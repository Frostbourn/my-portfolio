<?php

/**
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

defined('_JEXEC') or die;

if (!class_exists('Joomla\\CMS\\Form\\FormField')) {
    jimport('joomla.form.formfield');
}

use Joomla\CMS\Form\FormField;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

/**
 * Module admin usage meter (views/widgets + upgrade link).
 */
class JFormFieldUsagestatus extends FormField
{
    protected $type = 'Usagestatus';

    protected function getLabel()
    {
        return '';
    }

    protected function getInput()
    {
        $path = JPATH_SITE . '/modules/mod_js_like_box_pro/helper.php';
        if (!is_file($path)) {
            return '<div class="alert alert-warning">Helper not found.</div>';
        }

        require_once $path;

        $apiKey = trim((string) $this->form->getValue('api_key', 'params'));
        $app    = Factory::getApplication();
        $moduleId = (int) $app->input->getInt('id', 0);
        $domain   = Uri::getInstance()->getHost();
        $widgetId = $moduleId > 0
            ? substr(hash('sha256', $domain . '|' . $moduleId), 0, 24)
            : 'admin_preview';

        $status = ModJsLikeBoxProHelper::fetchStatus(
            ModJsLikeBoxProHelper::API_BASE_URL,
            $apiKey,
            $widgetId
        );

        return ModJsLikeBoxProHelper::renderAdminUsageHtml($status);
    }
}
