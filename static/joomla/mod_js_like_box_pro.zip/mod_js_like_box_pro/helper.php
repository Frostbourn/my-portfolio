<?php

/**
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @link       https://jsns.eu
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

/**
 * Server-side helper for JS Like Box PRO.
 *
 * All API calls are made server-side so the customer api_key never reaches the
 * browser. Feed payloads are cached on disk to reduce round-trips; the meta
 * block (usage + fresh beacon token) is fetched separately on every request.
 */
abstract class ModJsLikeBoxProHelper
{
    /** Hosted Like Box API (built into the module; not configurable in admin). */
    const API_BASE_URL = 'https://socialproof.pl/api';

    /** jsns.eu customer dashboard — API keys and usage. */
    const DASHBOARD_URL = 'https://jsns.eu/user/api-keys';

    /** jsns.eu plan upgrade page. */
    const UPGRADE_URL = 'https://jsns.eu/user/upgrade-plan';

    /** Disk cache lifetime for feed payloads (seconds). */
    const FEED_TTL = 1800;

    // -------------------------------------------------------------------------
    // Joomla 3.10 / 4 / 5 / 6 compatibility helpers
    // -------------------------------------------------------------------------

    /** @return bool */
    public static function isJoomla4()
    {
        return version_compare(JVERSION, '4.0', 'ge');
    }

    /** CSRF check for com_ajax POST (J3 JSession vs J4 Session). */
    public static function checkPostToken()
    {
        if (self::isJoomla4()) {
            return Session::checkToken('post');
        }

        jimport('joomla.session.session');

        return JSession::checkToken('post');
    }

    /** Append cache-buster query param (J3 asset URLs). */
    public static function appendAssetVersion($url, $version)
    {
        if ($version === '' || $version === null) {
            return $url;
        }

        $sep = (strpos($url, '?') !== false) ? '&' : '?';

        return $url . $sep . 'v=' . rawurlencode((string) $version);
    }

    /** Register a stylesheet on J3 and J4+. */
    public static function addDocumentStyleSheet($document, $url, $version = '')
    {
        if (self::isJoomla4()) {
            $options = ($version !== '') ? array('version' => (string) $version) : array();
            $document->addStyleSheet($url, $options);

            return;
        }

        $document->addStyleSheet(self::appendAssetVersion($url, $version));
    }

    /** Register a script on J3 and J4+. */
    public static function addDocumentScript($document, $url, $version = '', $defer = true)
    {
        if (self::isJoomla4()) {
            $options = ($version !== '') ? array('version' => (string) $version) : array();
            $attrs   = $defer ? array('defer' => 'defer') : array();
            $document->addScript($url, $options, $attrs);

            return;
        }

        $document->addScript(self::appendAssetVersion($url, $version), 'text/javascript', $defer, false);
    }

    /** Pass JSON config to frontend (Joomla.getOptions / optionsStorage fallback). */
    public static function addDocumentScriptOptions($document, $key, array $options)
    {
        if (method_exists($document, 'addScriptOptions')) {
            $document->addScriptOptions($key, $options);

            return;
        }

        $json = json_encode(array($key => $options));

        if ($json === false) {
            return;
        }

        $document->addScriptDeclaration(
            '(function(){var _o=' . $json . ';'
            . 'window.Joomla=window.Joomla||{};'
            . 'Joomla.optionsStorage=Joomla.optionsStorage||{};'
            . 'for(var _k in _o){if(Object.prototype.hasOwnProperty.call(_o,_k)){Joomla.optionsStorage[_k]=_o[_k];}}'
            . '})();'
        );
    }

    /** Plain-text mail body (isHtml vs legacy IsHTML). */
    private static function setMailerPlain($mailer)
    {
        if (method_exists($mailer, 'isHtml')) {
            $mailer->isHtml(false);
        } elseif (method_exists($mailer, 'IsHTML')) {
            $mailer->IsHTML(false);
        }
    }

    /** Send mail and return result (Send vs send). */
    private static function sendMailer($mailer)
    {
        if (method_exists($mailer, 'send')) {
            return $mailer->send();
        }

        return $mailer->Send();
    }

    /** Tab order in the slider (add new platforms here and in platforms()). */
    const PLATFORM_ORDER = array('facebook', 'twitter', 'instagram', 'youtube', 'linkedin', 'tiktok', 'pinterest', 'telegram');

    /**
     * Single source of truth for built-in social tabs.
     * Keep accent colours in sync with tmpl/css/style.scss.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function platforms()
    {
        return array(
            'facebook' => array(
                'label'           => 'facebook',
                'tab_class'       => 'facebook_icon',
                'icon'            => 'fab fa-facebook-f',
                'feed_icon'       => 'fa-facebook-f',
                'accent'          => '#3289d9',
                'endpoint'        => 'facebook',
                'api_param'       => 'page_id',
                'enabled_key'     => 'facebook_enabled',
                'id_key'          => 'facebook_username',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Like Page',
            ),
            'twitter' => array(
                'label'           => 'x',
                'tab_class'       => 'twitter_icon',
                'icon'            => 'fab fa-x-twitter',
                'feed_icon'       => 'fa-x-twitter',
                'accent'          => '#000000',
                'endpoint'        => 'x',
                'api_param'       => 'username',
                'enabled_key'     => 'twitter_enabled',
                'id_key'          => 'twitter_username',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'instagram' => array(
                'label'           => 'instagram',
                'tab_class'       => 'instagram_icon',
                'icon'            => 'fab fa-instagram',
                'feed_icon'       => 'fa-instagram',
                'accent'          => '#5851db',
                'endpoint'        => 'instagram',
                'api_param'       => 'username',
                'enabled_key'     => 'instagram_enabled',
                'id_key'          => 'instagram_username',
                'columns_key'     => null,
                'default_columns' => 1,
                'cta'             => 'Follow',
            ),
            'youtube' => array(
                'label'           => 'youtube',
                'tab_class'       => 'youtube_icon',
                'icon'            => 'fab fa-youtube',
                'feed_icon'       => 'fa-youtube',
                'accent'          => '#ff0000',
                'endpoint'        => 'youtube',
                'api_param'       => 'channel',
                'enabled_key'     => 'youtube_enabled',
                'id_key'          => 'youtube_channel',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Subscribe',
            ),
            'linkedin' => array(
                'label'           => 'linkedin',
                'tab_class'       => 'linkedin_icon',
                'icon'            => 'fab fa-linkedin-in',
                'feed_icon'       => 'fa-linkedin-in',
                'accent'          => '#0A66C2',
                'endpoint'        => 'linkedin',
                'api_param'       => 'account',
                'enabled_key'     => 'linkedin_enabled',
                'id_key'          => 'linkedin_company',
                'type_key'        => 'linkedin_type',
                'default_type'    => 'company',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'tiktok' => array(
                'label'           => 'tiktok',
                'tab_class'       => 'tiktok_icon',
                'icon'            => 'fab fa-tiktok',
                'feed_icon'       => 'fa-tiktok',
                'accent'          => '#000000',
                'endpoint'        => 'tiktok',
                'api_param'       => 'username',
                'enabled_key'     => 'tiktok_enabled',
                'id_key'          => 'tiktok_username',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'pinterest' => array(
                'label'           => 'pinterest',
                'tab_class'       => 'pinterest_icon',
                'icon'            => 'fab fa-pinterest-p',
                'feed_icon'       => 'fa-pinterest-p',
                'accent'          => '#E60023',
                'endpoint'        => 'pinterest',
                'api_param'       => 'account',
                'enabled_key'     => 'pinterest_enabled',
                'id_key'          => 'pinterest_account',
                'type_key'        => 'pinterest_type',
                'default_type'    => 'profile',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'telegram' => array(
                'label'           => 'telegram',
                'tab_class'       => 'telegram_icon',
                'icon'            => 'fab fa-telegram',
                'feed_icon'       => 'fa-telegram',
                'accent'          => '#26A5E4',
                'endpoint'        => 'telegram',
                'api_param'       => 'channel',
                'enabled_key'     => 'telegram_enabled',
                'id_key'          => 'telegram_channel',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Join Channel',
            ),
        );
    }

    /** @return array<string, array<string, mixed>>|null */
    public static function getPlatform($slug)
    {
        $slug = strtolower(trim((string) $slug));
        if ($slug === 'x') {
            $slug = 'twitter';
        }
        $all = self::platforms();

        return isset($all[$slug]) ? $all[$slug] : null;
    }

    /** Radio input id for the nth feed tab (tabOne … tabTen, then tab_N). */
    public static function tabRadioId($index)
    {
        $words = array('One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten');

        return isset($words[$index]) ? 'tab' . $words[$index] : 'tab_' . (int) $index;
    }

    /** Public profile URL used by the mobile bar and feed cards. */
    public static function buildProfileUrl($platform, $identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return 'https://jsns.eu';
        }
        if ($platform === 'linkedin') {
            return self::linkedInProfileUrl($identifier);
        }
        if ($platform === 'tiktok') {
            $username = self::normalizeTikTokIdentifier($identifier);
            return $username !== '' ? ('https://www.tiktok.com/@' . $username) : 'https://jsns.eu';
        }
        if ($platform === 'pinterest') {
            return self::pinterestProfileUrl($identifier);
        }
        if ($platform === 'telegram') {
            $channel = self::normalizeTelegramChannel($identifier);
            return $channel !== '' ? ('https://t.me/' . rawurlencode($channel)) : 'https://jsns.eu';
        }
        if (stripos($identifier, 'http') === 0) {
            return $identifier;
        }

        switch ($platform) {
            case 'instagram':
                return 'https://instagram.com/' . ltrim($identifier, '@');
            case 'twitter':
            case 'x':
                return 'https://x.com/' . ltrim($identifier, '@');
            case 'facebook':
                return 'https://www.facebook.com/' . $identifier;
            case 'youtube':
                return 'https://www.youtube.com/@' . ltrim($identifier, '@');
            case 'tiktok':
                return 'https://www.tiktok.com/@' . self::normalizeTikTokIdentifier($identifier);
            case 'telegram':
                $channel = self::normalizeTelegramChannel($identifier);
                return $channel !== '' ? ('https://t.me/' . rawurlencode($channel)) : 'https://jsns.eu';
            default:
                return 'https://jsns.eu';
        }
    }

    /** Normalize a Telegram channel username or t.me URL. */
    public static function normalizeTelegramChannel($identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (preg_match('~(?:https?://)?(?:www\.)?t\.me/(?:s/)?([^/?#]+)~i', $identifier, $m)) {
            return ltrim($m[1], '@/');
        }

        return ltrim($identifier, '@/');
    }

    /**
     * Normalize a Pinterest admin value to a canonical identifier.
     * Full URLs and user/board paths override the module type switch.
     *
     * @param string $identifier  Slug, board path, or URL from module settings.
     * @param string $type        profile|board
     */
    public static function normalizePinterestIdentifier($identifier, $type = 'profile')
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (preg_match('~^(?:www\.)?pinterest\.com/~i', $identifier) && stripos($identifier, 'http') !== 0) {
            $identifier = 'https://' . ltrim($identifier, '/');
        }

        if (stripos($identifier, 'http') === 0 || preg_match('~pinterest\.com/~i', $identifier)) {
            $path = trim((string) parse_url($identifier, PHP_URL_PATH), '/');
            $parts = array_values(array_filter(explode('/', $path)));
            if (count($parts) >= 2) {
                return $parts[0] . '/' . $parts[1];
            }
            if (!empty($parts[0])) {
                return $parts[0];
            }

            return $identifier;
        }

        $parts = array_values(array_filter(explode('/', str_replace('\\', '/', $identifier))));
        if (count($parts) >= 2) {
            return $parts[0] . '/' . $parts[1];
        }

        $slug = ltrim($identifier, '@/');
        $type = ($type === 'board') ? 'board' : 'profile';

        return $slug;
    }

    /** Public Pinterest profile or board URL for feed links. */
    public static function pinterestProfileUrl($identifier, $type = 'profile')
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return 'https://jsns.eu';
        }

        $normalized = self::normalizePinterestIdentifier($identifier, $type);
        if ($normalized === '') {
            return 'https://jsns.eu';
        }

        if (stripos($identifier, 'http') === 0) {
            return rtrim($identifier, '/') . '/';
        }

        if (strpos($normalized, '/') !== false) {
            $parts = explode('/', $normalized, 2);
            return 'https://www.pinterest.com/' . rawurlencode($parts[0]) . '/' . rawurlencode($parts[1]) . '/';
        }

        return 'https://www.pinterest.com/' . rawurlencode($normalized) . '/';
    }

    /**
     * Normalize a TikTok admin value to a bare @username handle.
     *
     * @param string $identifier  Handle or profile URL from module settings.
     */
    public static function normalizeTikTokIdentifier($identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (filter_var($identifier, FILTER_VALIDATE_URL)) {
            $path = trim((string) parse_url($identifier, PHP_URL_PATH), '/');
            if (preg_match('~^@?([^/]+)~', $path, $m)) {
                return ltrim($m[1], '@');
            }
            $identifier = $path;
        }

        return ltrim($identifier, '@');
    }

    /**
     * Normalize a LinkedIn admin value to a canonical identifier.
     * Full URLs and in/company/ prefixes win over the module type switch.
     *
     * @param string $identifier  Slug or URL from module settings.
     * @param string $type        company|profile
     */
    public static function normalizeLinkedInIdentifier($identifier, $type = 'company')
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (preg_match('~^(?:www\.)?linkedin\.com/~i', $identifier) && stripos($identifier, 'http') !== 0) {
            $identifier = 'https://' . ltrim($identifier, '/');
        }

        if (stripos($identifier, 'http') === 0) {
            return $identifier;
        }
        if (stripos($identifier, 'in/') === 0 || stripos($identifier, 'company/') === 0) {
            return $identifier;
        }
        if (preg_match('~linkedin\.com/(in|company)/~i', $identifier)) {
            return stripos($identifier, 'http') === 0 ? $identifier : ('https://' . ltrim($identifier, '/'));
        }

        $slug = ltrim($identifier, '@/');
        $type = ($type === 'profile') ? 'profile' : 'company';

        return $type === 'profile' ? ('in/' . $slug) : ('company/' . $slug);
    }

    /** Profile URL for a normalized LinkedIn identifier. */
    public static function linkedInProfileUrl($identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return 'https://jsns.eu';
        }

        if (preg_match('~^(?:www\.)?linkedin\.com/~i', $identifier) && stripos($identifier, 'http') !== 0) {
            $identifier = 'https://' . ltrim($identifier, '/');
        }

        if (stripos($identifier, 'http') === 0) {
            return $identifier;
        }
        if (stripos($identifier, 'in/') === 0 || stripos($identifier, 'company/') === 0) {
            return 'https://www.linkedin.com/' . ltrim($identifier, '/') . '/';
        }
        if (preg_match('~linkedin\.com/(in|company)/~i', $identifier)) {
            return stripos($identifier, 'http') === 0 ? $identifier : ('https://' . ltrim($identifier, '/'));
        }

        return 'https://www.linkedin.com/company/' . ltrim($identifier, '@/') . '/';
    }

    /**
     * Build one enabled feed tab from module params, or null when disabled/empty.
     *
     * @param object $params  Joomla module params.
     */
    public static function buildFeedEntry($slug, $params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12)
    {
        $cfg = self::getPlatform($slug);
        if ($cfg === null || !(int) $params->get($cfg['enabled_key'], 0)) {
            return null;
        }

        $identifier = trim((string) $params->get($cfg['id_key']));
        if ($identifier === '') {
            return null;
        }

        if ($slug === 'linkedin') {
            $typeKey = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'linkedin_type';
            $liType  = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'company');
            $identifier = self::normalizeLinkedInIdentifier($identifier, $liType);
        } elseif ($slug === 'tiktok') {
            $identifier = self::normalizeTikTokIdentifier($identifier);
        } elseif ($slug === 'pinterest') {
            $typeKey = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'pinterest_type';
            $pinType = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'profile');
            $identifier = self::normalizePinterestIdentifier($identifier, $pinType);
        } elseif ($slug === 'telegram') {
            $identifier = self::normalizeTelegramChannel($identifier);
        }

        $extraType = '';
        if ($slug === 'linkedin') {
            $extraType = $liType;
        } elseif ($slug === 'pinterest') {
            $extraType = $pinType;
        }

        $columns = (int) $cfg['default_columns'];
        if (!empty($cfg['columns_key'])) {
            $columns = (int) $params->get($cfg['columns_key'], $columns);
        }

        $profileUrl = self::buildProfileUrl($slug, $identifier);
        if ($slug === 'pinterest') {
            $profileUrl = self::pinterestProfileUrl($identifier, $extraType);
        }

        return array(
            'key'         => $slug,
            'label'       => $cfg['label'],
            'class'       => $cfg['tab_class'],
            'icon'        => $cfg['icon'],
            'accent'      => $cfg['accent'],
            'profile_url' => $profileUrl,
            'html'        => self::renderFeed(
                $slug,
                self::getFeed($apiUrl, $apiKey, $slug, $identifier, $widgetId, $postsLimit, $extraType),
                $profileUrl,
                $identifier,
                $columns,
                $apiUrl,
                $theme
            ),
        );
    }

    /**
     * Build optional feature tabs: unified feed, contact, WhatsApp, testimonials.
     * Order: unified → contact → WhatsApp → Calendly → FAQ → testimonials.
     * Platform feeds are merged before these in mod_js_like_box_pro.php.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function buildSpecialTabs($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12, $beaconToken = '', $moduleId = 0)
    {
        $tabs = array();

        if ((int) $params->get('unified_feed_enabled', 0) === 1) {
            $entry = self::buildUnifiedFeedEntry($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('contact_enabled', 0) === 1) {
            $entry = self::buildContactEntry($params, $theme, $moduleId);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('whatsapp_enabled', 0) === 1) {
            $entry = self::buildWhatsAppEntry($params, $theme);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('calendly_enabled', 0) === 1) {
            $entry = self::buildCalendlyEntry($params, $theme);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('faq_enabled', 0) === 1) {
            $entry = self::buildFaqEntry($params, $theme);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('testimonials_enabled', 0) === 1) {
            $entry = self::buildTestimonialsEntry($params, $theme);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        return $tabs;
    }

    /** @return array{slug:string,identifier:string,type:string}|null */
    private static function resolvePlatformIdentifier($slug, $params)
    {
        $cfg = self::getPlatform($slug);
        if ($cfg === null || (int) $params->get($cfg['enabled_key'], 0) !== 1) {
            return null;
        }

        $identifier = trim((string) $params->get($cfg['id_key']));
        if ($identifier === '') {
            return null;
        }

        $type = '';
        if ($slug === 'linkedin') {
            $typeKey    = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'linkedin_type';
            $type       = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'company');
            $identifier = self::normalizeLinkedInIdentifier($identifier, $type);
        } elseif ($slug === 'tiktok') {
            $identifier = self::normalizeTikTokIdentifier($identifier);
        } elseif ($slug === 'pinterest') {
            $typeKey    = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'pinterest_type';
            $type       = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'profile');
            $identifier = self::normalizePinterestIdentifier($identifier, $type);
        } elseif ($slug === 'telegram') {
            $identifier = self::normalizeTelegramChannel($identifier);
        }

        if ($identifier === '') {
            return null;
        }

        return array('slug' => $slug, 'identifier' => $identifier, 'type' => $type);
    }

    /** @return array<int, array{slug:string,identifier:string,type:string}> */
    public static function collectEnabledPlatforms($params)
    {
        $out = array();
        foreach (self::PLATFORM_ORDER as $slug) {
            $resolved = self::resolvePlatformIdentifier($slug, $params);
            if ($resolved !== null) {
                $out[] = $resolved;
            }
        }

        return $out;
    }

    /** @return array|null */
    public static function getUnifiedFeed($apiUrl, $apiKey, $params, $widgetId, $limit = 12)
    {
        $enabled = self::collectEnabledPlatforms($params);
        if (count($enabled) < 2) {
            return null;
        }

        $cacheDir  = JPATH_CACHE . '/mod_js_like_box_pro';
        $cacheKey  = md5(json_encode($enabled) . '|' . (int) $limit);
        $cacheFile = $cacheDir . '/unified_v1_' . $cacheKey . '.json';

        if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < self::FEED_TTL) {
            $cached = json_decode(file_get_contents($cacheFile), true);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $slugs   = array();
        $query   = array('widget_id' => $widgetId, 'limit' => (int) $limit);
        foreach ($enabled as $item) {
            $slug = $item['slug'];
            $cfg  = self::getPlatform($slug);
            if ($cfg === null) {
                continue;
            }
            $slugs[] = $slug;
            $value   = ($slug === 'twitter' || $slug === 'tiktok') ? ltrim($item['identifier'], '@') : $item['identifier'];
            $query[$slug] = $value;
            if ($slug === 'linkedin' && $item['type'] !== '') {
                $query['linkedin_type'] = $item['type'];
            }
            if ($slug === 'pinterest' && $item['type'] !== '') {
                $query['pinterest_type'] = $item['type'];
            }
        }

        if (count($slugs) < 2) {
            return null;
        }

        $query['platforms'] = implode(',', $slugs);
        $json = self::apiCall($apiUrl, $apiKey, 'social', $query, 12);
        $data = (is_array($json) && isset($json['data']) && is_array($json['data'])) ? $json['data'] : null;

        if (is_array($data) && !empty($data)) {
            if (!is_dir($cacheDir)) {
                @mkdir($cacheDir, 0755, true);
            }
            @file_put_contents($cacheFile, json_encode($data));
            return $data;
        }

        if (is_file($cacheFile)) {
            $stale = json_decode(file_get_contents($cacheFile), true);
            if (is_array($stale)) {
                return $stale;
            }
        }

        return is_array($data) ? $data : null;
    }

    public static function buildUnifiedFeedEntry($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12)
    {
        $data = self::getUnifiedFeed($apiUrl, $apiKey, $params, $widgetId, $postsLimit);
        if (!is_array($data) || empty($data)) {
            return null;
        }

        $label = trim((string) $params->get('unified_feed_label', ''));
        if ($label === '') {
            $label = 'Social';
        }

        return array(
            'key'         => 'unified',
            'label'       => $label,
            'class'       => 'unified_icon',
            'icon'        => 'fas fa-layer-group',
            'accent'      => '#7C3AED',
            'profile_url' => '',
            'html'        => self::renderUnifiedFeed($data, $apiUrl, $theme),
        );
    }

    public static function buildContactEntry($params, $theme, $moduleId)
    {
        $recipient = trim((string) $params->get('contact_recipient', ''));
        if ($recipient === '' || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            return null;
        }

        $label = trim((string) $params->get('contact_tab_label', ''));
        if ($label === '') {
            $label = 'Contact';
        }

        return array(
            'key'         => 'contact',
            'label'       => $label,
            'class'       => 'contact_icon',
            'icon'        => 'fas fa-envelope',
            'accent'      => '#6366F1',
            'profile_url' => 'mailto:' . $recipient,
            'html'        => self::renderContactForm($params, $theme, (int) $moduleId),
        );
    }

    /**
     * com_ajax handler: send contact-tab leads via Joomla Mail (site SMTP plugin).
     * URL: index.php?option=com_ajax&module=js_like_box_pro&method=submitContact&format=json&module_id={moduleId}
     *
     * @return array{success:bool,error?:string}
     */
    public static function submitContactAjax()
    {
        $app = Factory::getApplication();

        if (!self::checkPostToken()) {
            return self::contactAjaxResult(false, 'Invalid session. Please reload the page and try again.');
        }

        $moduleId = $app->input->post->getInt('module_id', 0);
        if ($moduleId <= 0) {
            $moduleId = $app->input->getInt('module_id', 0);
        }
        if ($moduleId <= 0) {
            return self::contactAjaxResult(false, 'Contact form is not configured (missing module id).');
        }

        $module = self::loadContactModule($moduleId);
        if ($module === null) {
            return self::contactAjaxResult(false, 'Contact form is not configured (module not found).');
        }

        $params = new Registry($module->params);
        if ((int) $params->get('contact_enabled', 0) !== 1) {
            return self::contactAjaxResult(false, 'Contact tab is disabled.');
        }

        $recipient = trim((string) $params->get('contact_recipient', ''));
        if ($recipient === '' || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            return self::contactAjaxResult(false, 'Recipient email is not configured.');
        }

        $input = $app->input;

        // Honeypots — obscure names so browsers/password managers do not autofill them.
        if (trim((string) $input->post->getString('contact_hp_a', '')) !== ''
            || trim((string) $input->post->getString('contact_hp_b', '')) !== '') {
            return self::contactAjaxResult(true);
        }

        if (!self::contactVerifyTimestamp(
            $moduleId,
            (int) $input->post->getInt('contact_ts', 0),
            (string) $input->post->getString('contact_sig', '')
        )) {
            return self::contactAjaxResult(false, 'Please wait a moment and try again.');
        }

        if (!self::contactRateLimitOk()) {
            return self::contactAjaxResult(false, 'Too many messages sent. Please try again later.');
        }

        $name    = trim((string) $input->post->getString('name', ''));
        $email   = trim((string) $input->post->getString('email', ''));
        $message = trim((string) $input->post->getString('message', ''));
        $phone   = trim((string) $input->post->getString('phone', ''));
        $showPhone = (int) $params->get('contact_show_phone', 0) === 1;

        if ($name === '' || $email === '' || $message === '') {
            return self::contactAjaxResult(false, 'Please fill in all required fields.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return self::contactAjaxResult(false, 'Invalid email address.');
        }
        if (strlen($name) > 120 || strlen($email) > 200 || strlen($message) > 5000 || strlen($phone) > 40) {
            return self::contactAjaxResult(false, 'One of the fields is too long.');
        }
        if (self::contactCountLinks($message) > 3) {
            return self::contactAjaxResult(false, 'Your message contains too many links.');
        }

        $subject = 'Js Like Box Slider contact: ' . $name;
        $body    = "New message from Js Like Box Slider\n\n"
            . "Name: {$name}\n"
            . "Email: {$email}\n"
            . (($showPhone && $phone !== '') ? "Phone: {$phone}\n" : '')
            . "Site: " . $app->get('sitename') . "\n"
            . "Page: " . Uri::getInstance()->toString(array('scheme', 'host', 'path')) . "\n\n"
            . "Message:\n{$message}\n";

        $mailError = self::sendContactMail($recipient, $email, $name, $subject, $body);
        if ($mailError !== '') {
            return self::contactAjaxResult(false, $mailError);
        }

        return self::contactAjaxResult(true);
    }

    /** @return string Empty on success, user-facing error otherwise. */
    private static function sendContactMail($recipient, $replyEmail, $replyName, $subject, $body)
    {
        $app      = Factory::getApplication();
        $mailfrom = trim((string) $app->get('mailfrom'));
        $fromname = trim((string) $app->get('fromname'));

        if ($mailfrom === '' || !filter_var($mailfrom, FILTER_VALIDATE_EMAIL)) {
            return 'Site mail is not configured. Set a valid From Email in System → Global Configuration → Mail.';
        }

        try {
            $mailer = Factory::getMailer();

            if (method_exists($mailer, 'clearAllRecipients')) {
                $mailer->clearAllRecipients();
            }
            if (method_exists($mailer, 'clearReplyTos')) {
                $mailer->clearReplyTos();
            }
            if (method_exists($mailer, 'clearAttachments')) {
                $mailer->clearAttachments();
            }
            if (method_exists($mailer, 'clearCustomHeaders')) {
                $mailer->clearCustomHeaders();
            }

            $mailer->setSender(array($mailfrom, $fromname !== '' ? $fromname : $mailfrom));
            $mailer->addRecipient($recipient);
            $mailer->addReplyTo($replyEmail, $replyName);
            $mailer->setSubject($subject);
            $mailer->setBody($body);
            self::setMailerPlain($mailer);

            $sent = self::sendMailer($mailer);

            if ($sent === true) {
                return '';
            }

            $detail = '';
            if ($sent instanceof \Throwable) {
                $detail = $sent->getMessage();
            } elseif (is_string($sent) && $sent !== '') {
                $detail = $sent;
            } elseif (!empty($mailer->ErrorInfo)) {
                $detail = (string) $mailer->ErrorInfo;
            }

            if ($detail !== '') {
                Log::add(
                    'JS Like Box contact mail failed to ' . $recipient . ': ' . $detail,
                    Log::ERROR,
                    'mod_js_like_box_pro'
                );
            }

            return 'Could not send message. Configure SMTP in System → Global Configuration → Mail (PHP mail often fails on hosting).';
        } catch (\Throwable $e) {
            Log::add(
                'JS Like Box contact mail exception: ' . $e->getMessage(),
                Log::ERROR,
                'mod_js_like_box_pro'
            );

            return 'Could not send message. Configure SMTP in System → Global Configuration → Mail (PHP mail often fails on hosting).';
        }
    }

    /** Non-SEF com_ajax URL (module param without mod_ prefix). */
    public static function buildContactAjaxUrl($moduleId)
    {
        $app    = Factory::getApplication();
        $itemId = $app->input->getInt('Itemid', 0);
        $query  = array(
            'option'    => 'com_ajax',
            'module'    => 'js_like_box_pro',
            'method'    => 'submitContact',
            'format'    => 'json',
            'module_id' => (int) $moduleId,
        );

        if ($itemId > 0) {
            $query['Itemid'] = $itemId;
        }

        return Uri::base() . 'index.php?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    /** @return object|null */
    private static function loadContactModule($moduleId)
    {
        $moduleId = (int) $moduleId;
        if ($moduleId <= 0) {
            return null;
        }

        $module = ModuleHelper::getModuleById($moduleId);
        if ($module && (int) $module->id === $moduleId && $module->module === 'mod_js_like_box_pro') {
            return $module;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__modules'))
            ->where($db->quoteName('id') . ' = ' . $moduleId)
            ->where($db->quoteName('module') . ' = ' . $db->quote('mod_js_like_box_pro'));

        $db->setQuery($query);

        try {
            $row = $db->loadObject();
        } catch (\Exception $e) {
            return null;
        }

        return ($row && (int) $row->id === $moduleId) ? $row : null;
    }

    /** @return array{ts:int,sig:string} */
    private static function contactSignTimestamp($moduleId)
    {
        $ts  = time();
        $sig = hash_hmac('sha256', (int) $moduleId . '|' . $ts, self::contactSpamSecret());

        return array('ts' => $ts, 'sig' => $sig);
    }

    private static function contactVerifyTimestamp($moduleId, $ts, $sig)
    {
        if ($ts <= 0 || $sig === '') {
            return false;
        }

        $expected = hash_hmac('sha256', (int) $moduleId . '|' . $ts, self::contactSpamSecret());
        if (!hash_equals($expected, $sig)) {
            return false;
        }

        $age = time() - $ts;

        return $age >= 3 && $age <= 7200;
    }

    private static function contactSpamSecret()
    {
        return (string) Factory::getApplication()->get('secret') . '|mod_js_like_box_pro|contact';
    }

    private static function contactRateLimitOk($max = 5, $windowSec = 3600)
    {
        $ip = (string) Factory::getApplication()->input->server->getString('REMOTE_ADDR', 'unknown');
        $dir = JPATH_CACHE . '/mod_js_like_box_pro';

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $file = $dir . '/contact_rate_' . md5($ip) . '.json';
        $now  = time();
        $data = array('count' => 0, 'start' => $now);

        if (is_file($file)) {
            $decoded = json_decode((string) file_get_contents($file), true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
            if ($now - (int) $data['start'] > $windowSec) {
                $data = array('count' => 0, 'start' => $now);
            }
        }

        if ((int) $data['count'] >= $max) {
            return false;
        }

        $data['count'] = (int) $data['count'] + 1;
        @file_put_contents($file, json_encode($data));

        return true;
    }

    private static function contactCountLinks($text)
    {
        if (preg_match_all('/https?:\/\/|www\./i', $text, $matches)) {
            return count($matches[0]);
        }

        return 0;
    }

    /** @return array{success:bool,error?:string} */
    private static function contactAjaxResult($success, $error = '')
    {
        $result = array('success' => (bool) $success);
        if ($error !== '') {
            $result['error'] = $error;
        }

        return $result;
    }

    private static function sanitizeMapEmbedUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }

        if (!preg_match('#^https://(www\.)?google\.[a-z.]{2,}/maps/#i', $url)) {
            return '';
        }

        return $url;
    }

    private static function buildMapsSearchUrl($address)
    {
        $address = trim((string) $address);
        if ($address === '') {
            return '';
        }

        return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($address);
    }

    private static function renderContactDetails($params)
    {
        if ((int) $params->get('contact_show_details', 0) !== 1) {
            return '';
        }

        $phone   = trim((string) $params->get('contact_display_phone', ''));
        $email   = trim((string) $params->get('contact_display_email', ''));
        $address = trim((string) $params->get('contact_address', ''));
        $mapsUrl = trim((string) $params->get('contact_maps_url', ''));

        if ($mapsUrl === '' && $address !== '') {
            $mapsUrl = self::buildMapsSearchUrl($address);
        }

        if ($phone === '' && $email === '' && $address === '') {
            return '';
        }

        ob_start();
        ?>
        <div class="jssocial_contact_details">
            <?php if ($address !== '') : ?>
                <div class="jssocial_contact_detail">
                    <i class="fas fa-location-dot" aria-hidden="true"></i>
                    <div class="jssocial_contact_detail_body">
                        <span class="jssocial_contact_detail_label">Address</span>
                        <?php if ($mapsUrl !== '') : ?>
                            <a class="jssocial_contact_detail_value" href="<?php echo htmlspecialchars($mapsUrl); ?>" target="_blank" rel="noopener">
                                <?php echo nl2br(htmlspecialchars($address)); ?>
                            </a>
                        <?php else : ?>
                            <span class="jssocial_contact_detail_value"><?php echo nl2br(htmlspecialchars($address)); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($phone !== '') : ?>
                <div class="jssocial_contact_detail">
                    <i class="fas fa-phone" aria-hidden="true"></i>
                    <div class="jssocial_contact_detail_body">
                        <span class="jssocial_contact_detail_label">Phone</span>
                        <a class="jssocial_contact_detail_value" href="tel:<?php echo htmlspecialchars(preg_replace('/\s+/', '', $phone)); ?>">
                            <?php echo htmlspecialchars($phone); ?>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) : ?>
                <div class="jssocial_contact_detail">
                    <i class="fas fa-envelope" aria-hidden="true"></i>
                    <div class="jssocial_contact_detail_body">
                        <span class="jssocial_contact_detail_label">Email</span>
                        <a class="jssocial_contact_detail_value" href="mailto:<?php echo htmlspecialchars($email); ?>">
                            <?php echo htmlspecialchars($email); ?>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function renderContactMap($params)
    {
        if ((int) $params->get('contact_show_map', 0) !== 1) {
            return '';
        }

        $embed = self::sanitizeMapEmbedUrl((string) $params->get('contact_map_embed', ''));
        if ($embed === '') {
            return '';
        }

        ob_start();
        ?>
        <div class="jssocial_contact_map">
            <iframe
                src="<?php echo htmlspecialchars($embed); ?>"
                title="Location map"
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"
                allowfullscreen></iframe>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function buildWhatsAppEntry($params, $theme)
    {
        $phone = self::normalizeWhatsAppPhone((string) $params->get('whatsapp_phone', ''));
        if (strlen($phone) < 8) {
            return null;
        }

        $message = trim((string) $params->get('whatsapp_message', ''));
        $url     = self::buildWhatsAppUrl($phone, $message);
        $telUrl  = 'tel:+' . $phone;

        $label = trim((string) $params->get('whatsapp_tab_label', ''));
        if ($label === '') {
            $label = 'WhatsApp';
        }

        return array(
            'key'         => 'whatsapp',
            'label'       => $label,
            'class'       => 'whatsapp_icon',
            'icon'        => 'fab fa-whatsapp',
            'accent'      => '#25D366',
            'profile_url' => $url,
            'html'        => self::renderWhatsAppTab($params, $theme, $url, $telUrl, $phone),
        );
    }

    private static function formatWhatsAppPhoneDisplay($digits)
    {
        $digits = self::normalizeWhatsAppPhone($digits);
        if ($digits === '') {
            return '';
        }

        return '+' . $digits;
    }

    /** @return array<int, string> */
    private static function parseWhatsAppBullets($params)
    {
        $raw = trim((string) $params->get('whatsapp_bullets', ''));
        if ($raw === '') {
            return array();
        }

        $lines = preg_split('/\r\n|\r|\n/', $raw);
        $out   = array();

        foreach ((array) $lines as $line) {
            $line = trim((string) $line);
            if ($line !== '') {
                $out[] = $line;
            }
        }

        return $out;
    }

    public static function renderWhatsAppTab($params, $theme, $url, $telUrl = '', $phoneDigits = '')
    {
        $theme       = self::normalizeTheme($theme);
        $intro       = trim((string) $params->get('whatsapp_intro', ''));
        $displayName = trim((string) $params->get('whatsapp_display_name', ''));
        $hours       = trim((string) $params->get('whatsapp_hours', ''));
        $replyNote   = trim((string) $params->get('whatsapp_reply_note', ''));
        $cta         = trim((string) $params->get('whatsapp_cta', ''));
        $callCta     = trim((string) $params->get('whatsapp_call_cta', ''));
        if ($cta === '') {
            $cta = 'Chat on WhatsApp';
        }
        if ($callCta === '') {
            $callCta = 'Call instead';
        }
        $showCall    = (int) $params->get('whatsapp_show_call', 1) === 1;
        $phoneDisp   = self::formatWhatsAppPhoneDisplay($phoneDigits);
        $bullets     = self::parseWhatsAppBullets($params);

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--whatsapp" style="--jssocial-accent: #25D366;">
            <div class="jssocial_whatsapp">
                <div class="jssocial_whatsapp_hero">
                    <div class="jssocial_whatsapp_icon"><i class="fab fa-whatsapp" aria-hidden="true"></i></div>
                    <div class="jssocial_whatsapp_hero_text">
                        <?php if ($displayName !== '') : ?>
                            <div class="jssocial_whatsapp_name"><?php echo htmlspecialchars($displayName); ?></div>
                        <?php endif; ?>
                        <?php if ($phoneDisp !== '') : ?>
                            <div class="jssocial_whatsapp_phone"><?php echo htmlspecialchars($phoneDisp); ?></div>
                        <?php endif; ?>
                        <?php if ($hours !== '') : ?>
                            <div class="jssocial_whatsapp_hours"><i class="fas fa-clock" aria-hidden="true"></i> <?php echo htmlspecialchars($hours); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($replyNote !== '') : ?>
                    <div class="jssocial_whatsapp_note">
                        <i class="fas fa-bolt" aria-hidden="true"></i>
                        <?php echo htmlspecialchars($replyNote); ?>
                    </div>
                <?php endif; ?>

                <?php if ($intro !== '') : ?>
                    <p class="jssocial_whatsapp_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>

                <?php if (!empty($bullets)) : ?>
                    <ul class="jssocial_whatsapp_bullets">
                        <?php foreach ($bullets as $bullet) : ?>
                            <li><?php echo htmlspecialchars($bullet); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <div class="jssocial_whatsapp_actions">
                    <a class="jssocial_whatsapp_btn jssocial_whatsapp_btn--primary" href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-whatsapp" aria-hidden="true"></i>
                        <span><?php echo htmlspecialchars($cta); ?></span>
                    </a>
                    <?php if ($showCall && $telUrl !== '') : ?>
                        <a class="jssocial_whatsapp_btn jssocial_whatsapp_btn--secondary" href="<?php echo htmlspecialchars($telUrl); ?>">
                            <i class="fas fa-phone" aria-hidden="true"></i>
                            <span><?php echo htmlspecialchars($callCta); ?></span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function sanitizeCalendlyEmbedUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return '';
        }

        $host = strtolower((string) parse_url($url, PHP_URL_SCHEME));
        if ($host !== 'https') {
            return '';
        }

        $hostname = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (!preg_match('/(^|\.)calendly\.com$/', $hostname)) {
            return '';
        }

        return $url;
    }

    private static function calendlyPublicUrl($embedUrl)
    {
        $embedUrl = trim((string) $embedUrl);
        if ($embedUrl === '') {
            return '';
        }

        $parts = parse_url($embedUrl);
        if (empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }

        $path = isset($parts['path']) ? $parts['path'] : '';

        return $parts['scheme'] . '://' . $parts['host'] . $path;
    }

    public static function buildCalendlyEntry($params, $theme)
    {
        $embedUrl = self::sanitizeCalendlyEmbedUrl((string) $params->get('calendly_embed_url', ''));
        if ($embedUrl === '') {
            return null;
        }

        $link = trim((string) $params->get('calendly_link', ''));
        if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
            $link = '';
        }
        if ($link === '') {
            $link = self::calendlyPublicUrl($embedUrl);
        }

        $label = trim((string) $params->get('calendly_tab_label', ''));
        if ($label === '') {
            $label = 'Book a call';
        }

        return array(
            'key'         => 'calendly',
            'label'       => $label,
            'class'       => 'calendly_icon',
            'icon'        => 'fas fa-calendar-check',
            'accent'      => '#0EA5E9',
            'profile_url' => '',
            'html'        => self::renderCalendlyTab($params, $theme, $embedUrl, $link),
        );
    }

    public static function renderCalendlyTab($params, $theme, $embedUrl, $publicUrl = '')
    {
        $theme   = self::normalizeTheme($theme);
        $intro   = trim((string) $params->get('calendly_intro', ''));
        $cta     = trim((string) $params->get('calendly_cta', ''));
        if ($cta === '') {
            $cta = 'Open in Calendly';
        }
        $height  = (int) $params->get('calendly_height', 480);
        if ($height < 320) {
            $height = 320;
        }
        if ($height > 900) {
            $height = 900;
        }
        $publicUrl = trim((string) $publicUrl);

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--calendly" style="--jssocial-accent: #0EA5E9;">
            <div class="jssocial_calendly">
                <?php if ($intro !== '') : ?>
                    <p class="jssocial_calendly_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>
                <div class="jssocial_calendly_embed">
                    <iframe
                        src="<?php echo htmlspecialchars($embedUrl); ?>"
                        title="Book a meeting"
                        loading="lazy"
                        style="min-height:<?php echo $height; ?>px;"></iframe>
                </div>
                <?php if ($publicUrl !== '') : ?>
                    <a class="jssocial_calendly_fallback" href="<?php echo htmlspecialchars($publicUrl); ?>" target="_blank" rel="noopener noreferrer">
                        <i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i>
                        <?php echo htmlspecialchars($cta); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /** @return array<int, array{question:string,answer:string}> */
    public static function parseFaqItems($params)
    {
        $raw   = $params->get('faq_items');
        $items = array();

        foreach ((array) $raw as $row) {
            $row      = (object) $row;
            $question = trim((string) ($row->question ?? ''));
            $answer   = trim((string) ($row->answer ?? ''));
            if ($question === '' || $answer === '') {
                continue;
            }

            $items[] = array(
                'question' => $question,
                'answer'   => $answer,
            );
        }

        return $items;
    }

    public static function buildFaqEntry($params, $theme)
    {
        $items = self::parseFaqItems($params);
        if (empty($items)) {
            return null;
        }

        $label = trim((string) $params->get('faq_tab_label', ''));
        if ($label === '') {
            $label = 'FAQ';
        }

        return array(
            'key'         => 'faq',
            'label'       => $label,
            'class'       => 'faq_icon',
            'icon'        => 'fas fa-circle-question',
            'accent'      => '#6366F1',
            'profile_url' => '',
            'html'        => self::renderFaqTab($items, $theme, $params),
        );
    }

    public static function renderFaqTab(array $items, $theme, $params)
    {
        $theme = self::normalizeTheme($theme);
        $intro = trim((string) $params->get('faq_intro', ''));
        if ($intro === '') {
            $intro = 'Quick answers before you reach out.';
        }

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--faq" style="--jssocial-accent: #6366F1;">
            <div class="jssocial_faq">
                <p class="jssocial_faq_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <div class="jssocial_faq_list">
                    <?php foreach ($items as $i => $item) : ?>
                        <details class="jssocial_faq_item"<?php echo $i === 0 ? ' open' : ''; ?>>
                            <summary class="jssocial_faq_question"><?php echo htmlspecialchars($item['question']); ?></summary>
                            <div class="jssocial_faq_answer"><?php echo nl2br(htmlspecialchars($item['answer'])); ?></div>
                        </details>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function buildTestimonialsEntry($params, $theme)
    {
        $items = self::parseTestimonials($params);
        if (empty($items)) {
            return null;
        }

        $label = trim((string) $params->get('testimonials_tab_label', ''));
        if ($label === '') {
            $label = 'Reviews';
        }

        return array(
            'key'         => 'testimonials',
            'label'       => $label,
            'class'       => 'testimonials_icon',
            'icon'        => 'fas fa-quote-left',
            'accent'      => '#F59E0B',
            'profile_url' => '',
            'html'        => self::renderTestimonials($items, $theme, $params),
        );
    }

    /** @return array<int, array<string, mixed>> */
    public static function parseTestimonials($params)
    {
        $raw   = $params->get('testimonials');
        $items = array();
        $order = 0;

        foreach ((array) $raw as $row) {
            $row   = (object) $row;
            $quote = trim((string) ($row->quote ?? ''));
            $name  = trim((string) ($row->name ?? ''));
            if ($quote === '' || $name === '') {
                continue;
            }

            $rating = (int) ($row->rating ?? 0);
            if ($rating < 0) {
                $rating = 0;
            }
            if ($rating > 5) {
                $rating = 5;
            }

            $source = strtolower(trim((string) ($row->source ?? 'manual')));
            if (!in_array($source, array('manual', 'google', 'facebook', 'trustpilot', 'other'), true)) {
                $source = 'manual';
            }

            $link = trim((string) ($row->link ?? ''));
            if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
                $link = '';
            }

            $items[] = array(
                'name'     => $name,
                'quote'    => $quote,
                'rating'   => $rating,
                'company'  => trim((string) ($row->company ?? '')),
                'avatar'   => self::sanitizeTestimonialAvatarUrl((string) ($row->avatar ?? '')),
                'date'     => trim((string) ($row->date ?? '')),
                'source'   => $source,
                'link'     => $link,
                'featured' => (int) ($row->featured ?? 0) === 1,
                'order'    => $order++,
            );
        }

        usort($items, function ($a, $b) {
            $af = !empty($a['featured']) ? 0 : 1;
            $bf = !empty($b['featured']) ? 0 : 1;
            if ($af !== $bf) {
                return $af - $bf;
            }

            return (int) $a['order'] - (int) $b['order'];
        });

        return $items;
    }

    private static function sanitizeTestimonialAvatarUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return '';
        }

        $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, array('http', 'https'), true)) {
            return '';
        }

        return $url;
    }

    private static function testimonialInitials($name)
    {
        $name = trim((string) $name);
        if ($name === '') {
            return '?';
        }

        $parts = preg_split('/\s+/u', $name, -1, PREG_SPLIT_NO_EMPTY);
        if (!$parts) {
            return '?';
        }

        if (count($parts) === 1) {
            return mb_strtoupper(mb_substr($parts[0], 0, 2));
        }

        return mb_strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[count($parts) - 1], 0, 1));
    }

    /** @return array{count:int,average:float,rated_count:int} */
    private static function testimonialStats(array $items)
    {
        $rated = 0;
        $sum   = 0;

        foreach ($items as $item) {
            $rating = (int) ($item['rating'] ?? 0);
            if ($rating > 0) {
                $rated++;
                $sum += $rating;
            }
        }

        return array(
            'count'       => count($items),
            'rated_count' => $rated,
            'average'     => $rated > 0 ? round($sum / $rated, 1) : 0.0,
        );
    }

    private static function testimonialSourceLabel($source)
    {
        $map = array(
            'manual'     => 'Verified review',
            'google'     => 'Google',
            'facebook'   => 'Facebook',
            'trustpilot' => 'Trustpilot',
            'other'      => 'Review',
        );

        return isset($map[$source]) ? $map[$source] : 'Review';
    }

    private static function testimonialSourceIcon($source)
    {
        $map = array(
            'manual'     => 'fas fa-circle-check',
            'google'     => 'fab fa-google',
            'facebook'   => 'fab fa-facebook-f',
            'trustpilot' => 'fas fa-star',
            'other'      => 'fas fa-quote-left',
        );

        return isset($map[$source]) ? $map[$source] : 'fas fa-quote-left';
    }

    private static function renderTestimonialAvatar($name, $avatarUrl)
    {
        $initials = self::testimonialInitials($name);
        ob_start();
        ?>
        <div class="jssocial_testimonial_avatarwrap">
            <span class="jssocial_testimonial_avatar_initials" aria-hidden="true"><?php echo htmlspecialchars($initials); ?></span>
            <?php if ($avatarUrl !== '') : ?>
                <img class="jssocial_testimonial_avatar" src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="" loading="lazy" decoding="async" />
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function normalizeWhatsAppPhone($phone)
    {
        return preg_replace('/\D+/', '', trim((string) $phone));
    }

    public static function buildWhatsAppUrl($phone, $message = '')
    {
        $phone = self::normalizeWhatsAppPhone($phone);
        if ($phone === '') {
            return '';
        }

        $url = 'https://wa.me/' . rawurlencode($phone);
        $message = trim((string) $message);
        if ($message !== '') {
            $url .= '?text=' . rawurlencode($message);
        }

        return $url;
    }

    public static function renderUnifiedFeed(array $feedsByPlatform, $apiUrl, $theme)
    {
        $theme   = self::normalizeTheme($theme);
        $posts   = array();
        $profiles = array();

        foreach ($feedsByPlatform as $platform => $feed) {
            if (!is_array($feed)) {
                continue;
            }
            $platform = (string) $platform;
            if (!empty($feed['profile']) && is_array($feed['profile'])) {
                $profiles[$platform] = $feed['profile'];
            }
            if (empty($feed['posts']) || !is_array($feed['posts'])) {
                continue;
            }
            foreach ($feed['posts'] as $post) {
                if (!is_array($post)) {
                    continue;
                }
                $post['_platform'] = $platform;
                $posts[] = $post;
            }
        }

        usort($posts, function ($a, $b) {
            $ta = isset($a['created_at']) ? strtotime((string) $a['created_at']) : 0;
            $tb = isset($b['created_at']) ? strtotime((string) $b['created_at']) : 0;
            return $tb <=> $ta;
        });

        $ctx = array(
            'apiUrl'     => $apiUrl,
            'avatar'     => '',
            'handle'     => '',
            'profileUrl' => '#',
            'meta'       => array('icon' => 'fa-layer-group', 'accent' => '#7C3AED', 'button' => 'Follow'),
            'platform'   => 'unified',
            'isX'        => false,
            'verified'   => false,
            'profiles'   => $profiles,
        );

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--unified" style="--jssocial-accent: #7C3AED;">
            <div class="jssocial_profile jssocial_profile--compact">
                <div class="jssocial_profile_body">
                    <div class="jssocial_ident">
                        <div class="jssocial_name">Latest updates</div>
                        <div class="jssocial_tagline">Posts from all your connected social accounts</div>
                    </div>
                </div>
            </div>
            <?php if (!empty($posts)) : ?>
                <?php echo self::renderPostList($posts, $ctx); ?>
            <?php else : ?>
                <div class="jssocial_empty"><p>No posts to show right now.</p></div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function renderContactForm($params, $theme, $moduleId)
    {
        $theme       = self::normalizeTheme($theme);
        $intro       = trim((string) $params->get('contact_intro', ''));
        $successMsg  = trim((string) $params->get('contact_success_msg', ''));
        if ($successMsg === '') {
            $successMsg = 'Thank you! Your message has been sent.';
        }
        $showPhone   = (int) $params->get('contact_show_phone', 0) === 1;
        $submitLabel = trim((string) $params->get('contact_submit_label', ''));
        if ($submitLabel === '') {
            $submitLabel = 'Send message';
        }

        $ajaxUrl = self::buildContactAjaxUrl((int) $moduleId);
        $guard   = self::contactSignTimestamp((int) $moduleId);
        $fieldId = 'jlb-c-' . (int) $moduleId;

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--contact" style="--jssocial-accent: #6366F1;"
             data-contact-form="1"
             data-contact-url="<?php echo htmlspecialchars($ajaxUrl); ?>"
             data-contact-success="<?php echo htmlspecialchars($successMsg); ?>">
            <div class="jssocial_contact">
                <?php echo self::renderContactMap($params); ?>
                <?php echo self::renderContactDetails($params); ?>
                <?php if ($intro !== '') : ?>
                    <p class="jssocial_contact_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>

                <div class="jssocial_contact_alert" role="alert" aria-live="polite" hidden></div>

                <form class="jssocial_contact_form" method="post" action="<?php echo htmlspecialchars($ajaxUrl); ?>" novalidate>
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="module_id" value="<?php echo (int) $moduleId; ?>" />
                    <input type="hidden" name="contact_ts" value="<?php echo (int) $guard['ts']; ?>" />
                    <input type="hidden" name="contact_sig" value="<?php echo htmlspecialchars($guard['sig']); ?>" />

                    <div class="jssocial_contact_field">
                        <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-name">Name <span class="jssocial_contact_req">*</span></label>
                        <input class="jssocial_contact_input" id="<?php echo $fieldId; ?>-name" type="text" name="name" required maxlength="120" autocomplete="name" placeholder="Your name" />
                    </div>

                    <div class="jssocial_contact_field">
                        <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-email">Email <span class="jssocial_contact_req">*</span></label>
                        <input class="jssocial_contact_input" id="<?php echo $fieldId; ?>-email" type="email" name="email" required maxlength="200" autocomplete="email" placeholder="you@example.com" />
                    </div>

                    <?php if ($showPhone) : ?>
                        <div class="jssocial_contact_field">
                            <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-phone">Phone</label>
                            <input class="jssocial_contact_input" id="<?php echo $fieldId; ?>-phone" type="tel" name="phone" maxlength="40" autocomplete="tel" placeholder="+48 123 456 789" />
                        </div>
                    <?php endif; ?>

                    <div class="jssocial_contact_field">
                        <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-message">Message <span class="jssocial_contact_req">*</span></label>
                        <textarea class="jssocial_contact_input jssocial_contact_textarea" id="<?php echo $fieldId; ?>-message" name="message" rows="4" required maxlength="5000" placeholder="How can we help?"></textarea>
                    </div>

                    <div class="jssocial_contact_hp" aria-hidden="true">
                        <input type="text" name="contact_hp_a" tabindex="-1" autocomplete="new-password" inputmode="none" value="" />
                    </div>
                    <div class="jssocial_contact_hp" aria-hidden="true">
                        <input type="text" name="contact_hp_b" tabindex="-1" autocomplete="new-password" inputmode="none" value="" />
                    </div>

                    <button type="submit" class="jssocial_contact_submit">
                        <span class="jssocial_contact_submit_icon" aria-hidden="true"><i class="fas fa-paper-plane"></i></span>
                        <span class="jssocial_contact_submit_text"><?php echo htmlspecialchars($submitLabel); ?></span>
                        <span class="jssocial_contact_submit_loading" hidden><i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Sending…</span>
                    </button>
                </form>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function renderTestimonials(array $items, $theme, $params = null)
    {
        $theme = self::normalizeTheme($theme);
        $intro = '';
        $showSummary = true;

        if ($params instanceof Registry) {
            $intro = trim((string) $params->get('testimonials_intro', ''));
            $showSummary = (int) $params->get('testimonials_show_summary', 1) === 1;
        }

        $stats = self::testimonialStats($items);

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--testimonials" style="--jssocial-accent: #F59E0B;">
            <div class="jssocial_testimonials">
                <?php if ($showSummary && $stats['rated_count'] > 0) : ?>
                    <div class="jssocial_testimonials_summary">
                        <div class="jssocial_testimonials_score">
                            <span class="jssocial_testimonials_score_value"><?php echo number_format($stats['average'], 1); ?></span>
                            <div class="jssocial_testimonials_score_stars" aria-label="<?php echo number_format($stats['average'], 1); ?> out of 5 stars">
                                <?php echo self::renderStarRating((int) round($stats['average'])); ?>
                            </div>
                        </div>
                        <div class="jssocial_testimonials_score_meta">
                            <strong><?php echo (int) $stats['count']; ?> review<?php echo $stats['count'] === 1 ? '' : 's'; ?></strong>
                            <span>Curated customer feedback</span>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($intro !== '') : ?>
                    <p class="jssocial_testimonials_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>

                <div class="jssocial_testimonials_list">
                <?php foreach ($items as $item) : ?>
                    <article class="jssocial_testimonial<?php echo !empty($item['featured']) ? ' jssocial_testimonial--featured' : ''; ?>">
                        <div class="jssocial_testimonial_top">
                            <?php if ((int) $item['rating'] > 0) : ?>
                                <div class="jssocial_testimonial_stars" aria-label="<?php echo (int) $item['rating']; ?> out of 5 stars">
                                    <?php echo self::renderStarRating((int) $item['rating']); ?>
                                </div>
                            <?php endif; ?>
                            <span class="jssocial_testimonial_source">
                                <i class="<?php echo self::testimonialSourceIcon($item['source']); ?>" aria-hidden="true"></i>
                                <?php echo htmlspecialchars(self::testimonialSourceLabel($item['source'])); ?>
                            </span>
                        </div>

                        <?php if ($item['quote'] !== '') : ?>
                            <blockquote class="jssocial_testimonial_quote">
                                <span class="jssocial_testimonial_quote_mark" aria-hidden="true">“</span>
                                <?php echo nl2br(htmlspecialchars($item['quote'])); ?>
                            </blockquote>
                        <?php endif; ?>

                        <div class="jssocial_testimonial_author">
                            <?php echo self::renderTestimonialAvatar($item['name'], $item['avatar']); ?>
                            <div class="jssocial_testimonial_author_meta">
                                <?php if ($item['name'] !== '') : ?>
                                    <div class="jssocial_testimonial_name"><?php echo htmlspecialchars($item['name']); ?></div>
                                <?php endif; ?>
                                <?php if ($item['company'] !== '') : ?>
                                    <div class="jssocial_testimonial_company"><?php echo htmlspecialchars($item['company']); ?></div>
                                <?php endif; ?>
                                <?php if ($item['date'] !== '') : ?>
                                    <div class="jssocial_testimonial_date"><?php echo htmlspecialchars($item['date']); ?></div>
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($item['featured'])) : ?>
                                <span class="jssocial_testimonial_featured">Featured</span>
                            <?php endif; ?>
                        </div>

                        <?php if ($item['link'] !== '') : ?>
                            <a class="jssocial_testimonial_link" href="<?php echo htmlspecialchars($item['link']); ?>" target="_blank" rel="noopener noreferrer">
                                View original review <i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i>
                            </a>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function renderStarRating($rating)
    {
        $rating = max(0, min(5, (int) $rating));
        $out    = '';
        for ($i = 1; $i <= 5; $i++) {
            $out .= '<i class="fas fa-star' . ($i <= $rating ? '' : ' jssocial_star--off') . '"></i>';
        }

        return $out;
    }

    /** Whether the jsns.eu plan tier should show the free-tier branding footer. */
    public static function isFreePlan($plan)
    {
        return strtolower(trim((string) $plan)) === 'free';
    }

    /** Small “Designed by jsns.eu” bar below the limit warning (free plan). */
    public static function renderBranding()
    {
        ob_start();
        ?>
        <div class="jssocial_branding">
            Designed with <span class="jssocial_branding__heart" aria-hidden="true">&#10084;</span> by
            <a href="https://jsns.eu" target="_blank" rel="noopener">jsns.eu</a>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Fetch the meta block (usage, limits, beacon token) from the API.
     * Cheap on the API side (no paid provider call), so it runs every request.
     *
     * @return array|null  The 'meta' array, or null when the key/API is invalid.
     */
    public static function getStatus($apiUrl, $apiKey, $widgetId)
    {
        $result = self::fetchStatus($apiUrl, $apiKey, $widgetId);

        return $result['ok'] ? $result['meta'] : null;
    }

    /**
     * Fetch status with HTTP/error details (module admin + clearer frontend messages).
     *
     * @return array{ok:bool,meta:?array,plan:?string,http_code:int,error:?string,message:?string}
     */
    public static function fetchStatus($apiUrl, $apiKey, $widgetId)
    {
        $empty = array(
            'ok'        => false,
            'meta'      => null,
            'plan'      => null,
            'http_code' => 0,
            'error'     => null,
            'message'   => null,
        );

        $apiKey = trim((string) $apiKey);
        if ($apiKey === '') {
            $empty['message'] = 'missing_api_key';
            return $empty;
        }

        $response = self::apiRequest($apiUrl, $apiKey, 'status', array('widget_id' => $widgetId), 8);
        $empty['http_code'] = $response['http_code'];
        $empty['error']     = $response['error'];

        $json = $response['json'];
        if ($response['http_code'] === 200 && is_array($json) && !empty($json['success']) && isset($json['meta']) && is_array($json['meta'])) {
            return array(
                'ok'        => true,
                'meta'      => $json['meta'],
                'plan'      => isset($json['plan']) ? (string) $json['plan'] : null,
                'user_id'   => isset($json['user_id']) ? (int) $json['user_id'] : 0,
                'http_code' => 200,
                'error'     => null,
                'message'   => null,
            );
        }

        if (is_array($json)) {
            if (!empty($json['error'])) {
                $empty['message'] = (string) $json['error'];
            } elseif (!empty($json['message'])) {
                $empty['message'] = (string) $json['message'];
            }
        }

        return $empty;
    }

    /** Usage panel HTML for the module admin screen. */
    public static function renderAdminUsageHtml(array $status, $upgradeUrl = null)
    {
        $upgradeUrl = trim((string) ($upgradeUrl ?? self::UPGRADE_URL));
        if ($upgradeUrl === '') {
            $upgradeUrl = self::UPGRADE_URL;
        }

        if (!empty($status['message']) && $status['message'] === 'missing_api_key') {
            return '<div class="alert alert-info" style="margin:0;">Enter your API key above and save to see monthly usage.</div>';
        }

        if (empty($status['ok'])) {
            $msg = 'Could not load usage from the API.';
            if ((int) $status['http_code'] === 401) {
                $msg = 'Invalid or inactive API key. Generate a key in your jsns.eu dashboard.';
            } elseif (!empty($status['message'])) {
                $msg = htmlspecialchars($status['message'], ENT_QUOTES, 'UTF-8');
            } elseif (!empty($status['error'])) {
                $msg = 'Connection error: ' . htmlspecialchars($status['error'], ENT_QUOTES, 'UTF-8');
            } elseif ((int) $status['http_code'] > 0) {
                $msg = 'API returned HTTP ' . (int) $status['http_code'] . '.';
            }

            return '<div class="alert alert-warning" style="margin:0;">' . $msg
                . ' <a href="' . htmlspecialchars(self::DASHBOARD_URL, ENT_QUOTES) . '" target="_blank" rel="noopener">Open API keys dashboard</a></div>';
        }

        $meta         = is_array($status['meta']) ? $status['meta'] : array();
        $viewsUsed    = isset($meta['views_used']) ? (int) $meta['views_used'] : 0;
        $viewLimit    = isset($meta['view_limit']) ? (int) $meta['view_limit'] : 0;
        $widgetsUsed  = isset($meta['widgets_used']) ? (int) $meta['widgets_used'] : 0;
        $widgetLimit  = isset($meta['widget_limit']) ? (int) $meta['widget_limit'] : 0;
        $overLimit    = !empty($meta['over_limit']);
        $widgetDenied = empty($meta['widget_allowed']);
        $viewPct      = $viewLimit > 0 ? min(100, (int) round($viewsUsed / $viewLimit * 100)) : 0;
        $widgetPct    = $widgetLimit > 0 ? min(100, (int) round($widgetsUsed / $widgetLimit * 100)) : 0;
        $viewColor    = $overLimit ? '#d9534f' : ($viewPct >= 85 ? '#f0ad4e' : '#5cb85c');
        $plan         = isset($status['plan']) && $status['plan'] !== '' ? htmlspecialchars($status['plan'], ENT_QUOTES, 'UTF-8') : '';
        $userId       = isset($status['user_id']) && (int) $status['user_id'] > 0 ? (int) $status['user_id'] : 0;

        ob_start();
        ?>
        <div class="jslikebox-admin-usage" style="max-width:520px;padding:12px 14px;border:1px solid #ccd0d4;border-radius:4px;background:#fff;color:#212529;">
            <?php if ($userId > 0) : ?>
                <p style="margin:0 0 10px;color:#212529;"><strong style="color:#212529;">Account ID:</strong> <?php echo $userId; ?> <span style="color:#6c757d;font-size:12px;">(from your API key)</span></p>
            <?php endif; ?>
            <?php if ($plan !== '') : ?>
                <p style="margin:0 0 10px;color:#212529;"><strong style="color:#212529;">Plan:</strong> <?php echo $plan; ?></p>
            <?php endif; ?>

            <p style="margin:0 0 6px;font-size:13px;color:#212529;"><strong style="color:#212529;">Monthly views</strong> — <?php echo number_format($viewsUsed); ?> / <?php echo number_format($viewLimit); ?></p>
            <div style="background:#e9ecef;height:18px;border-radius:4px;overflow:hidden;margin-bottom:12px;">
                <div style="width:<?php echo $viewPct; ?>%;height:100%;background:<?php echo $viewColor; ?>;"></div>
            </div>

            <p style="margin:0 0 6px;font-size:13px;color:#212529;"><strong style="color:#212529;">Widgets</strong> — <?php echo (int) $widgetsUsed; ?> / <?php echo (int) $widgetLimit; ?></p>
            <div style="background:#e9ecef;height:18px;border-radius:4px;overflow:hidden;margin-bottom:12px;">
                <div style="width:<?php echo $widgetPct; ?>%;height:100%;background:#5bc0de;"></div>
            </div>

            <?php if ($overLimit) : ?>
                <div class="alert alert-warning" style="margin:0 0 10px;padding:8px 10px;">
                    You have reached your monthly view limit. Feeds keep showing cached data.
                </div>
            <?php endif; ?>

            <?php if ($widgetDenied) : ?>
                <div class="alert alert-warning" style="margin:0 0 10px;padding:8px 10px;">
                    This module exceeds your plan&rsquo;s widget limit and will not render on the site.
                </div>
            <?php endif; ?>

            <p style="margin:0;font-size:13px;color:#212529;">
                <a href="<?php echo htmlspecialchars($upgradeUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" style="color:#0d6efd;"><strong style="color:#0d6efd;">Upgrade your plan on jsns.eu</strong></a>
                to increase limits or manage API keys.
            </p>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Frontend notice shown inside the feed panel when the monthly view limit
     * is reached and cached posts are displayed.
     */
    public static function renderOverLimitNotice($theme = 'light')
    {
        $dark  = self::isDarkFeedTheme($theme);
        $class = 'social_feed_overlimit' . ($dark ? ' social_feed_overlimit--dark' : '');

        ob_start();
        ?>
        <div class="<?php echo $class; ?>" role="status">
            <p class="social_feed_overlimit__title">Monthly view limit reached</p>
            <p class="social_feed_overlimit__text">Showing cached posts. <a href="<?php echo htmlspecialchars(self::UPGRADE_URL); ?>" target="_blank" rel="noopener">Upgrade your plan</a></p>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Fetch a normalized feed ({profile, posts}) for a platform, with a disk
     * cache and stale fallback.
     *
     * @return array|null  {platform, profile, posts} or null when unavailable.
     */
    public static function getFeed($apiUrl, $apiKey, $platform, $identifier, $widgetId, $limit = 12, $accountType = '')
    {
        $identifier = trim((string) $identifier);
        $cfg = self::getPlatform($platform);
        if ($identifier === '' || $cfg === null) {
            return null;
        }

        if ($platform === 'linkedin') {
            $accountType = ($accountType === 'profile') ? 'profile' : 'company';
            $identifier   = self::normalizeLinkedInIdentifier($identifier, $accountType);
            if ($identifier === '') {
                return null;
            }
        }

        if ($platform === 'pinterest') {
            $accountType = ($accountType === 'board') ? 'board' : 'profile';
            $identifier  = self::normalizePinterestIdentifier($identifier, $accountType);
            if ($identifier === '') {
                return null;
            }
        }

        $cacheDir  = JPATH_CACHE . '/mod_js_like_box_pro';
        $cacheVer  = ($platform === 'linkedin') ? '_v10' : (($platform === 'twitter' || $platform === 'facebook') ? '_v5' : (($platform === 'telegram') ? '_v3' : (($platform === 'tiktok') ? '_v2' : (($platform === 'pinterest') ? '_v3' : '_v3'))));
        $cacheFile = $cacheDir . '/' . $platform . $cacheVer . '_' . md5(strtolower($identifier)) . '.json';

        if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < self::FEED_TTL) {
            $cached = json_decode(file_get_contents($cacheFile), true);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $query = array(
            $cfg['api_param'] => ($platform === 'twitter' || $platform === 'tiktok') ? ltrim($identifier, '@') : $identifier,
            'widget_id'       => $widgetId,
            'limit'           => (int) $limit,
        );
        if ($platform === 'linkedin') {
            $query['type'] = $accountType;
        }
        if ($platform === 'pinterest') {
            $query['type'] = $accountType;
        }

        $json = self::apiCall($apiUrl, $apiKey, $cfg['endpoint'], $query, 8);
        $data = (is_array($json) && isset($json['data']) && is_array($json['data'])) ? $json['data'] : null;

        if (is_array($data) && self::feedHasContent($platform, $data)) {
            if (!is_dir($cacheDir)) {
                @mkdir($cacheDir, 0755, true);
            }
            @file_put_contents($cacheFile, json_encode($data));
            return $data;
        }

        // Fetch failed or warming up: serve the last successful data.
        if (is_file($cacheFile)) {
            $stale = json_decode(file_get_contents($cacheFile), true);
            if (is_array($stale)) {
                return $stale;
            }
        }

        return is_array($data) ? $data : null;
    }

    /** True when a feed response is worth caching and rendering. */
    private static function feedHasContent($platform, array $data)
    {
        if (!empty($data['posts']) && is_array($data['posts'])) {
            return true;
        }

        if (!in_array($platform, array('linkedin', 'pinterest', 'telegram'), true) || empty($data['profile']) || !is_array($data['profile'])) {
            return false;
        }

        $profile = $data['profile'];
        $name    = trim((string) ($profile['display_name'] ?? ''));
        $avatar  = trim((string) ($profile['avatar'] ?? ''));
        $bio     = trim((string) ($profile['bio'] ?? ''));
        $handle  = trim((string) ($profile['username'] ?? ''));

        return $avatar !== '' || $bio !== '' || ($name !== '' && $name !== $handle);
    }

    /**
     * Perform an authenticated GET against the Like Box API.
     *
     * @return array|null  Decoded JSON, or null on failure.
     */
    private static function apiCall($apiUrl, $apiKey, $path, array $query, $timeout)
    {
        $response = self::apiRequest($apiUrl, $apiKey, $path, $query, $timeout);

        if ($response['http_code'] !== 200 || !is_array($response['json'])) {
            return null;
        }

        return $response['json'];
    }

    /**
     * @return array{http_code:int,json:?array,error:?string}
     */
    private static function apiRequest($apiUrl, $apiKey, $path, array $query, $timeout)
    {
        $result = array(
            'http_code' => 0,
            'json'      => null,
            'error'     => null,
        );

        $apiUrl = trim((string) $apiUrl);
        $apiKey = trim((string) $apiKey);
        if ($apiUrl === '' || $apiKey === '') {
            return $result;
        }

        $endpoint = rtrim($apiUrl, '/') . '/' . ltrim($path, '/');
        $endpoint .= (strpos($endpoint, '?') === false ? '?' : '&') . http_build_query($query);

        if (!function_exists('curl_init')) {
            $result['error'] = 'curl extension unavailable';
            return $result;
        }

        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => (int) $timeout,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_HTTPHEADER     => array(
                'X-API-Key: ' . $apiKey,
                'User-Agent: JSLikeBoxPro/4.0',
            ),
        ));

        $response = curl_exec($ch);
        $code     = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        $result['http_code'] = $code;

        if ($response === false) {
            $result['error'] = $curlErr !== '' ? $curlErr : 'request failed';
            return $result;
        }

        $json = json_decode($response, true);
        $result['json'] = is_array($json) ? $json : null;

        return $result;
    }

    /**
     * Render a feed tab (profile header + posts) for any platform.
     *
     * @param   string      $platform     instagram|twitter|facebook|youtube
     * @param   array|null  $data         Feed data from getFeed().
     * @param   string      $fallbackUrl  Profile URL for the follow button.
     * @param   string      $identifier   Raw identifier (fallback label).
     * @param   int         $columns      Grid columns (Instagram only).
     *
     * @return  string  HTML markup.
     */
    public static function renderFeed($platform, $data, $fallbackUrl, $identifier, $columns = 2, $apiUrl = '', $theme = 'light')
    {
        $isX  = ($platform === 'twitter' || $platform === 'x');
        $isYt = ($platform === 'youtube');

        $profile = (is_array($data) && isset($data['profile']) && is_array($data['profile'])) ? $data['profile'] : array();
        $posts   = (is_array($data) && isset($data['posts']) && is_array($data['posts'])) ? $data['posts'] : array();

        $username  = (isset($profile['username']) && $profile['username'] !== '') ? $profile['username'] : (string) $identifier;
        $name      = (isset($profile['display_name']) && $profile['display_name'] !== '') ? $profile['display_name'] : $username;
        $handle    = $username;
        $avatar    = self::proxied($apiUrl, self::normalizeAvatarUrl(isset($profile['avatar']) ? (string) $profile['avatar'] : ''));
        $cover     = self::resolveCover($apiUrl, $platform, $profile, $posts);
        $followers = (int) ($profile['followers'] ?? $profile['followerCount'] ?? 0);
        $verified  = self::isProfileVerified($profile);
        $profUrl   = isset($profile['url']) && $profile['url'] !== '' ? $profile['url'] : $fallbackUrl;

        $following   = isset($profile['following']) ? (int) $profile['following'] : 0;
        $connections = (int) ($profile['connections'] ?? $profile['connectionsCount'] ?? 0);
        if ($connections === 0 && $platform === 'linkedin') {
            $connections = $following;
        }
        $postsNum  = isset($profile['posts_count']) ? (int) $profile['posts_count'] : 0;
        if ($postsNum === 0 && !empty($posts)) {
            $postsNum = count($posts);
        }
        $profViews = isset($profile['views']) ? (int) $profile['views'] : 0;
        $bio       = self::formatProfileBio(isset($profile['bio']) ? (string) $profile['bio'] : '', $name, $handle);

        $meta  = self::platformMeta($platform);
        $theme = self::normalizeTheme($theme);

        // Stat cells shown under the name (value, label) - zeros are skipped.
        $stats = self::profileStats($platform, $postsNum, $followers, $following, $profViews, $connections);

        // Shared context passed to the per-post renderers.
        $ctx = array(
            'apiUrl'     => $apiUrl,
            'avatar'     => $avatar,
            'handle'     => $handle,
            'profileUrl' => $profUrl,
            'meta'       => $meta,
            'platform'   => $platform,
            'isX'        => $isX,
            'verified'   => $verified,
        );

        $isIg = ($platform === 'instagram');
        $hasProfile = ($avatar !== '' || $bio !== '' || ($name !== '' && $name !== $handle) || $followers > 0 || $connections > 0 || $following > 0);

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--<?php echo htmlspecialchars($platform); ?>" style="--jssocial-accent: <?php echo $meta['accent']; ?>;">
            <div class="jssocial_profile">
                <?php if ($cover !== '') : ?>
                <div class="jssocial_cover jssocial_cover--img">
                    <?php echo self::lazyImg($cover, 'jssocial_cover_img', 'jssocial_imgwrap--cover', 'loading="eager" fetchpriority="high" decoding="async"'); ?>
                    <i class="fab <?php echo $meta['icon']; ?> jssocial_cover_badge"></i>
                </div>
                <?php elseif (!$isIg) : ?>
                <div class="jssocial_cover">
                    <i class="fab <?php echo $meta['icon']; ?> jssocial_cover_badge"></i>
                </div>
                <?php endif; ?>
                <div class="jssocial_profile_body<?php echo $cover !== '' ? ' jssocial_profile_body--cover' : ''; ?>">
                    <span class="jssocial_avatar_wrap">
                        <?php if ($avatar !== '') : ?>
                            <?php echo self::lazyImg($avatar, 'jssocial_avatar', 'jssocial_imgwrap--round jssocial_imgwrap--avatar'); ?>
                        <?php else : ?>
                            <span class="jssocial_avatar jssocial_avatar--ph"><i class="fab <?php echo $meta['icon']; ?>"></i></span>
                        <?php endif; ?>
                    </span>
                    <div class="jssocial_ident">
                        <div class="jssocial_name">
                            <a href="<?php echo htmlspecialchars($profUrl); ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($name); ?></a>
                            <?php echo self::verifiedBadge($verified, $platform); ?>
                        </div>
                        <?php if ($handle !== '') : ?>
                            <div class="jssocial_handle"><?php echo htmlspecialchars(self::formatHandle($platform, $handle)); ?></div>
                        <?php endif; ?>
                        <?php if ($bio !== '') : ?>
                            <div class="jssocial_tagline"><?php echo htmlspecialchars($bio); ?></div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($stats)) : ?>
                        <div class="jssocial_stats">
                            <?php foreach ($stats as $st) : ?>
                                <span class="jssocial_statcell">
                                    <b><?php echo htmlspecialchars(self::formatCount($st[0])); ?></b>
                                    <small><?php echo htmlspecialchars($st[1]); ?></small>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <a class="jssocial_action" href="<?php echo htmlspecialchars($profUrl); ?>" target="_blank" rel="noopener">
                        <i class="fab <?php echo $meta['icon']; ?>"></i> <?php echo htmlspecialchars($meta['button']); ?>
                    </a>
                </div>
            </div>

            <?php if (!empty($posts) && $isYt) : ?>
                <?php echo self::renderYouTubeList($posts, $ctx); ?>
            <?php elseif (!empty($posts)) : ?>
                <?php echo self::renderPostList($posts, $ctx); ?>
            <?php elseif ($hasProfile) : ?>
                <div class="jssocial_empty">
                    <p>No public posts to show right now.</p>
                </div>
            <?php else : ?>
                <div class="jssocial_empty">
                    <p>Latest posts are loading&hellip; check back in a moment, or visit the profile.</p>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Build the (value, label) stat cells for a platform, skipping zeros. */
    private static function profileStats($platform, $posts, $followers, $following, $profileViews = 0, $connections = 0)
    {
        switch ($platform) {
            case 'instagram':
                $cells = array(array($posts, 'Posts'), array($followers, 'Followers'), array($following, 'Following'));
                break;
            case 'twitter':
            case 'x':
                $cells = array(array($posts, 'Posts'), array($following, 'Following'), array($followers, 'Followers'));
                break;
            case 'youtube':
                $cells = array(
                    array($followers, 'Subscribers'),
                    array($posts, 'Videos'),
                    array($profileViews, 'Views'),
                );
                break;
            case 'linkedin':
                $cells = array(array($posts, 'Posts'));
                if ($followers > 0) {
                    $cells[] = array($followers, 'Followers');
                }
                if ($connections > 0) {
                    $cells[] = array($connections, 'Connections');
                }
                break;
            case 'tiktok':
                $cells = array(
                    array($posts, 'Videos'),
                    array($followers, 'Followers'),
                    array($following, 'Following'),
                );
                break;
            case 'pinterest':
                $cells = array(array($posts, 'Pins'), array($followers, 'Followers'));
                if ($following > 0) {
                    $cells[] = array($following, 'Following');
                }
                break;
            case 'telegram':
                $cells = array(array($followers, 'Subscribers'), array($posts, 'Posts'));
                break;
            case 'facebook':
            default:
                $cells = array(array($followers, 'Likes'));
                break;
        }

        $out = array();
        foreach ($cells as $c) {
            if ((int) $c[0] > 0) {
                $out[] = $c;
            }
        }
        return $out;
    }

    /** Rich post cards (image, caption, author row, actions) matching the design. */
    private static function renderPostList(array $posts, array $ctx)
    {
        $meta     = $ctx['meta'];
        $avatar   = (string) $ctx['avatar'];
        $handle   = (string) $ctx['handle'];
        $platform = isset($ctx['platform']) ? (string) $ctx['platform'] : '';
        $verified = !empty($ctx['verified']);

        ob_start();
        ?>
        <div class="jssocial_posts">
            <?php foreach ($posts as $post) : ?>
                <?php
                    $postPlatform = isset($post['_platform']) ? (string) $post['_platform'] : $platform;
                    $postMeta     = ($postPlatform !== '' && $postPlatform !== $platform)
                        ? self::platformMeta($postPlatform)
                        : $meta;
                    $postCtx      = $ctx;
                    $postCtx['platform'] = $postPlatform;
                    $postCtx['meta']     = $postMeta;
                    $postCtx['isX']      = ($postPlatform === 'twitter' || $postPlatform === 'x');

                    if ($postPlatform !== $platform && !empty($ctx['profiles'][$postPlatform]) && is_array($ctx['profiles'][$postPlatform])) {
                        $prof = $ctx['profiles'][$postPlatform];
                        $postCtx['avatar']     = self::proxied($ctx['apiUrl'], self::normalizeAvatarUrl(isset($prof['avatar']) ? (string) $prof['avatar'] : ''));
                        $postCtx['handle']     = (isset($prof['username']) && $prof['username'] !== '') ? (string) $prof['username'] : '';
                        $postCtx['profileUrl'] = isset($prof['url']) && $prof['url'] !== '' ? (string) $prof['url'] : self::buildProfileUrl($postPlatform, $postCtx['handle']);
                        $postCtx['verified']   = self::isProfileVerified($prof);
                    }

                    $cardAvatar   = (string) $postCtx['avatar'];
                    $cardHandle   = (string) $postCtx['handle'];
                    $cardProfUrl  = (string) $postCtx['profileUrl'];
                    $cardVerified = !empty($postCtx['verified']);
                    $cardMeta     = $postCtx['meta'];

                    $purl    = isset($post['url']) && $post['url'] !== '' ? $post['url'] : $cardProfUrl;
                    $caption = isset($post['caption']) ? (string) $post['caption'] : '';
                    $image   = self::proxied($ctx['apiUrl'], isset($post['image']) ? (string) $post['image'] : '');
                    $created = isset($post['created_at']) ? (string) $post['created_at'] : '';
                ?>
                <article class="jssocial_card">
                    <?php if ($image !== '') : ?>
                        <a class="jssocial_card_media" href="<?php echo htmlspecialchars($purl); ?>" target="_blank" rel="noopener">
                            <?php echo self::lazyImg($image); ?>
                        </a>
                    <?php endif; ?>

                    <div class="jssocial_card_body">
                        <?php if ($caption !== '') : ?>
                            <a class="jssocial_card_caption" href="<?php echo htmlspecialchars($purl); ?>" target="_blank" rel="noopener"><?php echo nl2br(htmlspecialchars($caption)); ?></a>
                        <?php endif; ?>

                        <div class="jssocial_card_author">
                            <?php if ($cardAvatar !== '') : ?>
                                <?php echo self::lazyImg($cardAvatar, 'jssocial_card_avatar', 'jssocial_imgwrap--round jssocial_imgwrap--avatar-sm'); ?>
                            <?php endif; ?>
                            <div class="jssocial_card_authinfo">
                                <span class="jssocial_card_namerow">
                                    <a class="jssocial_card_name" href="<?php echo htmlspecialchars($cardProfUrl); ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars(self::formatHandle($postPlatform, $cardHandle)); ?></a>
                                    <?php echo self::verifiedBadge($cardVerified, $postPlatform); ?>
                                </span>
                                <?php if ($created !== '') : ?><span class="jssocial_card_date"><?php echo htmlspecialchars(self::formatDate($created)); ?></span><?php endif; ?>
                            </div>
                            <i class="fab <?php echo $cardMeta['icon']; ?> jssocial_card_platform"></i>
                        </div>

                        <?php echo self::renderPostActions($post, $postCtx, $purl); ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Platform-specific engagement row under each post card. */
    private static function renderPostActions(array $post, array $ctx, $purl)
    {
        $platform = isset($ctx['platform']) ? (string) $ctx['platform'] : '';
        $isX      = !empty($ctx['isX']);
        $likes    = isset($post['likes']) ? (int) $post['likes'] : 0;
        $comments = isset($post['comments']) ? (int) $post['comments'] : 0;
        $shares   = isset($post['shares']) ? (int) $post['shares'] : 0;

        ob_start();

        if ($platform === 'facebook') {
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--facebook">
                <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <?php if ($shares > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('share'); ?> <?php echo self::formatCount($shares); ?></span>
                <?php endif; ?>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($isX) {
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--x">
                <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('retweet'); ?> <?php echo self::formatCount($shares); ?></span>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($platform === 'youtube') {
            $views = self::ytCount($post, array('views', 'viewCount', 'viewsCount'));
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--youtube">
                <?php if ($views > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('views'); ?> <?php echo self::formatCount($views); ?></span>
                <?php endif; ?>
                <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($platform === 'pinterest') {
            $saves = isset($post['saves']) ? (int) $post['saves'] : 0;
            if ($saves <= 0 && $likes > 0) {
                $saves = $likes;
            }
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--pinterest">
                <?php if ($saves > 0) : ?>
                    <span class="jssocial_stat" title="Saves"><?php echo self::icon('save'); ?> <?php echo self::formatCount($saves); ?></span>
                <?php endif; ?>
                <?php if ($comments > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <?php endif; ?>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($platform === 'telegram') {
            $views = isset($post['views']) ? (int) $post['views'] : 0;
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--telegram">
                <?php if ($views > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('views'); ?> <?php echo self::formatCount($views); ?></span>
                <?php endif; ?>
                <?php if ($likes > 0) : ?>
                    <span class="jssocial_stat" title="Reactions"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <?php endif; ?>
                <?php if ($shares > 0) : ?>
                    <span class="jssocial_stat" title="Forwards"><?php echo self::icon('share'); ?> <?php echo self::formatCount($shares); ?></span>
                <?php endif; ?>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        ?>
        <div class="jssocial_card_actions">
            <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
            <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
            <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Normalise theme param (legacy aliases → current values). */
    public static function normalizeTheme($theme)
    {
        $theme = (string) $theme;
        if ($theme === 'fintech') {
            $theme = 'rounded_light';
        }
        if ($theme === 'rounded') {
            $theme = 'rounded_dark';
        }
        $allowed = array('light', 'dark', 'rounded_light', 'rounded_dark', 'minimal', 'warm', 'neon');
        return in_array($theme, $allowed, true) ? $theme : 'rounded_dark';
    }

    /** Whether the theme uses a dark feed background. */
    public static function isDarkFeedTheme($theme)
    {
        $theme = self::normalizeTheme($theme);
        return in_array($theme, array('dark', 'rounded_dark', 'neon'), true);
    }

    /** Whether the theme uses rounded cards + DM Sans styling. */
    public static function isRoundedTheme($theme)
    {
        $theme = self::normalizeTheme($theme);
        return $theme === 'rounded_light' || $theme === 'rounded_dark';
    }

    /** Lazy-loaded image with shimmer placeholder. */
    private static function lazyImg($src, $class = '', $wrapClass = '', $extra = '')
    {
        $src = trim((string) $src);
        if ($src === '') {
            return '';
        }

        $imgClass = $class !== '' ? ' class="' . htmlspecialchars($class, ENT_QUOTES) . '"' : '';
        $wrapExtra = $wrapClass !== '' ? ' ' . htmlspecialchars($wrapClass, ENT_QUOTES) : '';

        ob_start();
        ?>
        <span class="jssocial_imgwrap<?php echo $wrapExtra; ?>">
            <span class="jssocial_imgloader" aria-hidden="true"></span>
            <img src="<?php echo htmlspecialchars($src, ENT_QUOTES); ?>" alt="" loading="lazy"<?php echo $imgClass; ?><?php echo $extra !== '' ? ' ' . $extra : ''; ?> />
        </span>
        <?php
        return ob_get_clean();
    }

    /** Share trigger + popup menu (Copy Link, Facebook, WhatsApp, etc.). */
    private static function renderSharePopup($url, $title = '')
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }

        $encoded = rawurlencode($url);
        $title   = trim((string) $title);
        $text    = $title !== '' ? rawurlencode($title . ' ' . $url) : $encoded;
        $subject = $title !== '' ? rawurlencode($title) : rawurlencode('Check this out');

        ob_start();
        ?>
        <span class="jssocial_share_wrap">
            <button type="button" class="jssocial_share" aria-expanded="false" aria-haspopup="true" data-url="<?php echo htmlspecialchars($url, ENT_QUOTES); ?>">
                <?php echo self::icon('share'); ?> Share
            </button>
            <div class="jssocial_share_menu" role="menu" hidden>
                <button type="button" class="jssocial_share_item jssocial_share_item--copy" role="menuitem" data-url="<?php echo htmlspecialchars($url, ENT_QUOTES); ?>">
                    <span class="jssocial_share_item_label">Copy Link</span>
                    <i class="fas fa-link" aria-hidden="true"></i>
                </button>
                <div class="jssocial_share_divider" role="separator"></div>
                <a class="jssocial_share_item" role="menuitem" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $encoded; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on Facebook</span>
                    <i class="fab fa-facebook-f" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://wa.me/?text=<?php echo $text; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on WhatsApp</span>
                    <i class="fab fa-whatsapp" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://t.me/share/url?url=<?php echo $encoded; ?><?php echo $title !== '' ? '&text=' . rawurlencode($title) : ''; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on Telegram</span>
                    <i class="fab fa-telegram" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="mailto:?subject=<?php echo $subject; ?>&amp;body=<?php echo $text; ?>">
                    <span class="jssocial_share_item_label">Share via Email</span>
                    <i class="fas fa-envelope" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://twitter.com/intent/tweet?url=<?php echo $encoded; ?><?php echo $title !== '' ? '&text=' . rawurlencode($title) : ''; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on X</span>
                    <i class="fab fa-x-twitter" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $encoded; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on LinkedIn</span>
                    <i class="fab fa-linkedin-in" aria-hidden="true"></i>
                </a>
            </div>
        </span>
        <?php
        return ob_get_clean();
    }

    private static function renderYouTubeList(array $posts, array $ctx)
    {
        ob_start();
        ?>
        <div class="jssocial_posts">
            <?php foreach ($posts as $post) : ?>
                <?php
                    $purl        = isset($post['url']) && $post['url'] !== '' ? $post['url'] : $ctx['profileUrl'];
                    $title       = isset($post['caption']) ? trim((string) $post['caption']) : '';
                    $description = isset($post['description']) ? trim((string) $post['description']) : '';
                    $videoId     = isset($post['id']) ? trim((string) $post['id']) : '';
                    $image       = self::youtubeThumbnail($ctx['apiUrl'], isset($post['image']) ? (string) $post['image'] : '', $videoId);
                    $created     = isset($post['created_at']) ? (string) $post['created_at'] : '';
                    $ytTitle     = $title !== '' ? 'Watch on YouTube: ' . $title : 'Watch on YouTube';
                ?>
                <article class="jssocial_card jssocial_yt">
                    <?php if ($image !== '') : ?>
                        <a class="jssocial_yt_thumb" href="<?php echo htmlspecialchars($purl); ?>" target="_blank" rel="noopener">
                            <?php
                                $ytExtra = $videoId !== ''
                                    ? 'onerror="if(this.dataset.fbk)return;this.dataset.fbk=1;this.src=\'https://i.ytimg.com/vi/' . htmlspecialchars($videoId, ENT_QUOTES) . '/hqdefault.jpg\';"'
                                    : '';
                                echo self::lazyImg($image, '', '', $ytExtra);
                            ?>
                            <span class="jssocial_play"><?php echo self::icon('play'); ?></span>
                        </a>
                    <?php endif; ?>
                    <div class="jssocial_yt_info">
                        <?php if ($title !== '') : ?>
                            <a class="jssocial_yt_info_title" href="<?php echo htmlspecialchars($purl); ?>" title="<?php echo htmlspecialchars($ytTitle); ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($title); ?></a>
                        <?php endif; ?>
                        <?php if ($created !== '') : ?>
                            <div class="jssocial_yt_info_date"><?php echo htmlspecialchars(self::formatYouTubeDate($created)); ?></div>
                        <?php endif; ?>
                        <div class="jssocial_yt_info_caption"><?php
                            if ($description !== '' && $description !== $title) {
                                echo nl2br(htmlspecialchars(mb_strlen($description) > 220 ? mb_substr($description, 0, 220) . '…' : $description));
                            }
                        ?></div>
                        <?php echo self::renderPostActions($post, $ctx, $purl); ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Resolve a high-res YouTube thumbnail URL for display. */
    private static function youtubeThumbnail($apiUrl, $image, $videoId)
    {
        $image = trim((string) $image);
        if ($image === '' && $videoId !== '') {
            $image = 'https://i.ytimg.com/vi/' . $videoId . '/maxresdefault.jpg';
        } elseif ($image !== '' && preg_match('#(?:i\.)?ytimg\.com/vi/([a-zA-Z0-9_-]{11})/#', $image, $m)) {
            $image = 'https://i.ytimg.com/vi/' . $m[1] . '/maxresdefault.jpg';
        }

        return self::proxied($apiUrl, $image);
    }

    /** Read a numeric YouTube stat from normalized (or legacy) post fields. */
    private static function ytCount(array $post, array $keys)
    {
        foreach ($keys as $key) {
            if (!isset($post[$key]) || $post[$key] === '' || $post[$key] === null || is_array($post[$key])) {
                continue;
            }
            if (is_int($post[$key]) || is_float($post[$key])) {
                return (int) $post[$key];
            }
            $raw = trim((string) $post[$key]);
            if ($raw === '') {
                continue;
            }
            if (is_numeric(str_replace(',', '', $raw))) {
                return (int) str_replace(',', '', $raw);
            }
            if (preg_match('/^([\d,.]+)\s*([KMB])?/i', $raw, $m)) {
                $n = (float) str_replace(',', '', $m[1]);
                switch (strtoupper($m[2] ?? '')) {
                    case 'K':
                        return (int) round($n * 1000);
                    case 'M':
                        return (int) round($n * 1000000);
                    case 'B':
                        return (int) round($n * 1000000000);
                    default:
                        return (int) round($n);
                }
            }
        }

        return 0;
    }

    private static function formatYouTubeDate($raw)
    {
        $raw = trim((string) $raw);
        if ($raw === '') {
            return '';
        }
        $timestamp = is_numeric($raw) ? (int) $raw : strtotime($raw);
        return $timestamp ? date('j.n.Y', $timestamp) : $raw;
    }

    /** Tab/button accent colours — sourced from platforms(). */
    public static function platformTabColor($platform)
    {
        $cfg = self::getPlatform($platform);

        return $cfg !== null ? $cfg['accent'] : '#5e9ca0';
    }

    private static function platformMeta($platform)
    {
        $cfg = self::getPlatform($platform);
        if ($cfg === null) {
            return array('icon' => 'fa-link', 'accent' => '#5e9ca0', 'button' => 'Follow');
        }

        return array(
            'icon'   => $cfg['feed_icon'],
            'accent' => $cfg['accent'],
            'button' => $cfg['cta'],
        );
    }

    public static function formatDate($raw)
    {
        $raw = (string) $raw;
        if ($raw === '') {
            return '';
        }
        $timestamp = is_numeric($raw) ? (int) $raw : strtotime($raw);
        return $timestamp ? date('M j, Y', $timestamp) : '';
    }

    /** Profile cover from API; Instagram/LinkedIn may lack a native banner so use a post image fallback. */
    private static function resolveCover($apiUrl, $platform, array $profile, array $posts)
    {
        $cover = self::proxied($apiUrl, isset($profile['cover']) ? (string) $profile['cover'] : '');
        if ($cover !== '') {
            return $cover;
        }

        if (($platform === 'instagram' || $platform === 'linkedin' || $platform === 'tiktok' || $platform === 'pinterest' || $platform === 'telegram') && !empty($posts)) {
            $best     = '';
            $bestScore = 0;
            foreach ($posts as $post) {
                $img = isset($post['image']) ? trim((string) $post['image']) : '';
                if ($img === '') {
                    continue;
                }

                if ($platform === 'linkedin') {
                    $score = self::linkedInCoverImageScore($img);
                    if ($score > $bestScore) {
                        $bestScore = $score;
                        $best      = $img;
                    }
                    continue;
                }

                return self::proxied($apiUrl, $img);
            }

            if ($platform === 'linkedin' && $best !== '') {
                return self::proxied($apiUrl, $best);
            }
        }

        return '';
    }

    /** Prefer wide, high-resolution LinkedIn post images as cover fallbacks. */
    private static function linkedInCoverImageScore($url)
    {
        $url = (string) $url;
        if ($url === '') {
            return 0;
        }

        $score = 0;
        if (preg_match('~image-shrink_(\d+)_(\d+)~', $url, $m)) {
            $w = (int) $m[1];
            $h = (int) $m[2];
            $score = $w;
            if ($h > 0 && ($w / $h) >= 1.15) {
                $score += 500;
            }
        } elseif (preg_match('~image-shrink_(\d+)~', $url, $m)) {
            $score = (int) $m[1];
        }

        return $score;
    }

    /** Upscale avatar URLs when the CDN exposes size variants. */
    private static function normalizeAvatarUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return $url;
        }
        if (stripos($url, 'twimg.com') !== false) {
            $upgraded = preg_replace('#_(normal|bigger|mini)(\.)#', '_400x400$2', $url);
            return is_string($upgraded) && $upgraded !== '' ? $upgraded : $url;
        }
        if (stripos($url, 'googleusercontent.com') !== false) {
            $upgraded = preg_replace('#=s\d+(-c-k-c0x00ffffff-no-rj)?$#', '=s176-c-k-c0x00ffffff-no-rj', $url);
            if (!is_string($upgraded) || $upgraded === '') {
                $upgraded = preg_replace('#=s\d+#', '=s176', $url);
            }
            return is_string($upgraded) && $upgraded !== '' ? $upgraded : $url;
        }
        return $url;
    }

    /**
     * Route social-CDN image URLs through the API image proxy so the browser
     * never hotlinks Instagram/Facebook/X CDNs directly (they block hotlinking
     * and use short-lived signed URLs). Non-CDN URLs pass through untouched.
     *
     * Telegram (telesco.pe) allows direct hotlinking — skip the proxy to avoid
     * rate limits and expired URLs being cached behind a second hop.
     */
    public static function proxied($apiUrl, $url)
    {
        $url    = (string) $url;
        $apiUrl = trim((string) $apiUrl);

        if ($url === '' || $apiUrl === '' || strpos($url, 'proxy-image') !== false) {
            return $url;
        }

        $host = (string) parse_url($url, PHP_URL_HOST);
        if ($host === '') {
            return $url;
        }

        foreach (array('telesco.pe', 'telegram.org', 'telegram-cdn.org') as $cdn) {
            if (stripos($host, $cdn) !== false) {
                return $url;
            }
        }

        $cdns = array('cdninstagram.com', 'fbcdn.net', 'twimg.com', 'ytimg.com', 'ggpht.com', 'googleusercontent.com', 'licdn.com', 'media.licdn.com', 'tiktokcdn.com', 'tiktokcdn-eu.com', 'tiktokcdn-us.com', 'tiktokv.com', 'pinimg.com');
        foreach ($cdns as $cdn) {
            if (stripos($host, $cdn) !== false) {
                return rtrim($apiUrl, '/') . '/proxy-image?url=' . rawurlencode($url);
            }
        }

        return $url;
    }

    /** Short profile bio/tagline for the feed header; skips duplicates of the name/handle. */
    private static function formatProfileBio($bio, $name, $handle)
    {
        $bio = trim((string) $bio);
        if ($bio === '') {
            return '';
        }

        $name   = trim((string) $name);
        $handle = trim((string) $handle);
        if ($name !== '' && strcasecmp($bio, $name) === 0) {
            return '';
        }
        if ($handle !== '' && strcasecmp($bio, $handle) === 0) {
            return '';
        }
        if ($handle !== '' && strcasecmp($bio, '@' . ltrim($handle, '@')) === 0) {
            return '';
        }

        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($bio) > 120) {
                return rtrim(mb_substr($bio, 0, 117)) . '...';
            }
            return $bio;
        }

        if (strlen($bio) > 120) {
            return rtrim(substr($bio, 0, 117)) . '...';
        }

        return $bio;
    }

    /** @return string  @handle for YouTube/X/Instagram; plain for Facebook. */
    private static function formatHandle($platform, $handle)
    {
        $handle = trim((string) $handle);
        if ($handle === '') {
            return '';
        }
        if ($platform === 'youtube' || $platform === 'twitter' || $platform === 'x' || $platform === 'instagram' || $platform === 'tiktok' || $platform === 'telegram') {
            return '@' . ltrim($handle, '@');
        }

        return $handle;
    }

    /** Whether a normalized profile object is verified. */
    private static function isProfileVerified(array $profile)
    {
        if (!empty($profile['verified'])) {
            return true;
        }

        foreach (array('isVerified', 'is_verified', 'isBlueVerified', 'pageVerified', 'isChannelVerified', 'channelVerified') as $key) {
            if (!empty($profile[$key])) {
                return true;
            }
        }

        return false;
    }

    /** Verified badge markup beside the display name, or empty when not verified. */
    private static function verifiedBadge($verified, $platform = '')
    {
        if (empty($verified)) {
            return '';
        }

        $class = 'jssocial_verified';
        $slug  = preg_replace('/[^a-z0-9_-]/', '', (string) $platform);
        if ($slug !== '') {
            $class .= ' jssocial_verified--' . $slug;
        }

        return '<span class="' . $class . '" title="Verified" aria-label="Verified"><i class="fas fa-circle-check" aria-hidden="true"></i></span>';
    }

    /**
     * Inline SVG icons for post actions. These are embedded directly so the
     * like/comment/share glyphs always render, even when the site template
     * ships an old or partial FontAwesome build.
     */
    public static function icon($name)
    {
        $paths = array(
            'heart'   => '<path fill-rule="evenodd" d="M11.36 1.407A4.267 4.267 0 0 0 8.583 2.65l-.282.282-.283-.282a4.268 4.268 0 0 0-6.035 6.035l5.894 5.894a.6.6 0 0 0 .848 0l5.893-5.894A4.267 4.267 0 0 0 11.601 1.4l-.242.007ZM11.6 2.6a3.067 3.067 0 0 1 3.069 3.068l-.007.202a3.067 3.067 0 0 1-.892 1.967l-5.469 5.469-5.47-5.469A3.068 3.068 0 0 1 7.17 3.499l.707.706a.6.6 0 0 0 .848 0l.707-.706A3.067 3.067 0 0 1 11.6 2.6Z"/>',
            'save'    => '<path fill-rule="evenodd" d="M3.2 1.3a.6.6 0 0 0-.6.6v10.2l4.4-2.64 4.4 2.64V1.9a.6.6 0 0 0-.6-.6H3.2Zm1.2 1.2h5.2v7.28L8 7.22 4.4 9.78V2.5Z"/>',
            'like'    => '<path fill-rule="evenodd" d="M7.5 1.3a3.2 3.2 0 0 0-3.15 2.57l-.02.13-.45 2.38a.6.6 0 0 1-.59.49H1.8a1.2 1.2 0 0 0-1.2 1.2v3.6A1.2 1.2 0 0 0 1.8 12.7h5.34a1.8 1.8 0 0 0 1.74-1.34l.98-3.43.36-1.8a3.2 3.2 0 0 0-3.12-3.83Zm-.02 1.2a2 2 0 0 1 1.95 2.39l-.36 1.8-.98 3.43a.6.6 0 0 1-.58.45H1.8a.6.6 0 0 1-.6-.6V7.79a.6.6 0 0 1 .6-.6h1.49a1.8 1.8 0 0 0 1.77-1.47l.45-2.38A2 2 0 0 1 7.48 2.5ZM12.2 7.79v3.6a.6.6 0 0 1-.6.6h-1.8V7.19h1.8a.6.6 0 0 1 .6.6Z"/>',
            'comment' => '<path fill-rule="evenodd" d="M8.389.7h-.422a7.176 7.176 0 0 0-3.229.759A7.262 7.262 0 0 0 .7 7.965l.008.34c.04.908.254 1.8.627 2.628l.039.08-.66 3.419-.013.097c-.024.416.313.765.701.691l3.512-.667-.176-.082a7.264 7.264 0 0 0 9.714-3.233 7.172 7.172 0 0 0 .782-3.275v-.387C15.026 3.833 12.068.902 8.389.701Zm-.423 1.32h.378-.015c3.091.17 5.539 2.593 5.706 5.597l-.001.348a5.751 5.751 0 0 1-.63 2.63c-1.02 2.024-3.125 3.313-5.437 3.314a6.07 6.07 0 0 1-2.732-.64l-.084-.034a.547.547 0 0 0-.266-.016l-2.814.534.522-2.698a.719.719 0 0 0-.063-.46 5.75 5.75 0 0 1-.63-2.628c.001-2.236 1.284-4.29 3.333-5.305a6.072 6.072 0 0 1 2.733-.641Z"/>',
            'retweet' => '<path fill-rule="evenodd" d="M4.5 2.5 1.8 5.2l.7.7L4 4.4V10a2 2 0 0 0 2 2h4v-1.3H6a.7.7 0 0 1-.7-.7V4.4l1.5 1.5.7-.7L4.5 2.5Zm7 11 2.7-2.7-.7-.7L12 11.6V6a2 2 0 0 0-2-2H6v1.3h4a.7.7 0 0 1 .7.7v5.6L9.2 10.1l-.7.7 2.7 2.7Z"/>',
            'share'   => '<path fill-rule="evenodd" d="M11.5 1a2.5 2.5 0 0 0-2.46 2.99L5.7 5.86a2.5 2.5 0 1 0 0 4.28l3.34 1.87a2.5 2.5 0 1 0 .64-1.14L6.34 9a2.5 2.5 0 0 0 0-2L9.68 5.13A2.5 2.5 0 1 0 11.5 1Z"/>',
            'views'   => '<path fill-rule="evenodd" d="M8 3.75C4.9 3.75 2.2 6.1 1 8c1.2 1.9 3.9 4.25 7 4.25s5.8-2.35 7-4.25c-1.2-1.9-3.9-4.25-7-4.25zm0 1.5c2.35 0 4.35 1.55 5.25 2.75-.9 1.2-2.9 2.75-5.25 2.75S3.65 9.2 2.75 8 4.65 5.25 8 5.25zm0 1.75a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z"/>',
            'play'    => '<path d="M4.5 3v10l8-5-8-5Z"/>',
            'verified' => '<path fill-rule="evenodd" d="M8 1 6.2 2.3l-2.2-.2-.9 2L1.2 5.3l.6 2.1-.6 2.1 1.9 1.2.9 2 2.2-.2L8 15l1.8-1.5 2.2.2.9-2 1.9-1.2-.6-2.1.6-2.1-1.9-1.2-.9-2-2.2.2L8 1Zm-.7 9.2L4.9 7.8l.9-.9 1.5 1.5 3-3 .9.9-3.9 3.9Z"/>',
        );

        if (!isset($paths[$name])) {
            return '';
        }

        return '<svg class="jssocial_ico" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true">' . $paths[$name] . '</svg>';
    }

    public static function formatCount($n)
    {
        $n = (int) $n;
        if ($n >= 1000000000) {
            return rtrim(rtrim(number_format($n / 1000000000, 1), '0'), '.') . 'B';
        }
        if ($n >= 1000000) {
            return rtrim(rtrim(number_format($n / 1000000, 1), '0'), '.') . 'M';
        }
        if ($n >= 1000) {
            return rtrim(rtrim(number_format($n / 1000, 1), '0'), '.') . 'K';
        }
        return (string) $n;
    }
}
