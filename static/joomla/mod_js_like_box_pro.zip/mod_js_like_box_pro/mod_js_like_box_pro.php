<?php

/**
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @link       https://jsns.eu
 *
 * Unified, server-side rendered social feed module (Instagram, X, Facebook,
 * YouTube). Feeds are rendered on the server so the customer api_key is never
 * exposed. Views are counted client-side via a signed beacon; widget/usage
 * limits are enforced by the API (validated against jsns.eu).
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

require_once __DIR__ . '/helper.php';

$app      = Factory::getApplication();
$document = $app->getDocument();

// API endpoint is fixed for the hosted service; not exposed as an admin field.
$apiUrl = ModJsLikeBoxProHelper::API_BASE_URL;
$apiKey = trim((string) $params->get('api_key'));

// Stable widget identity: hash(domain + module instance id). No params written.
$domain   = Uri::getInstance()->getHost();
$widgetId = substr(hash('sha256', $domain . '|' . (int) $module->id), 0, 24);

$postsLimit = 12;

// Display settings.
$showOnMobile = (int) $params->get('show_on_mobile', 1);
$theme        = ModJsLikeBoxProHelper::normalizeTheme($params->get('theme', 'rounded_dark'));
$position     = (int) $params->get('position', 0);
$buttonsShape = (int) $params->get('buttons_shape', 0);
$buttonsShape = ($buttonsShape >= 0 && $buttonsShape <= 2) ? $buttonsShape : 0;
$buttonsLabel = (int) $params->get('buttons_label', 0);
$marginTop    = $params->get('margin_top', '10vh');
$faCdn        = (int) $params->get('fa_cdn', 1);
$faShim       = (int) $params->get('fa_shim', 0);

// ---------------------------------------------------------------------------
// Fetch meta (usage, limits, beacon token). This also validates the api_key.
// ---------------------------------------------------------------------------
$statusResult  = ($apiUrl !== '' && $apiKey !== '') ? ModJsLikeBoxProHelper::fetchStatus($apiUrl, $apiKey, $widgetId) : null;
$configError   = null;
$statusWarning = null;
$widgetAllowed = true;
$overLimit     = false;
$beaconToken   = '';
$meta          = null;
$plan          = '';
$showBranding  = false;

if (empty($apiKey) || empty($apiUrl)) {
    $configError = 'Js Like Box Slider is not configured. Paste your API key from the jsns.eu dashboard.';
} elseif (!is_array($statusResult) || empty($statusResult['ok'])) {
    $httpCode = is_array($statusResult) ? (int) $statusResult['http_code'] : 0;

    if ($httpCode === 401) {
        $configError = 'Invalid or inactive API key. Check the key in your jsns.eu dashboard.';
    } else {
        $statusWarning = 'Could not verify API status'
            . ($httpCode > 0 ? ' (HTTP ' . $httpCode . ')' : '')
            . '. Cached feeds will still display when available.';
    }
} else {
    $meta          = $statusResult['meta'];
    $plan          = isset($statusResult['plan']) ? (string) $statusResult['plan'] : '';
    if ($plan === '' && is_array($meta) && !empty($meta['plan'])) {
        $plan = (string) $meta['plan'];
    }
    $showBranding  = ModJsLikeBoxProHelper::isFreePlan($plan);
    $widgetAllowed = !empty($meta['widget_allowed']);
    $overLimit     = !empty($meta['over_limit']);
    $beaconToken   = (string) ($meta['beacon_token'] ?? '');
}

// ---------------------------------------------------------------------------
// Build the enabled feeds (server-side rendered), only if this widget is
// within the plan's widget allowance.
// ---------------------------------------------------------------------------
$feeds = array();

if ($configError === null && $widgetAllowed) {
    foreach (ModJsLikeBoxProHelper::PLATFORM_ORDER as $platformSlug) {
        $entry = ModJsLikeBoxProHelper::buildFeedEntry(
            $platformSlug,
            $params,
            $apiUrl,
            $apiKey,
            $widgetId,
            $theme,
            $postsLimit
        );
        if ($entry !== null) {
            $feeds[] = $entry;
        }
    }

    $feeds = array_merge(
        $feeds,
        ModJsLikeBoxProHelper::buildSpecialTabs($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit, $beaconToken, (int) $module->id)
    );
}

// ---------------------------------------------------------------------------
// Custom tabs: arbitrary icon + HTML content tabs appended after the feeds.
// They do not call the API, but respect the plan's widget allowance.
// ---------------------------------------------------------------------------
$customTabs = array();

if ($configError === null && $widgetAllowed) {
    $rawTabs = $params->get('custom_tabs');

    foreach ((array) $rawTabs as $rawTab) {
        $tab     = (object) $rawTab;
        $content = (string) ($tab->custom_content ?? '');
        $text    = trim((string) ($tab->custom_text ?? ''));
        $icon    = trim((string) ($tab->custom_icon ?? ''));
        $url     = trim((string) ($tab->custom_url ?? ''));

        // Skip empty rows (subform always keeps at least one placeholder).
        if ($content === '' && $text === '' && $url === '') {
            continue;
        }

        if ($content !== '' && (int) ($tab->js_prepare_content ?? 0) === 1) {
            $content = HTMLHelper::_('content.prepare', $content);
        }

        $customTabs[] = array(
            'text'    => $text,
            'icon'    => $icon !== '' ? $icon : 'fas fa-link',
            'color'   => trim((string) ($tab->custom_color ?? '')),
            'url'     => $url,
            'content' => $content,
        );
    }
}

// When monthly views are over limit, keep cached social feeds only — hide
// contact, WhatsApp, Calendly, FAQ, testimonials, unified feed, and custom tabs.
if ($overLimit) {
    $feeds = array_values(array_filter($feeds, function ($feed) {
        return isset($feed['key'])
            && in_array($feed['key'], ModJsLikeBoxProHelper::PLATFORM_ORDER, true);
    }));
    $customTabs = array();
}

$hasContent = !empty($feeds) || !empty($customTabs);
$hasContact = false;

if ($configError === null && $widgetAllowed) {
    foreach ($feeds as $feed) {
        if (isset($feed['key']) && $feed['key'] === 'contact') {
            $hasContact = true;
            break;
        }
    }
}

// ---------------------------------------------------------------------------
// Assets.
// ---------------------------------------------------------------------------
$cssPath = JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl/css/style.min.css';
$cssVer  = is_file($cssPath) ? (string) filemtime($cssPath) : '4.0';
ModJsLikeBoxProHelper::addDocumentStyleSheet($document, Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl/css/style.min.css', $cssVer);

if (ModJsLikeBoxProHelper::isRoundedTheme($theme)) {
    ModJsLikeBoxProHelper::addDocumentStyleSheet($document, 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,400&display=swap');
}

if ($faCdn == 1) {
    ModJsLikeBoxProHelper::addDocumentStyleSheet($document, 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css');
    if ($faShim == 1) {
        ModJsLikeBoxProHelper::addDocumentStyleSheet($document, 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/v4-shims.min.css');
    }
}

// Beacon: count one view for this widget on page load. api_key never sent.
if ($widgetAllowed && $beaconToken !== '' && $hasContent) {
    ModJsLikeBoxProHelper::addDocumentScriptOptions($document, 'modJsLikeBoxPro', array(
        'beaconUrl' => rtrim($apiUrl, '/') . '/beacon',
        'token'     => $beaconToken,
        'widgetId'  => $widgetId,
    ));
    ModJsLikeBoxProHelper::addDocumentScript($document, Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl/js/beacon.js', '4.0', true);
}

if ($hasContent) {
    $shareJs = JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl/js/share.js';
    ModJsLikeBoxProHelper::addDocumentScript(
        $document,
        Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl/js/share.js',
        is_file($shareJs) ? (string) filemtime($shareJs) : '4.0',
        true
    );

    $imagesJs = JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl/js/images.js';
    ModJsLikeBoxProHelper::addDocumentScript(
        $document,
        Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl/js/images.js',
        is_file($imagesJs) ? (string) filemtime($imagesJs) : '4.0',
        true
    );

    if ($hasContact) {
        $contactJs = JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl/js/contact.js';
        ModJsLikeBoxProHelper::addDocumentScript(
            $document,
            Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl/js/contact.js',
            is_file($contactJs) ? (string) filemtime($contactJs) : '4.0',
            true
        );
    }
}

require ModuleHelper::getLayoutPath('mod_js_like_box_pro', $params->get('layout', 'default'));
