/**
 * JS Like Box PRO - contact tab form submission.
 * Posts to Joomla com_ajax; mail is sent via Joomla Mail (site SMTP plugin).
 */
(function () {
    'use strict';

    function closestForm(el) {
        while (el && el !== document) {
            if (el.matches && el.matches('[data-contact-form]')) {
                return el;
            }
            el = el.parentNode;
        }
        return null;
    }

    function parseAjaxPayload(wrapper) {
        if (!wrapper || typeof wrapper !== 'object') {
            return { success: false, error: 'Invalid response from server.' };
        }

        if (wrapper.data && typeof wrapper.data === 'object' && 'success' in wrapper.data) {
            return wrapper.data;
        }

        if (wrapper.data && typeof wrapper.data === 'string' && wrapper.data !== '') {
            return { success: false, error: wrapper.data };
        }

        if ('success' in wrapper) {
            return wrapper;
        }

        if (wrapper.message) {
            return { success: false, error: String(wrapper.message) };
        }

        return { success: false, error: 'Could not send message. Try again later.' };
    }

    function setAlert(wrap, message, type) {
        var alert = wrap.querySelector('.jssocial_contact_alert');
        if (!alert) {
            return;
        }

        alert.hidden = false;
        alert.textContent = message;
        alert.classList.remove('jssocial_contact_alert--ok', 'jssocial_contact_alert--error');
        alert.classList.add(type === 'ok' ? 'jssocial_contact_alert--ok' : 'jssocial_contact_alert--error');
        alert.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }

    function clearAlert(wrap) {
        var alert = wrap.querySelector('.jssocial_contact_alert');
        if (!alert) {
            return;
        }
        alert.hidden = true;
        alert.textContent = '';
        alert.classList.remove('jssocial_contact_alert--ok', 'jssocial_contact_alert--error');
    }

    function setFieldError(form, name, message) {
        var input = form.querySelector('[name="' + name + '"]');
        if (!input) {
            return;
        }
        var field = input.closest('.jssocial_contact_field');
        if (!field) {
            return;
        }
        field.classList.toggle('jssocial_contact_field--invalid', !!message);
    }

    function clearFieldErrors(form) {
        form.querySelectorAll('.jssocial_contact_field--invalid').forEach(function (field) {
            field.classList.remove('jssocial_contact_field--invalid');
        });
    }

    function setLoading(form, isLoading) {
        var btn = form.querySelector('.jssocial_contact_submit');
        if (!btn) {
            return;
        }
        btn.disabled = !!isLoading;
        btn.classList.toggle('is-loading', !!isLoading);
        var text = btn.querySelector('.jssocial_contact_submit_text');
        var loading = btn.querySelector('.jssocial_contact_submit_loading');
        if (text) {
            text.hidden = !!isLoading;
        }
        if (loading) {
            loading.hidden = !isLoading;
        }
    }

    function handleSubmit(event) {
        event.preventDefault();

        var wrap = closestForm(event.target);
        if (!wrap) {
            return;
        }

        var form = wrap.querySelector('.jssocial_contact_form');
        if (!form) {
            return;
        }

        var url = wrap.getAttribute('data-contact-url') || form.getAttribute('action') || '';
        var successMsg = wrap.getAttribute('data-contact-success') || 'Thank you!';

        clearAlert(wrap);
        clearFieldErrors(form);

        if (!url) {
            setAlert(wrap, 'Contact form is not configured.', 'error');
            return;
        }

        var fd = new FormData(form);
        var hasError = false;

        if (!String(fd.get('name') || '').trim()) {
            setFieldError(form, 'name', '1');
            hasError = true;
        }
        if (!String(fd.get('email') || '').trim()) {
            setFieldError(form, 'email', '1');
            hasError = true;
        }
        if (!String(fd.get('message') || '').trim()) {
            setFieldError(form, 'message', '1');
            hasError = true;
        }

        if (hasError) {
            setAlert(wrap, 'Please fill in all required fields.', 'error');
            return;
        }

        setLoading(form, true);

        fetch(url, {
            method: 'POST',
            body: fd,
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
            .then(function (res) {
                return res.text().then(function (text) {
                    var data = {};
                    try {
                        data = text ? JSON.parse(text) : {};
                    } catch (e) {
                        data = { success: false, message: text || 'Invalid server response.' };
                    }
                    return { ok: res.ok, status: res.status, data: data };
                });
            })
            .then(function (result) {
                var payload = parseAjaxPayload(result.data);

                if (result.ok && payload.success) {
                    form.reset();
                    setAlert(wrap, successMsg, 'ok');
                    return;
                }

                if (result.status === 404) {
                    setAlert(wrap, 'Contact endpoint not found. Reinstall the module and clear Joomla cache.', 'error');
                    return;
                }

                var err = payload.error || 'Could not send message. Try again later.';
                setAlert(wrap, err, 'error');

                if (/email/i.test(err)) {
                    setFieldError(form, 'email', '1');
                }
            })
            .catch(function () {
                setAlert(wrap, 'Network error. Check your connection and try again.', 'error');
            })
            .finally(function () {
                setLoading(form, false);
            });
    }

    document.addEventListener('submit', function (event) {
        if (event.target && event.target.matches('.jssocial_contact_form')) {
            handleSubmit(event);
        }
    }, true);
})();
