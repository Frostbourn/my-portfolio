/**
 * JS Like Box PRO — image load placeholders (shimmer until loaded).
 */
(function () {
    'use strict';

    var ROOT = '.social_slider_pro';
    var WRAP_SEL = '.jssocial_imgwrap';
    var COVER_WRAP_SEL = '.jssocial_imgwrap--cover';

    function markLoaded(wrap) {
        wrap.classList.add('is-loaded');
    }

    function bindImage(img) {
        var wrap = img.closest(WRAP_SEL);
        if (!wrap || wrap.classList.contains('is-loaded')) {
            return;
        }

        if (wrap.matches(COVER_WRAP_SEL)) {
            markLoaded(wrap);
            return;
        }

        if (img.complete && img.naturalWidth > 0) {
            markLoaded(wrap);
            return;
        }

        img.addEventListener('load', function () {
            markLoaded(wrap);
        }, { once: true });

        img.addEventListener('error', function () {
            wrap.classList.add('is-error');
            markLoaded(wrap);
        }, { once: true });
    }

    function init() {
        document.querySelectorAll(ROOT + ' ' + WRAP_SEL + ' img').forEach(bindImage);
    }

    function bindTabRefresh() {
        document.querySelectorAll(ROOT + ' input[name="tabs"]').forEach(function (radio) {
            radio.addEventListener('change', function () {
                window.setTimeout(init, 0);
            });
        });
    }

    function boot() {
        init();
        bindTabRefresh();
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        boot();
    } else {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    }
})();
