/**
 * JS Like Box PRO - view beacon.
 *
 * Sends a single signed token to the API's /beacon endpoint on page load so a
 * view is counted for this widget. The customer api_key is never present here;
 * the token is a short-lived HMAC issued server-side during render.
 *
 * Uses a text/plain body so the request stays a CORS "simple request" and
 * never triggers a preflight.
 */
(function () {
    'use strict';

    function getOptions() {
        if (window.Joomla && typeof window.Joomla.getOptions === 'function') {
            return window.Joomla.getOptions('modJsLikeBoxPro');
        }
        if (window.Joomla && window.Joomla.optionsStorage && window.Joomla.optionsStorage.modJsLikeBoxPro) {
            return window.Joomla.optionsStorage.modJsLikeBoxPro;
        }
        return null;
    }

    function sendBeacon() {
        var opts = getOptions();
        if (!opts || !opts.beaconUrl || !opts.token) {
            return;
        }

        var body = JSON.stringify({ t: opts.token, widget_id: opts.widgetId });

        try {
            if (navigator.sendBeacon) {
                var blob = new Blob([body], { type: 'text/plain' });
                if (navigator.sendBeacon(opts.beaconUrl, blob)) {
                    return;
                }
            }
        } catch (e) {
            // fall through to fetch
        }

        try {
            fetch(opts.beaconUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'text/plain' },
                body: body,
                keepalive: true,
                mode: 'cors',
                credentials: 'omit'
            });
        } catch (e) {
            // best-effort only
        }
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        sendBeacon();
    } else {
        document.addEventListener('DOMContentLoaded', sendBeacon, { once: true });
    }
})();
