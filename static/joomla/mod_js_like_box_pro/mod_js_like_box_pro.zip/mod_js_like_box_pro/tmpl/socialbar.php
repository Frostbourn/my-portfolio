<?php

/**
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @link       https://jsns.eu
 *
 * Compact social proof bar: platform icons + one latest post (lazy-loaded).
 */

defined('_JEXEC') or die('Restricted access');

if ($configError !== null) {
    if ($showAdminNotices) {
        echo '<div class="social_feed_notice social_feed_error">' . htmlspecialchars($configError) . '</div>';
    }

    return;
}

if (!$widgetAllowed) {
    ?>
    <div class="social_feed_notice social_feed_upgrade">
        This widget exceeds your plan's widget limit.
        <a href="<?php echo htmlspecialchars(ModJsLikeBoxProHelper::UPGRADE_URL); ?>" target="_blank" rel="noopener">Upgrade your plan</a>
    </div>
    <?php
    return;
}

if ($socialBarHtml === '') {
    return;
}

if (!empty($statusWarning) && $showAdminNotices) {
    echo '<div class="social_feed_notice social_feed_warning">' . htmlspecialchars($statusWarning) . '</div>';
}

if ($overLimit) {
    echo ModJsLikeBoxProHelper::renderOverLimitNotice();
}

echo $socialBarHtml;

if ($showBranding) {
    echo ModJsLikeBoxProHelper::renderBranding();
}
