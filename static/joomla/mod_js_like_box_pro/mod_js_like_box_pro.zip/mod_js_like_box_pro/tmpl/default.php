<?php

/**
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @link       https://jsns.eu
 */

defined('_JEXEC') or die('Restricted access');

// Nothing to show if misconfigured or the widget is over the plan allowance.
if ($configError !== null) {
    if ($showAdminNotices) {
        echo '<div class="social_feed_notice social_feed_error">' . htmlspecialchars($configError) . '</div>';
    }

    return;
}

if (!$widgetAllowed) {
    ?>
    <div class="social_feed_notice social_feed_upgrade">
        This widget exceeds your plan's widget limit.
        <a href="<?php echo htmlspecialchars(ModJsLikeBoxProHelper::UPGRADE_URL); ?>" target="_blank" rel="noopener">Upgrade your plan</a> to activate it.
    </div>
    <?php
    return;
}

if (empty($feeds) && empty($customTabs) && empty($socialBarHtml)) {
    return;
}

$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Custom tabs that opt into a mobile button (they set a URL).
$mobileCustom = array();
foreach ($customTabs as $ci => $ctab) {
    if ($ctab['url'] !== '') {
        $mobileCustom[$ci] = $ctab;
    }
}
?>

<?php if ($showOnMobile == 1) : ?>
    <div class="social_mobile_pro">
        <div class="top-left">
            <?php
            foreach ($feeds as $feed) :
                if (empty($feed['profile_url'])) {
                    continue;
                }
                ?>
                <a class="<?php echo $feed['key']; ?>" href="<?php echo htmlspecialchars($feed['profile_url']); ?>" target="_blank" rel="noopener">
                    <i class="<?php echo $feed['icon']; ?>"></i>
                </a>
            <?php endforeach; ?>
            <?php foreach ($mobileCustom as $ci => $ctab) : ?>
                <a class="custom_<?php echo $ci; ?>" href="<?php echo htmlspecialchars($ctab['url']); ?>" target="_blank" rel="noopener">
                    <i class="<?php echo htmlspecialchars($ctab['icon']); ?>"></i>
                </a>
                <?php if ($ctab['color'] !== '') {
                    $document->addStyleDeclaration('.social_mobile_pro .custom_' . $ci . ' { background-color: ' . $ctab['color'] . '; }');
                } ?>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<?php
$btnShapeClass = array(0 => 'social_slider_pro--btn-square', 1 => 'social_slider_pro--btn-rounded', 2 => 'social_slider_pro--btn-round');
$btnShapeClass = isset($btnShapeClass[$buttonsShape]) ? $btnShapeClass[$buttonsShape] : 'social_slider_pro--btn-square';
$themeClass    = ModJsLikeBoxProHelper::isDarkFeedTheme($theme) ? ' social_slider_pro--feed-dark' : ' social_slider_pro--feed-light';
?>
<div class="social_slider_pro social_slider_pro--<?php echo (int) $position === 1 ? 'left' : 'right'; ?> <?php echo $btnShapeClass; ?><?php echo (int) $buttonsLabel === 0 ? ' social_slider_pro--btn-icons' : ''; ?><?php echo ModJsLikeBoxProHelper::isRoundedTheme($theme) ? ' social_slider_pro--rounded' : ''; ?><?php echo $themeClass; ?>"<?php
if (!empty($hasLazyFeeds)) :
    ?> data-jssocial-lazy="1" data-jssocial-module-id="<?php echo (int) $module->id; ?>" data-jssocial-ajax-url="<?php echo htmlspecialchars(ModJsLikeBoxProHelper::buildFeedAjaxUrl((int) $module->id), ENT_QUOTES); ?>"<?php
endif;
?>>
    <?php if (!empty($statusWarning) && $showAdminNotices) : ?>
        <div class="social_feed_notice social_feed_warning"><?php echo htmlspecialchars($statusWarning); ?></div>
    <?php endif; ?>

    <?php foreach ($feeds as $i => $feed) : ?>
        <?php $tabId = ModJsLikeBoxProHelper::tabRadioId($i); ?>
        <input id="<?php echo $tabId; ?>" type="radio" name="tabs" <?php echo $i === 0 ? 'checked' : ''; ?> />
        <label for="<?php echo $tabId; ?>" class="<?php echo $feed['class']; ?>">
            <span><?php echo htmlspecialchars($feed['label']); ?></span>
            <i class="<?php echo $feed['icon']; ?>"></i>
        </label>
        <section id="content_<?php echo $tabId; ?>">
            <div class="<?php echo $feed['key']; ?>_box social_feed_box<?php echo $overLimit ? ' social_feed_box--overlimit' : ''; ?><?php echo !empty($feed['lazy']) ? ' social_feed_box--lazy' : ''; ?>"<?php echo !empty($feed['lazy']) ? ' data-jssocial-lazy="1" data-jssocial-tab="' . htmlspecialchars($feed['key'], ENT_QUOTES) . '"' : ''; ?>>
                <?php if ($overLimit) : ?>
                    <?php echo ModJsLikeBoxProHelper::renderOverLimitNotice($theme); ?>
                <?php endif; ?>
                <?php if (!empty($showBranding)) : ?>
                    <?php echo ModJsLikeBoxProHelper::renderBranding(); ?>
                <?php endif; ?>
                <?php echo $feed['html']; ?>
            </div>
        </section>
    <?php endforeach; ?>

    <?php foreach ($customTabs as $ci => $ctab) : ?>
        <?php $ctabId = 'ctab_' . $ci; ?>
        <input id="<?php echo $ctabId; ?>" type="radio" name="tabs" <?php echo (empty($feeds) && $ci === 0) ? 'checked' : ''; ?> />
        <label for="<?php echo $ctabId; ?>" id="custom_label_<?php echo $ci; ?>" class="custom_icon">
            <span><?php echo htmlspecialchars($ctab['text']); ?></span>
            <i class="<?php echo htmlspecialchars($ctab['icon']); ?>"></i>
        </label>
        <section id="content_<?php echo $ctabId; ?>">
            <div class="custom_box">
                <?php if (!empty($showBranding)) : ?>
                    <?php echo ModJsLikeBoxProHelper::renderBranding(); ?>
                <?php endif; ?>
                <?php echo $ctab['content']; ?>
            </div>
        </section>
    <?php endforeach; ?>
</div>

<?php if (!empty($socialBarHtml)) : ?>
    <?php echo $socialBarHtml; ?>
<?php endif; ?>

<?php
// Show only the checked tab's section (scoped to enabled feeds).
$dynamicStyles = '';
foreach ($feeds as $i => $feed) {
    $tabId = ModJsLikeBoxProHelper::tabRadioId($i);
    $dynamicStyles .= '#' . $tabId . ':checked ~ #content_' . $tabId . '{display:block;}';

    $accent = isset($feed['accent']) ? (string) $feed['accent'] : '';
    if ($accent !== '') {
        $boxSel = '.social_slider_pro #content_' . $tabId . ' .' . $feed['key'] . '_box';
        if ($position == 1) {
            $dynamicStyles .= $boxSel . '{border-right:10px solid ' . $accent . ';border-left:none;}';
        } else {
            $dynamicStyles .= $boxSel . '{border-left:10px solid ' . $accent . ';}';
        }
    }
}

foreach ($customTabs as $ci => $ctab) {
    $ctabId = 'ctab_' . $ci;
    $dynamicStyles .= '#' . $ctabId . ':checked ~ #content_' . $ctabId . '{display:block;}';

    if ($ctab['color'] !== '') {
        if (ModJsLikeBoxProHelper::isRoundedTheme($theme)) {
            $dynamicStyles .= '.social_slider_pro #custom_label_' . $ci . '.custom_icon{background-color:' . $ctab['color'] . ';box-shadow:0 0 0 rgb(0 0 0 / 38%),0 5px 0 ' . $ctab['color'] . ';}';
        } else {
            $dynamicStyles .= '.social_slider_pro #custom_label_' . $ci . '.custom_icon{background-color:' . $ctab['color'] . ';box-shadow:0px 0px 0px rgb(0 0 0 / 38%),0px 5px 0px ' . $ctab['color'] . ';}';
        }
        if ($position == 1) {
            $dynamicStyles .= '.social_slider_pro #content_' . $ctabId . ' .custom_box{border-right:10px solid ' . $ctab['color'] . ';border-left:none;}';
        } else {
            $dynamicStyles .= '.social_slider_pro #content_' . $ctabId . ' .custom_box{border-left:10px solid ' . $ctab['color'] . ';}';
        }
    }
}

if ($buttonsLabel == 0) {
    $dynamicStyles .= '.social_slider_pro > label {width: 40px!important;height: 40px!important;display:flex!important;justify-content:center!important;align-items:center!important;} .social_slider_pro > label span {display:none!important;} .social_slider_pro > label > i {width:42px!important;height:40px!important;display:flex!important;justify-content:center!important;align-items:center!important;color:#fff!important;position:relative!important;font-size:18px!important;background-color:unset!important;}';
}

if ($position == 1) {
    $dynamicStyles .= '.social_slider_pro {left:-370px;}.social_slider_pro:hover,.social_slider_pro:focus-within,.social_slider_pro.is-hover,.social_slider_pro:has(> label:hover){transform: translateX(370px);}';
    $dynamicStyles .= '.social_slider_pro > label{float:right; clear:right; right:-32px;}';
    if ($buttonsLabel == 0) {
        $dynamicStyles .= '.social_slider_pro > label {right:-40px !important;}';
    }
} else {
    $dynamicStyles .= '.social_slider_pro {right:-370px;}.social_slider_pro:hover,.social_slider_pro:focus-within,.social_slider_pro.is-hover,.social_slider_pro:has(> label:hover){transform: translateX(-370px);}';
    $dynamicStyles .= '.social_slider_pro > label{float:left; left:-32px; clear:left;}';
    if ($buttonsLabel == 0) {
        $dynamicStyles .= '.social_slider_pro > label {left:-40px !important;}';
    }
}

$dynamicStyles .= '.social_slider_pro > label:first-of-type {margin-top: ' . $marginTop . ';}';
$dynamicStyles .= '.social_slider_pro .fab { font-family: "Font Awesome 6 Brands" !important; }';
$dynamicStyles .= '.social_slider_pro .fas { font-family: "Font Awesome 6 Free" !important; font-weight: 900; }';

$document->addStyleDeclaration($dynamicStyles);
?>
