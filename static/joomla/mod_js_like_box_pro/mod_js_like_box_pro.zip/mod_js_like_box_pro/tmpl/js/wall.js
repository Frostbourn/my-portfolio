/**
 * JS Like Box PRO — Social Wall lazy load (scroll into view) + load-more.
 */
(function () {
    'use strict';

    var WALL_SEL = '[data-jssocial-wall="1"]';
    var LAZY_SEL = '[data-jssocial-wall-lazy="1"]';
    var HIDDEN_SEL = '.jssocial_card--wall-hidden';
    var BTN_SEL = '[data-jssocial-wall-loadmore]';

    function parseAjaxPayload(wrapper) {
        if (!wrapper || typeof wrapper !== 'object') {
            return { success: false, error: 'Invalid response from server.' };
        }

        var data = wrapper.data;

        if (data && typeof data === 'object' && ('success' in data || 'html' in data || 'error' in data)) {
            if (data.cache_miss) {
                return { success: false, error: data.error || 'cache_miss', cache_miss: true };
            }
            return data;
        }

        if (typeof data === 'string' && data !== '') {
            if (data.charAt(0) === '{' || data.charAt(0) === '[') {
                try {
                    var nested = JSON.parse(data);
                    if (nested && typeof nested === 'object') {
                        return parseAjaxPayload({ data: nested });
                    }
                } catch (e) {
                    // fall through
                }
            }
            if (data.indexOf('<') !== -1) {
                return { success: true, html: data };
            }
            return { success: false, error: data };
        }

        if ('success' in wrapper && ('html' in wrapper || 'error' in wrapper)) {
            return wrapper;
        }

        if (wrapper.success === false && wrapper.message) {
            return { success: false, error: String(wrapper.message) };
        }

        return { success: false, error: 'Could not load wall.' };
    }

    function requestFeed(url) {
        if (window.jQuery && typeof window.jQuery.ajax === 'function') {
            return new Promise(function (resolve, reject) {
                window.jQuery.ajax({
                    url: url,
                    type: 'GET',
                    dataType: 'json',
                    cache: false,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    success: function (json) {
                        resolve(parseAjaxPayload(json));
                    },
                    error: function (xhr) {
                        var json = xhr.responseJSON;
                        if (!json && xhr.responseText) {
                            try {
                                json = JSON.parse(xhr.responseText);
                            } catch (e) {
                                json = null;
                            }
                        }
                        if (json) {
                            var payload = parseAjaxPayload(json);
                            reject(new Error(payload.error || 'Could not load wall.'));
                            return;
                        }
                        reject(new Error('Could not load wall.'));
                    }
                });
            });
        }

        if (typeof window.fetch !== 'function') {
            return Promise.reject(new Error('This browser cannot load the wall.'));
        }

        return fetch(url, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        }).then(function (res) {
            return res.text().then(function (text) {
                var json = null;
                try {
                    json = JSON.parse(text);
                } catch (e2) {
                    json = null;
                }
                if (!json) {
                    throw new Error('Could not load wall.');
                }
                var payload = parseAjaxPayload(json);
                if (!payload.success) {
                    throw new Error(payload.error || 'Could not load wall.');
                }
                return payload;
            });
        });
    }

    function buildWallUrl(wall) {
        var url = wall.getAttribute('data-jssocial-ajax-url') || '';
        var sep = url.indexOf('?') >= 0 ? '&' : '?';
        return url + sep + 'context=wall';
    }

    function notifyImages(wall) {
        try {
            if (typeof window.CustomEvent === 'function') {
                document.dispatchEvent(new CustomEvent('jssocial-init-images', { detail: { root: wall } }));
            } else if (document.createEvent) {
                var ev = document.createEvent('CustomEvent');
                ev.initCustomEvent('jssocial-init-images', true, true, { root: wall });
                document.dispatchEvent(ev);
            }
        } catch (e) {
            // best-effort
        }

        try {
            if (typeof window.CustomEvent === 'function') {
                document.dispatchEvent(new CustomEvent('jssocial-init-shares', { detail: { root: wall } }));
            }
        } catch (e2) {
            // best-effort
        }
    }

    function showWallError(wall, message) {
        var feed = wall.querySelector('.jssocial_feed--wall');
        if (feed) {
            feed.classList.remove('jssocial_feed--pending');
            feed.innerHTML = '<div class="jssocial_empty"><p>' + message + '</p></div>';
        }
    }

    function loadWall(wall) {
        if (!wall || wall.getAttribute('data-jssocial-wall-loaded') === '1' || wall.getAttribute('data-jssocial-wall-inflight') === '1') {
            return;
        }

        wall.setAttribute('data-jssocial-wall-inflight', '1');
        wall.classList.add('jssocial_wall--loading');

        requestFeed(buildWallUrl(wall)).then(function (payload) {
            if (payload.cache_miss) {
                var miss = new Error('cache_miss');
                miss.cacheMiss = true;
                throw miss;
            }
            if (!payload.html) {
                throw new Error(payload.error || 'Could not load wall.');
            }

            var temp = document.createElement('div');
            temp.innerHTML = payload.html.trim();
            var fresh = temp.firstElementChild;
            if (!fresh) {
                throw new Error('Invalid wall response.');
            }

            fresh.setAttribute('data-jssocial-wall-loaded', '1');
            if (wall.parentNode) {
                wall.parentNode.replaceChild(fresh, wall);
            }
            bindWall(fresh);
            notifyImages(fresh);
        }).catch(function (err) {
            wall.removeAttribute('data-jssocial-wall-inflight');
            wall.classList.remove('jssocial_wall--loading');
            if (err && err.cacheMiss) {
                return;
            }
            showWallError(wall, err && err.message ? err.message : 'Could not load wall.');
        });
    }

    function bindLazyWall(wall) {
        if (wall.getAttribute('data-jssocial-wall-lazy-bound') === '1') {
            return;
        }
        wall.setAttribute('data-jssocial-wall-lazy-bound', '1');

        if ('IntersectionObserver' in window) {
            var io = new IntersectionObserver(function (entries) {
                var i;
                for (i = 0; i < entries.length; i++) {
                    if (entries[i].isIntersecting) {
                        io.disconnect();
                        loadWall(wall);
                        break;
                    }
                }
            }, { rootMargin: '160px' });
            io.observe(wall);
            return;
        }

        setTimeout(function () {
            loadWall(wall);
        }, 600);
    }

    function loadMore(wall, btn) {
        var batch = parseInt(wall.getAttribute('data-jssocial-wall-batch') || btn.getAttribute('data-batch') || '6', 10);
        if (batch <= 0) {
            batch = 6;
        }

        var hidden = wall.querySelectorAll(HIDDEN_SEL);
        var shown = 0;
        var i;

        for (i = 0; i < hidden.length && shown < batch; i++) {
            hidden[i].classList.remove('jssocial_card--wall-hidden');
            shown++;
        }

        notifyImages(wall);

        if (wall.querySelectorAll(HIDDEN_SEL).length === 0) {
            var footer = btn.closest('.jssocial_wall_footer');
            if (footer) {
                footer.style.display = 'none';
            } else {
                btn.style.display = 'none';
            }
        }
    }

    function bindWall(wall) {
        var btn = wall.querySelector(BTN_SEL);
        if (!btn || btn.getAttribute('data-jssocial-wall-bound') === '1') {
            return;
        }
        btn.setAttribute('data-jssocial-wall-bound', '1');
        btn.addEventListener('click', function (event) {
            event.preventDefault();
            loadMore(wall, btn);
        });
    }

    function retryLazyWallsFromCache() {
        var walls = document.querySelectorAll(LAZY_SEL);
        var i;

        for (i = 0; i < walls.length; i++) {
            var wall = walls[i];
            if (wall.getAttribute('data-jssocial-wall-loaded') === '1' || wall.getAttribute('data-jssocial-wall-inflight') === '1') {
                continue;
            }
            loadWall(wall);
        }
    }

    function boot() {
        var lazyWalls = document.querySelectorAll(LAZY_SEL);
        var i;

        for (i = 0; i < lazyWalls.length; i++) {
            bindLazyWall(lazyWalls[i]);
        }

        var walls = document.querySelectorAll(WALL_SEL);
        for (i = 0; i < walls.length; i++) {
            if (walls[i].getAttribute('data-jssocial-wall-lazy') === '1') {
                continue;
            }
            bindWall(walls[i]);
        }

        document.addEventListener('jssocial-feed-cached', retryLazyWallsFromCache);
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        boot();
    } else if (document.addEventListener) {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        window.attachEvent('onload', boot);
    }
})();
