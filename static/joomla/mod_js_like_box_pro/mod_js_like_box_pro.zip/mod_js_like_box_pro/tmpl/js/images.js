/**
 * JS Like Box PRO — image load placeholders (shimmer until loaded).
 */
(function () {
    'use strict';

    var ROOTS = ['.social_slider_pro', '.jssocial_wall'];
    var WRAP_SEL = '.jssocial_imgwrap';
    var COVER_WRAP_SEL = '.jssocial_imgwrap--cover';

    function markLoaded(wrap) {
        wrap.classList.add('is-loaded');
    }

    function bindImage(img) {
        var wrap = img.closest(WRAP_SEL);
        if (!wrap || wrap.classList.contains('is-loaded')) {
            return;
        }

        if (wrap.matches(COVER_WRAP_SEL)) {
            markLoaded(wrap);
            return;
        }

        if (img.complete && img.naturalWidth > 0) {
            markLoaded(wrap);
            return;
        }

        img.addEventListener('load', function () {
            markLoaded(wrap);
        }, { once: true });

        img.addEventListener('error', function () {
            wrap.classList.add('is-error');
            markLoaded(wrap);
            if (wrap.classList.contains('jssocial_imgwrap--avatar-sm')) {
                avatarErrorFallback(wrap);
            }
        }, { once: true });
    }

    function avatarErrorFallback(wrap) {
        var author = wrap.closest('.jssocial_card_author');
        if (!author) {
            return;
        }
        var platformIcon = author.querySelector('.jssocial_card_platform');
        var iconClass = 'fab fa-link';
        if (platformIcon) {
            iconClass = platformIcon.className.replace(/\bjssocial_card_platform\b/g, '').trim();
        }
        var ph = document.createElement('span');
        ph.className = 'jssocial_card_avatar jssocial_card_avatar--ph';
        ph.setAttribute('aria-hidden', 'true');
        var icon = document.createElement('i');
        icon.className = iconClass || 'fab fa-link';
        ph.appendChild(icon);
        if (wrap.parentNode) {
            wrap.parentNode.replaceChild(ph, wrap);
        }
    }

    function collectImages(root) {
        if (root && root.querySelectorAll && root !== document) {
            return root.querySelectorAll(WRAP_SEL + ' img');
        }

        var seen = [];
        var i;
        for (i = 0; i < ROOTS.length; i++) {
            var nodes = document.querySelectorAll(ROOTS[i] + ' ' + WRAP_SEL + ' img');
            var j;
            for (j = 0; j < nodes.length; j++) {
                seen.push(nodes[j]);
            }
        }
        return seen;
    }

    function initRoot(root) {
        var imgs = collectImages(root);
        for (var i = 0; i < imgs.length; i++) {
            bindImage(imgs[i]);
        }
    }

    function init() {
        initRoot(document);
    }

    function bindTabRefresh() {
        document.querySelectorAll('.social_slider_pro input[name="tabs"]').forEach(function (radio) {
            radio.addEventListener('change', function () {
                window.setTimeout(init, 0);
            });
        });

        document.addEventListener('jssocial-feed-loaded', function (e) {
            if (e.target && e.target.closest) {
                initRoot(e.target);
            }
        });

        document.addEventListener('jssocial-init-images', function (e) {
            var root = (e.detail && e.detail.root) ? e.detail.root : document;
            initRoot(root);
        });
    }

    function boot() {
        init();
        bindTabRefresh();
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        boot();
    } else {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    }
})();
