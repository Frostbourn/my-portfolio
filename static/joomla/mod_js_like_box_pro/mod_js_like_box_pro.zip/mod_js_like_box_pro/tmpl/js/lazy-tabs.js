/**
 * JS Like Box PRO — lazy-load API-backed feed tabs on widget hover or tab click.
 * Joomla 3.10+ (jQuery.ajax) and 4+ (fetch). Contact tabs render immediately.
 */
(function () {
    'use strict';

    var ROOT = '.social_slider_pro[data-jssocial-lazy="1"]';
    var LAZY_BOX = '.social_feed_box--lazy[data-jssocial-lazy="1"]';

    function getOptions() {
        if (window.Joomla && typeof window.Joomla.getOptions === 'function') {
            return window.Joomla.getOptions('modJsLikeBoxProLazy');
        }
        if (window.Joomla && window.Joomla.optionsStorage && window.Joomla.optionsStorage.modJsLikeBoxProLazy) {
            return window.Joomla.optionsStorage.modJsLikeBoxProLazy;
        }
        return null;
    }

    function optsFromSlider(slider) {
        var opts = getOptions() || {};
        if (slider) {
            if (!opts.ajaxUrl && slider.getAttribute('data-jssocial-ajax-url')) {
                opts.ajaxUrl = slider.getAttribute('data-jssocial-ajax-url');
            }
            if (!opts.moduleId && slider.getAttribute('data-jssocial-module-id')) {
                opts.moduleId = parseInt(slider.getAttribute('data-jssocial-module-id'), 10) || 0;
            }
        }
        return opts;
    }

    /**
     * Unwrap Joomla 3/4 com_ajax JSON (JResponseJson / JsonResponse).
     * Helper return value is usually in .data; errors use .message.
     */
    function parseAjaxPayload(wrapper) {
        if (!wrapper || typeof wrapper !== 'object') {
            return { success: false, error: 'Invalid response from server.' };
        }

        var data = wrapper.data;

        if (data && typeof data === 'object' && ('success' in data || 'html' in data || 'error' in data)) {
            if (data.cache_miss) {
                return { success: false, error: data.error || 'cache_miss', cache_miss: true };
            }
            return data;
        }

        if (typeof data === 'string' && data !== '') {
            if (data.charAt(0) === '{' || data.charAt(0) === '[') {
                try {
                    var nested = JSON.parse(data);
                    if (nested && typeof nested === 'object') {
                        return parseAjaxPayload({ data: nested });
                    }
                } catch (e) {
                    // fall through
                }
            }
            if (data.indexOf('<') !== -1) {
                return { success: true, html: data };
            }
            return { success: false, error: data };
        }

        if ('success' in wrapper && ('html' in wrapper || 'error' in wrapper)) {
            return wrapper;
        }

        if (wrapper.success === false && wrapper.message) {
            return { success: false, error: String(wrapper.message) };
        }

        return { success: false, error: 'Could not load feed.' };
    }

    function boxForRadio(radio) {
        if (!radio || !radio.id) {
            return null;
        }
        var section = document.getElementById('content_' + radio.id);
        if (!section) {
            return null;
        }
        return section.querySelector(LAZY_BOX);
    }

    function activeLazyBox(slider) {
        var checked = slider.querySelector('input[name="tabs"]:checked');
        return checked ? boxForRadio(checked) : null;
    }

    function isLoaded(box) {
        return box.getAttribute('data-jssocial-loaded') === '1';
    }

    function setLoaded(box) {
        box.setAttribute('data-jssocial-loaded', '1');
    }

    function isInflight(box) {
        return box.getAttribute('data-jssocial-inflight') === '1';
    }

    function setInflight(box, on) {
        if (on) {
            box.setAttribute('data-jssocial-inflight', '1');
        } else {
            box.removeAttribute('data-jssocial-inflight');
        }
    }

    function markLoading(box, loading) {
        box.classList.toggle('social_feed_box--loading', !!loading);
        var pending = box.querySelector('.jssocial_feed--pending, .jssocial_feed_skeleton');
        if (pending) {
            pending.setAttribute('aria-busy', loading ? 'true' : 'false');
        }
    }

    function showError(box, message) {
        box.innerHTML = '<div class="jssocial_empty"><p>' + message + '</p></div>';
        box.removeAttribute('data-jssocial-lazy');
        box.classList.remove('social_feed_box--lazy', 'social_feed_box--loading');
    }

    function notifyFeedCached(opts, tab) {
        if (!opts || !opts.moduleId || !tab) {
            return;
        }
        try {
            if (typeof window.CustomEvent === 'function') {
                document.dispatchEvent(new CustomEvent('jssocial-feed-cached', {
                    detail: { moduleId: opts.moduleId, tab: tab }
                }));
            }
        } catch (e) {
            // best-effort
        }
    }

    function notifyLoaded(box) {
        try {
            if (typeof window.CustomEvent === 'function') {
                box.dispatchEvent(new CustomEvent('jssocial-feed-loaded', { bubbles: true }));
            } else if (document.createEvent) {
                var ev = document.createEvent('Event');
                ev.initEvent('jssocial-feed-loaded', true, true);
                box.dispatchEvent(ev);
            }
        } catch (e) {
            // best-effort
        }
    }

    function buildFeedUrl(opts, tab, context) {
        var url = opts.ajaxUrl || '';
        var sep = url.indexOf('?') >= 0 ? '&' : '?';
        var out = url + sep + 'tab=' + encodeURIComponent(tab);
        if (context) {
            out += '&context=' + encodeURIComponent(context);
        }
        return out;
    }

    function requestFeed(url) {
        if (window.jQuery && typeof window.jQuery.ajax === 'function') {
            return new Promise(function (resolve, reject) {
                window.jQuery.ajax({
                    url: url,
                    type: 'GET',
                    dataType: 'json',
                    cache: false,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    success: function (json) {
                        resolve(parseAjaxPayload(json));
                    },
                    error: function (xhr) {
                        var json = xhr.responseJSON;
                        if (!json && xhr.responseText) {
                            try {
                                json = JSON.parse(xhr.responseText);
                            } catch (e) {
                                json = null;
                            }
                        }
                        if (json) {
                            var payload = parseAjaxPayload(json);
                            reject(new Error(payload.error || 'Could not load feed.'));
                            return;
                        }
                        if (xhr.status === 404) {
                            reject(new Error('Feed endpoint not found. Clear Joomla cache and reload.'));
                            return;
                        }
                        reject(new Error('Could not load feed.'));
                    }
                });
            });
        }

        if (typeof window.fetch !== 'function') {
            return Promise.reject(new Error('This browser cannot load feeds.'));
        }

        return fetch(url, {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }
        }).then(function (res) {
            return res.text().then(function (text) {
                var json;
                try {
                    json = text ? JSON.parse(text) : null;
                } catch (e) {
                    throw new Error('Invalid response from server.');
                }
                if (!res.ok && (!json || json.data === undefined)) {
                    throw new Error((json && json.message) ? String(json.message) : ('HTTP ' + res.status));
                }
                return parseAjaxPayload(json);
            });
        });
    }

    function loadBox(box, opts) {
        if (!box || !box.getAttribute('data-jssocial-lazy')) {
            return Promise.resolve(false);
        }

        var tab = box.getAttribute('data-jssocial-tab') || '';
        if (tab === '') {
            return Promise.resolve(false);
        }

        if (isLoaded(box)) {
            return Promise.resolve(true);
        }

        if (isInflight(box)) {
            return Promise.resolve(false);
        }

        if (!opts || !opts.ajaxUrl) {
            showError(box, 'Feed loader is not configured.');
            return Promise.resolve(false);
        }

        setInflight(box, true);
        markLoading(box, true);

        return requestFeed(buildFeedUrl(opts, tab))
            .then(function (payload) {
                if (payload && payload.cache_miss) {
                    var miss = new Error('cache_miss');
                    miss.cacheMiss = true;
                    throw miss;
                }
                if (!payload || !payload.success || !payload.html) {
                    throw new Error((payload && payload.error) ? payload.error : 'Could not load feed.');
                }
                box.innerHTML = payload.html;
                setLoaded(box);
                box.removeAttribute('data-jssocial-lazy');
                box.classList.remove('social_feed_box--lazy', 'social_feed_box--loading');
                notifyLoaded(box);
                notifyFeedCached(opts, tab);
                return true;
            })
            .catch(function (err) {
                showError(box, err && err.message ? err.message : 'Could not load feed.');
                return false;
            })
            .then(function (result) {
                setInflight(box, false);
                markLoading(box, false);
                return result;
            });
    }

    function loadActiveTab(slider, opts) {
        return loadBox(activeLazyBox(slider), opts);
    }

    function bindSlider(slider) {
        var primed = false;

        function prime() {
            if (primed) {
                return;
            }
            primed = true;
            loadActiveTab(slider, optsFromSlider(slider));
        }

        function setHover(on) {
            if (on) {
                slider.classList.add('is-hover');
            } else if (!slider.classList.contains('is-pinned')) {
                slider.classList.remove('is-hover');
            }
        }

        function onTabHover() {
            setHover(true);
            prime();
        }

        slider.addEventListener('mouseenter', onTabHover);
        slider.addEventListener('mouseleave', function () {
            setHover(false);
        });
        slider.addEventListener('focusin', function () {
            setHover(true);
            prime();
        });

        var labels = slider.querySelectorAll(':scope > label');
        var li;
        for (li = 0; li < labels.length; li++) {
            labels[li].addEventListener('mouseenter', onTabHover);
        }

        var radios = slider.querySelectorAll('input[name="tabs"]');
        for (var i = 0; i < radios.length; i++) {
            (function (radio) {
                radio.addEventListener('change', function () {
                    setHover(true);
                    var box = boxForRadio(radio);
                    if (box) {
                        loadBox(box, optsFromSlider(slider));
                    }
                });
            })(radios[i]);
        }
    }

    function loadSocialBar(bar) {
        var tab = bar.getAttribute('data-jssocial-bar-tab') || '';
        var slot = bar.querySelector('[data-jssocial-bar-post]');
        if (!tab || !slot || bar.getAttribute('data-jssocial-bar-loaded') === '1') {
            return;
        }
        if (bar.getAttribute('data-jssocial-bar-inflight') === '1') {
            return;
        }

        var opts = getOptions() || {};
        if (!opts.ajaxUrl && bar.getAttribute('data-jssocial-ajax-url')) {
            opts.ajaxUrl = bar.getAttribute('data-jssocial-ajax-url');
        }

        if (!opts.ajaxUrl) {
            slot.innerHTML = '<p class="jssocial_bar_post_empty">Feed loader is not configured.</p>';
            return;
        }

        bar.setAttribute('data-jssocial-bar-inflight', '1');

        requestFeed(buildFeedUrl(opts, tab, 'social_bar'))
            .then(function (payload) {
                if (payload && payload.cache_miss) {
                    var miss = new Error('cache_miss');
                    miss.cacheMiss = true;
                    throw miss;
                }
                if (!payload || !payload.success || !payload.html) {
                    throw new Error((payload && payload.error) ? payload.error : 'Could not load feed.');
                }
                slot.innerHTML = payload.html;
                bar.setAttribute('data-jssocial-bar-loaded', '1');
                try {
                    if (typeof window.CustomEvent === 'function') {
                        document.dispatchEvent(new CustomEvent('jssocial-feed-cached', {
                            detail: {
                                moduleId: bar.getAttribute('data-jssocial-module-id') || '',
                                tab: bar.getAttribute('data-jssocial-bar-tab') || ''
                            }
                        }));
                    }
                } catch (e2) {
                    // best-effort
                }
            })
            .catch(function (err) {
                if (err && err.cacheMiss) {
                    return;
                }
                slot.innerHTML = '<p class="jssocial_bar_post_empty">' +
                    (err && err.message ? err.message : 'Could not load feed.') + '</p>';
            })
            .then(function () {
                bar.removeAttribute('data-jssocial-bar-inflight');
            });
    }

    function socialBarStorageKey(bar) {
        var moduleId = bar.getAttribute('data-jssocial-module-id') || '0';
        return 'jssocial_bar_closed_' + moduleId;
    }

    function isSocialBarDismissed(bar) {
        if (bar.getAttribute('data-jssocial-bar-remember') !== '1') {
            return false;
        }
        try {
            return window.localStorage.getItem(socialBarStorageKey(bar)) === '1';
        } catch (e) {
            return false;
        }
    }

    function dismissSocialBar(bar) {
        bar.classList.add('is-closed');
        bar.setAttribute('aria-hidden', 'true');
        if (bar.getAttribute('data-jssocial-bar-remember') === '1') {
            try {
                window.localStorage.setItem(socialBarStorageKey(bar), '1');
            } catch (e) {
                // best-effort
            }
        }
    }

    function bindSocialBarClose(bar) {
        if (bar.getAttribute('data-jssocial-bar-closable') !== '1') {
            return;
        }

        var btn = bar.querySelector('[data-jssocial-bar-close]');
        if (!btn) {
            return;
        }

        btn.addEventListener('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            dismissSocialBar(bar);
        });
    }

    function bindSocialBar(bar) {
        if (isSocialBarDismissed(bar)) {
            bar.classList.add('is-closed');
            bar.setAttribute('aria-hidden', 'true');
            return;
        }

        bindSocialBarClose(bar);

        var primed = false;

        function prime() {
            if (primed) {
                return;
            }
            primed = true;
            loadSocialBar(bar);
        }

        bar.addEventListener('mouseenter', prime, { once: true });
        bar.addEventListener('focusin', prime);
        // Do not auto-fetch when the bar scrolls into view — hover/focus only (saves Apify on Facebook etc.).
    }

    function retrySocialBarsFromCache(ev) {
        var detail = (ev && ev.detail) ? ev.detail : {};
        var moduleId = detail.moduleId != null ? String(detail.moduleId) : '';
        var bars = document.querySelectorAll('[data-jssocial-bar="1"]');
        var i;

        for (i = 0; i < bars.length; i++) {
            var bar = bars[i];
            if (bar.getAttribute('data-jssocial-bar-loaded') === '1') {
                continue;
            }
            if (moduleId !== '' && bar.getAttribute('data-jssocial-module-id') !== moduleId) {
                continue;
            }
            if (bar.getAttribute('data-jssocial-bar-inflight') === '1') {
                continue;
            }
            loadSocialBar(bar);
        }
    }

    function boot() {
        var sliders = document.querySelectorAll(ROOT);
        for (var i = 0; i < sliders.length; i++) {
            var slider = sliders[i];
            var opts = optsFromSlider(slider);
            if (!opts.ajaxUrl) {
                continue;
            }
            bindSlider(slider);
        }

        var bars = document.querySelectorAll('[data-jssocial-bar="1"]');
        for (var j = 0; j < bars.length; j++) {
            bindSocialBar(bars[j]);
        }

        document.addEventListener('jssocial-feed-cached', retrySocialBarsFromCache);
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        boot();
    } else if (document.addEventListener) {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        window.attachEvent('onload', boot);
    }
})();
