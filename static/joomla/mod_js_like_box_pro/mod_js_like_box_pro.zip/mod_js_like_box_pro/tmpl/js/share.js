/**
 * JS Like Box PRO — share popup menus on post cards.
 * Menus are portaled to document.body so they aren't clipped by the slider's
 * transform + overflow:hidden stacking context.
 */
(function () {
    'use strict';

    var ROOTS = ['.social_slider_pro', '.jssocial_wall'];
    var SLIDER_SEL = '.social_slider_pro';
    var MENU_SEL = '.jssocial_share_menu';

    function getSlider() {
        return document.querySelector(SLIDER_SEL);
    }

    function isInSlider(el) {
        return !!(el && el.closest && el.closest(SLIDER_SEL));
    }

    function isShareUiTarget(el) {
        if (!el || !el.closest) {
            return false;
        }
        if (el.closest(MENU_SEL)) {
            return true;
        }
        var i;
        for (i = 0; i < ROOTS.length; i++) {
            if (el.closest(ROOTS[i] + ' .jssocial_share_wrap')) {
                return true;
            }
        }
        return false;
    }

    function setPinned(pinned) {
        var slider = getSlider();
        if (slider) {
            slider.classList.toggle('is-pinned', pinned);
        }
    }

    function isOpen(menu) {
        return menu.classList.contains('is-open');
    }

    function shouldPin() {
        var menus = document.querySelectorAll(MENU_SEL + '.is-open');
        var i;
        for (i = 0; i < menus.length; i++) {
            var wrap = getWrap(menus[i]);
            if (wrap && isInSlider(wrap)) {
                return true;
            }
        }
        var slider = getSlider();
        if (slider && slider.matches(':focus-within')) {
            return true;
        }
        return false;
    }

    function syncPinned() {
        setPinned(shouldPin());
    }

    function onSliderFocusOut() {
        window.setTimeout(syncPinned, 250);
    }

    function getWrap(menu) {
        var id = menu.getAttribute('data-wrap-id');
        if (!id) {
            return null;
        }
        var i;
        for (i = 0; i < ROOTS.length; i++) {
            var wrap = document.querySelector(ROOTS[i] + ' .jssocial_share_wrap[data-share-id="' + id + '"]');
            if (wrap) {
                return wrap;
            }
        }
        return null;
    }

    function ensureWrapId(wrap) {
        if (!wrap.getAttribute('data-share-id')) {
            wrap.setAttribute('data-share-id', 's' + Math.random().toString(36).slice(2, 10));
        }
        return wrap.getAttribute('data-share-id');
    }

    function getMenu(wrap) {
        var wrapId = wrap.getAttribute('data-share-id');
        if (wrapId) {
            var floating = document.querySelector(MENU_SEL + '[data-wrap-id="' + wrapId + '"]');
            if (floating) {
                return floating;
            }
        }
        return wrap.querySelector(MENU_SEL);
    }

    function portalMenu(menu, wrap) {
        var wrapId = ensureWrapId(wrap);
        menu.setAttribute('data-wrap-id', wrapId);

        if (!menu.__anchor) {
            menu.__anchor = document.createComment('share-menu');
            wrap.insertBefore(menu.__anchor, menu);
        }

        if (menu.parentNode !== document.body) {
            document.body.appendChild(menu);
        }

        menu.classList.add('jssocial_share_menu--floating');
        syncMenuTheme(menu, wrap);
    }

    function syncMenuTheme(menu, wrap) {
        var feed = wrap.closest('.jssocial_feed');
        if (!feed) {
            return;
        }
        var style = window.getComputedStyle(feed);
        ['--js-bg', '--js-card', '--js-text', '--js-muted', '--js-border', '--js-hover', '--jssocial-accent'].forEach(function (key) {
            var val = style.getPropertyValue(key);
            if (val) {
                menu.style.setProperty(key, val);
            }
        });
        if (feed.classList.contains('jssocial_feed--rounded_light') || feed.classList.contains('jssocial_feed--rounded_dark')) {
            menu.classList.add('jssocial_share_menu--rounded');
        } else {
            menu.classList.remove('jssocial_share_menu--rounded');
        }
        if (feed.classList.contains('jssocial_feed--rounded_dark') || feed.classList.contains('jssocial_feed--dark') || feed.classList.contains('jssocial_feed--neon')) {
            menu.classList.add('jssocial_share_menu--dark');
        } else {
            menu.classList.remove('jssocial_share_menu--dark');
        }
    }

    function positionMenu(menu, trigger) {
        var rect = trigger.getBoundingClientRect();
        var menuWidth = menu.offsetWidth || 210;
        var menuHeight = menu.offsetHeight || 200;
        var left = rect.right - menuWidth;
        var top = rect.top - menuHeight - 8;

        if (left < 8) {
            left = 8;
        }
        if (top < 8) {
            top = rect.bottom + 8;
        }
        if (left + menuWidth > window.innerWidth - 8) {
            left = window.innerWidth - menuWidth - 8;
        }

        menu.style.left = left + 'px';
        menu.style.top = top + 'px';
    }

    function showMenu(menu, trigger, wrap) {
        portalMenu(menu, wrap);
        menu.hidden = false;
        menu.classList.add('is-open');
        trigger.setAttribute('aria-expanded', 'true');
        positionMenu(menu, trigger);
    }

    function hideMenu(menu) {
        var wrap = getWrap(menu);
        var trigger = wrap && wrap.querySelector('.jssocial_share');

        menu.hidden = true;
        menu.classList.remove('is-open');
        menu.style.left = '';
        menu.style.top = '';

        if (trigger) {
            trigger.setAttribute('aria-expanded', 'false');
        }
    }

    function closeAll(except) {
        document.querySelectorAll(MENU_SEL).forEach(function (menu) {
            if (menu === except) {
                return;
            }
            hideMenu(menu);
        });
        syncPinned();
    }

    function openMenu(menu, trigger, wrap) {
        closeAll(menu);
        showMenu(menu, trigger, wrap);
        if (isInSlider(wrap)) {
            setPinned(true);
        }
    }

    function copyUrl(url, labelEl) {
        var done = function () {
            if (!labelEl) {
                return;
            }
            var original = labelEl.textContent;
            labelEl.textContent = 'Copied!';
            window.setTimeout(function () {
                labelEl.textContent = original;
            }, 1500);
        };

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(done).catch(fallback);
            return;
        }

        fallback();

        function fallback() {
            var input = document.createElement('textarea');
            input.value = url;
            input.setAttribute('readonly', '');
            input.style.position = 'fixed';
            input.style.left = '-9999px';
            document.body.appendChild(input);
            input.select();
            try {
                document.execCommand('copy');
                done();
            } catch (e) {
                // ignore
            }
            document.body.removeChild(input);
        }
    }

    function onDocumentClick(e) {
        if (isShareUiTarget(e.target)) {
            return;
        }
        closeAll(null);
    }

    function onKeyDown(e) {
        if (e.key === 'Escape') {
            closeAll(null);
        }
    }

    function onResize() {
        document.querySelectorAll(MENU_SEL + '.is-open').forEach(function (menu) {
            var wrap = getWrap(menu);
            var trigger = wrap && wrap.querySelector('.jssocial_share');
            if (trigger) {
                positionMenu(menu, trigger);
            }
        });
    }

    function bindShareTrigger(trigger) {
        if (!trigger || trigger.dataset.jssocialShareBound === '1') {
            return;
        }
        trigger.dataset.jssocialShareBound = '1';
        trigger.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var wrap = trigger.closest('.jssocial_share_wrap');
            var menu = wrap && getMenu(wrap);
            if (!wrap || !menu) {
                return;
            }
            if (!isOpen(menu)) {
                openMenu(menu, trigger, wrap);
            } else {
                hideMenu(menu);
                syncPinned();
            }
        });
    }

    function bindSharesIn(root) {
        var triggers;
        if (root && root.querySelectorAll && root !== document) {
            triggers = root.querySelectorAll('.jssocial_share');
        } else {
            var list = [];
            ROOTS.forEach(function (sel) {
                document.querySelectorAll(sel + ' .jssocial_share').forEach(function (node) {
                    list.push(node);
                });
            });
            triggers = list;
        }
        triggers.forEach(bindShareTrigger);
    }

    function init() {
        document.addEventListener('click', onDocumentClick);
        document.addEventListener('keydown', onKeyDown);
        window.addEventListener('resize', onResize);

        var slider = getSlider();
        if (slider) {
            slider.addEventListener('focusin', syncPinned);
            slider.addEventListener('focusout', onSliderFocusOut);
        }

        bindSharesIn(document);

        document.addEventListener('click', function (e) {
            var copyBtn = e.target.closest(MENU_SEL + ' .jssocial_share_item--copy');
            if (!copyBtn) {
                return;
            }
            e.preventDefault();
            e.stopPropagation();
            var url = copyBtn.getAttribute('data-url') || '';
            if (url === '') {
                return;
            }
            copyUrl(url, copyBtn.querySelector('.jssocial_share_item_label'));
            closeAll(null);
        });

        document.addEventListener('click', function (e) {
            var link = e.target.closest(MENU_SEL + ' a.jssocial_share_item');
            if (link) {
                closeAll(null);
            }
        });

        document.addEventListener('jssocial-feed-loaded', function (e) {
            if (e.target && e.target.closest) {
                bindSharesIn(e.target);
            }
        });

        document.addEventListener('jssocial-init-shares', function (e) {
            var root = (e.detail && e.detail.root) ? e.detail.root : document;
            bindSharesIn(root);
        });
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        init();
    } else {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    }
})();
