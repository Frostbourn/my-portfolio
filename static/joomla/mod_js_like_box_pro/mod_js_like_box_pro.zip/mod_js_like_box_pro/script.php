<?php
/**
 * mod_js_like_box_pro install/upgrade script.
 */

defined('_JEXEC') or die;

class Mod_js_like_box_proInstallerScript
{
    public function postflight($type, $parent)
    {
        if ($type === 'uninstall') {
            return;
        }

        $this->clearFeedCache();
        $this->clearPageCache();
    }

    private function clearFeedCache()
    {
        $dir = JPATH_CACHE . '/mod_js_like_box_pro';
        if (!is_dir($dir)) {
            return;
        }

        $removed = 0;
        foreach (glob($dir . '/*.json') ?: array() as $file) {
            if (@unlink($file)) {
                $removed++;
            }
        }

        if ($removed > 0) {
            JFactory::getApplication()->enqueueMessage(
                'JS Like Box PRO: cleared ' . $removed . ' cached feed file(s).',
                'message'
            );
        }
    }

    private function clearPageCache()
    {
        try {
            $cache = JFactory::getCache('', 'callback');
            $cache->clean('page');
        } catch (Exception $e) {
            // Ignore cache backend issues.
        }
    }
}
