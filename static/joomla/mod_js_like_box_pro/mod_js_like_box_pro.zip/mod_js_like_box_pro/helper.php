<?php

/**
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @link       https://jsns.eu
 */

defined('_JEXEC') or die('Restricted access');

require_once __DIR__ . '/joomla-compat.php';

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

/**
 * Server-side helper for JS Like Box PRO.
 *
 * All API calls are made server-side so the customer api_key never reaches the
 * browser. Feed payloads are cached on disk to reduce round-trips; the meta
 * block (usage + fresh beacon token) is fetched separately on every request.
 */
class ModJsLikeBoxProHelper
{
    /** Hosted Like Box API (built into the module; not configurable in admin). */
    const API_BASE_URL = 'https://socialproof.pl/api';

    /** jsns.eu customer dashboard — API keys and usage. */
    const DASHBOARD_URL = 'https://jsns.eu/user/api-keys';

    /** jsns.eu plan upgrade page. */
    const UPGRADE_URL = 'https://jsns.eu/user/upgrade-plan';

    /** Disk cache lifetime for feed payloads (seconds). */
    const FEED_TTL = 1800;

    // -------------------------------------------------------------------------
    // Joomla 3.10 / 4 / 5 / 6 compatibility helpers
    // -------------------------------------------------------------------------

    /** @return bool */
    public static function isJoomla4()
    {
        return defined('JVERSION') && version_compare(JVERSION, '4.0', 'ge');
    }

    /** Exact usage percent (0–100, one decimal). */
    public static function usagePercent($used, $limit)
    {
        $used  = (int) $used;
        $limit = (int) $limit;
        if ($limit <= 0 || $used <= 0) {
            return 0.0;
        }

        return min(100.0, round(($used / $limit) * 100, 1));
    }

    /** Bar width percent — keeps a visible slice for any non-zero usage. */
    public static function usageBarPercent($used, $limit)
    {
        $pct = self::usagePercent($used, $limit);
        if ($pct > 0 && $pct < 2) {
            return 2.0;
        }

        return $pct;
    }

    /** CSRF check for contact-form POST. */
    public static function checkPostToken()
    {
        if (self::isJoomla4()) {
            return Session::checkToken('post');
        }

        jimport('joomla.session.session');

        return JSession::checkToken('post');
    }

    /** Append cache-buster query param (J3 asset URLs). */
    public static function appendAssetVersion($url, $version)
    {
        if ($version === '' || $version === null) {
            return $url;
        }

        $sep = (strpos($url, '?') !== false) ? '&' : '?';

        return $url . $sep . 'v=' . rawurlencode((string) $version);
    }

    /** Register a stylesheet. */
    public static function addDocumentStyleSheet($document, $url, $version = '')
    {
        if (self::isJoomla4()) {
            $options = ($version !== '') ? array('version' => (string) $version) : array();
            $document->addStyleSheet($url, $options);

            return;
        }

        $document->addStyleSheet(self::appendAssetVersion($url, $version));
    }

    /** Register a script. */
    public static function addDocumentScript($document, $url, $version = '', $defer = true)
    {
        if (self::isJoomla4()) {
            $options = ($version !== '') ? array('version' => (string) $version) : array();
            $attrs   = $defer ? array('defer' => 'defer') : array();
            $document->addScript($url, $options, $attrs);

            return;
        }

        $document->addScript(self::appendAssetVersion($url, $version), 'text/javascript', $defer, false);
    }

    /** Joomla 3.10: ensure jQuery is present for com_ajax feed loading. */
    public static function ensureJQuery()
    {
        if (self::isJoomla4()) {
            return;
        }

        jimport('joomla.html.html');
        if (class_exists('JHtml', false)) {
            JHtml::_('jquery.framework');
        }
    }

    /** Pass JSON config to frontend (Joomla.getOptions / optionsStorage fallback). */
    public static function addDocumentScriptOptions($document, $key, array $options)
    {
        if (method_exists($document, 'addScriptOptions')) {
            $document->addScriptOptions($key, $options);

            return;
        }

        $json = json_encode(array($key => $options));
        if ($json === false) {
            return;
        }

        $document->addScriptDeclaration(
            '(function(){var _o=' . $json . ';'
            . 'window.Joomla=window.Joomla||{};'
            . 'Joomla.optionsStorage=Joomla.optionsStorage||{};'
            . 'for(var _k in _o){if(Object.prototype.hasOwnProperty.call(_o,_k)){Joomla.optionsStorage[_k]=_o[_k];}}'
            . '})();'
        );
    }

    /** Tab order in the slider (add new platforms here and in platforms()). */
    const PLATFORM_ORDER = array('facebook', 'twitter', 'instagram', 'youtube', 'linkedin', 'tiktok', 'pinterest', 'telegram');

    /**
     * Single source of truth for built-in social tabs.
     * Keep accent colours in sync with tmpl/css/style.scss.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function platforms()
    {
        return array(
            'facebook' => array(
                'label'           => 'facebook',
                'tab_class'       => 'facebook_icon',
                'icon'            => 'fab fa-facebook-f',
                'feed_icon'       => 'fa-facebook-f',
                'accent'          => '#3289d9',
                'endpoint'        => 'facebook',
                'api_param'       => 'page_id',
                'enabled_key'     => 'facebook_enabled',
                'id_key'          => 'facebook_username',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Like Page',
            ),
            'twitter' => array(
                'label'           => 'x',
                'tab_class'       => 'twitter_icon',
                'icon'            => 'fab fa-x-twitter',
                'feed_icon'       => 'fa-x-twitter',
                'accent'          => '#000000',
                'endpoint'        => 'x',
                'api_param'       => 'username',
                'enabled_key'     => 'twitter_enabled',
                'id_key'          => 'twitter_username',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'instagram' => array(
                'label'           => 'instagram',
                'tab_class'       => 'instagram_icon',
                'icon'            => 'fab fa-instagram',
                'feed_icon'       => 'fa-instagram',
                'accent'          => '#5851db',
                'endpoint'        => 'instagram',
                'api_param'       => 'username',
                'enabled_key'     => 'instagram_enabled',
                'id_key'          => 'instagram_username',
                'columns_key'     => null,
                'default_columns' => 1,
                'cta'             => 'Follow',
            ),
            'youtube' => array(
                'label'           => 'youtube',
                'tab_class'       => 'youtube_icon',
                'icon'            => 'fab fa-youtube',
                'feed_icon'       => 'fa-youtube',
                'accent'          => '#ff0000',
                'endpoint'        => 'youtube',
                'api_param'       => 'channel',
                'enabled_key'     => 'youtube_enabled',
                'id_key'          => 'youtube_channel',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Subscribe',
            ),
            'linkedin' => array(
                'label'           => 'linkedin',
                'tab_class'       => 'linkedin_icon',
                'icon'            => 'fab fa-linkedin-in',
                'feed_icon'       => 'fa-linkedin-in',
                'accent'          => '#0A66C2',
                'endpoint'        => 'linkedin',
                'api_param'       => 'account',
                'enabled_key'     => 'linkedin_enabled',
                'id_key'          => 'linkedin_company',
                'type_key'        => 'linkedin_type',
                'default_type'    => 'company',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'tiktok' => array(
                'label'           => 'tiktok',
                'tab_class'       => 'tiktok_icon',
                'icon'            => 'fab fa-tiktok',
                'feed_icon'       => 'fa-tiktok',
                'accent'          => '#000000',
                'endpoint'        => 'tiktok',
                'api_param'       => 'username',
                'enabled_key'     => 'tiktok_enabled',
                'id_key'          => 'tiktok_username',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'pinterest' => array(
                'label'           => 'pinterest',
                'tab_class'       => 'pinterest_icon',
                'icon'            => 'fab fa-pinterest-p',
                'feed_icon'       => 'fa-pinterest-p',
                'accent'          => '#E60023',
                'endpoint'        => 'pinterest',
                'api_param'       => 'account',
                'enabled_key'     => 'pinterest_enabled',
                'id_key'          => 'pinterest_account',
                'type_key'        => 'pinterest_type',
                'default_type'    => 'profile',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Follow',
            ),
            'telegram' => array(
                'label'           => 'telegram',
                'tab_class'       => 'telegram_icon',
                'icon'            => 'fab fa-telegram',
                'feed_icon'       => 'fa-telegram',
                'accent'          => '#26A5E4',
                'endpoint'        => 'telegram',
                'api_param'       => 'channel',
                'enabled_key'     => 'telegram_enabled',
                'id_key'          => 'telegram_channel',
                'columns_key'     => null,
                'default_columns' => 2,
                'cta'             => 'Join Channel',
            ),
            'google_reviews' => array(
                'label'           => 'google',
                'tab_class'       => 'testimonials_icon',
                'icon'            => 'fab fa-google',
                'feed_icon'       => 'fa-google',
                'accent'          => '#4285F4',
                'endpoint'        => 'google_reviews',
                'api_param'       => 'place',
                'enabled_key'     => 'google_reviews_place',
                'id_key'          => 'google_reviews_place',
                'columns_key'     => null,
                'default_columns' => 1,
                'cta'             => 'Reviews',
            ),
        );
    }

    /** @return array<string, array<string, mixed>>|null */
    public static function getPlatform($slug)
    {
        $slug = strtolower(trim((string) $slug));
        if ($slug === 'x') {
            $slug = 'twitter';
        }
        $all = self::platforms();

        return isset($all[$slug]) ? $all[$slug] : null;
    }

    /** Radio input id for the nth feed tab (tabOne … tabTen, then tab_N). */
    public static function tabRadioId($index)
    {
        $words = array('One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten');

        return isset($words[$index]) ? 'tab' . $words[$index] : 'tab_' . (int) $index;
    }

    /** Public profile URL used by the mobile bar and feed cards. */
    public static function buildProfileUrl($platform, $identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return 'https://jsns.eu';
        }
        if ($platform === 'linkedin') {
            return self::linkedInProfileUrl($identifier);
        }
        if ($platform === 'tiktok') {
            $username = self::normalizeTikTokIdentifier($identifier);
            return $username !== '' ? ('https://www.tiktok.com/@' . $username) : 'https://jsns.eu';
        }
        if ($platform === 'pinterest') {
            return self::pinterestProfileUrl($identifier);
        }
        if ($platform === 'telegram') {
            $channel = self::normalizeTelegramChannel($identifier);
            return $channel !== '' ? ('https://t.me/' . rawurlencode($channel)) : 'https://jsns.eu';
        }
        if (stripos($identifier, 'http') === 0) {
            return $identifier;
        }

        switch ($platform) {
            case 'instagram':
                return 'https://instagram.com/' . ltrim($identifier, '@');
            case 'twitter':
            case 'x':
                return 'https://x.com/' . ltrim($identifier, '@');
            case 'facebook':
                if (ctype_digit(ltrim($identifier, '@/'))) {
                    return 'https://www.facebook.com/profile.php?id=' . ltrim($identifier, '@/');
                }
                return 'https://www.facebook.com/' . ltrim($identifier, '@/');
            case 'youtube':
                return 'https://www.youtube.com/@' . ltrim($identifier, '@');
            case 'tiktok':
                return 'https://www.tiktok.com/@' . self::normalizeTikTokIdentifier($identifier);
            case 'telegram':
                $channel = self::normalizeTelegramChannel($identifier);
                return $channel !== '' ? ('https://t.me/' . rawurlencode($channel)) : 'https://jsns.eu';
            default:
                return 'https://jsns.eu';
        }
    }

    /** Normalize a Telegram channel username or t.me URL. */
    public static function normalizeTelegramChannel($identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (preg_match('~(?:https?://)?(?:www\.)?t\.me/(?:s/)?([^/?#]+)~i', $identifier, $m)) {
            return ltrim($m[1], '@/');
        }

        return ltrim($identifier, '@/');
    }

    /**
     * Normalize a Pinterest admin value to a canonical identifier.
     * Full URLs and user/board paths override the module type switch.
     *
     * @param string $identifier  Slug, board path, or URL from module settings.
     * @param string $type        profile|board
     */
    public static function normalizePinterestIdentifier($identifier, $type = 'profile')
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (preg_match('~^(?:www\.)?pinterest\.com/~i', $identifier) && stripos($identifier, 'http') !== 0) {
            $identifier = 'https://' . ltrim($identifier, '/');
        }

        if (stripos($identifier, 'http') === 0 || preg_match('~pinterest\.com/~i', $identifier)) {
            $path = trim((string) parse_url($identifier, PHP_URL_PATH), '/');
            $parts = array_values(array_filter(explode('/', $path)));
            if (count($parts) >= 2) {
                return $parts[0] . '/' . $parts[1];
            }
            if (!empty($parts[0])) {
                return $parts[0];
            }

            return $identifier;
        }

        $parts = array_values(array_filter(explode('/', str_replace('\\', '/', $identifier))));
        if (count($parts) >= 2) {
            return $parts[0] . '/' . $parts[1];
        }

        $slug = ltrim($identifier, '@/');
        $type = ($type === 'board') ? 'board' : 'profile';

        return $slug;
    }

    /** Public Pinterest profile or board URL for feed links. */
    public static function pinterestProfileUrl($identifier, $type = 'profile')
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return 'https://jsns.eu';
        }

        $normalized = self::normalizePinterestIdentifier($identifier, $type);
        if ($normalized === '') {
            return 'https://jsns.eu';
        }

        if (stripos($identifier, 'http') === 0) {
            return rtrim($identifier, '/') . '/';
        }

        if (strpos($normalized, '/') !== false) {
            $parts = explode('/', $normalized, 2);
            return 'https://www.pinterest.com/' . rawurlencode($parts[0]) . '/' . rawurlencode($parts[1]) . '/';
        }

        return 'https://www.pinterest.com/' . rawurlencode($normalized) . '/';
    }

    /**
     * Normalize a TikTok admin value to a bare @username handle.
     *
     * @param string $identifier  Handle or profile URL from module settings.
     */
    public static function normalizeTikTokIdentifier($identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (filter_var($identifier, FILTER_VALIDATE_URL)) {
            $path = trim((string) parse_url($identifier, PHP_URL_PATH), '/');
            if (preg_match('~^@?([^/]+)~', $path, $m)) {
                return ltrim($m[1], '@');
            }
            $identifier = $path;
        }

        return ltrim($identifier, '@');
    }

    /**
     * Normalize a LinkedIn admin value to a canonical identifier.
     * Full URLs and in/company/ prefixes win over the module type switch.
     *
     * @param string $identifier  Slug or URL from module settings.
     * @param string $type        company|profile
     */
    public static function normalizeLinkedInIdentifier($identifier, $type = 'company')
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        if (preg_match('~^(?:www\.)?linkedin\.com/~i', $identifier) && stripos($identifier, 'http') !== 0) {
            $identifier = 'https://' . ltrim($identifier, '/');
        }

        if (stripos($identifier, 'http') === 0) {
            return $identifier;
        }
        if (stripos($identifier, 'in/') === 0 || stripos($identifier, 'company/') === 0) {
            return $identifier;
        }
        if (preg_match('~linkedin\.com/(in|company)/~i', $identifier)) {
            return stripos($identifier, 'http') === 0 ? $identifier : ('https://' . ltrim($identifier, '/'));
        }

        $slug = ltrim($identifier, '@/');
        $type = ($type === 'profile') ? 'profile' : 'company';

        return $type === 'profile' ? ('in/' . $slug) : ('company/' . $slug);
    }

    /** Profile URL for a normalized LinkedIn identifier. */
    public static function linkedInProfileUrl($identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return 'https://jsns.eu';
        }

        if (preg_match('~^(?:www\.)?linkedin\.com/~i', $identifier) && stripos($identifier, 'http') !== 0) {
            $identifier = 'https://' . ltrim($identifier, '/');
        }

        if (stripos($identifier, 'http') === 0) {
            return $identifier;
        }
        if (stripos($identifier, 'in/') === 0 || stripos($identifier, 'company/') === 0) {
            return 'https://www.linkedin.com/' . ltrim($identifier, '/') . '/';
        }
        if (preg_match('~linkedin\.com/(in|company)/~i', $identifier)) {
            return stripos($identifier, 'http') === 0 ? $identifier : ('https://' . ltrim($identifier, '/'));
        }

        return 'https://www.linkedin.com/company/' . ltrim($identifier, '@/') . '/';
    }

    /**
     * Build one enabled feed tab from module params, or null when disabled/empty.
     *
     * @param object $params  Joomla module params.
     * @param bool   $lazy    When true, skip the API call and render a placeholder.
     */
    public static function buildFeedEntry($slug, $params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12, $lazy = false, $showFeedPosts = true)
    {
        $cfg = self::getPlatform($slug);
        if ($cfg === null || !(int) $params->get($cfg['enabled_key'], 0)) {
            return null;
        }

        $identifier = trim((string) $params->get($cfg['id_key']));
        if ($identifier === '') {
            return null;
        }

        if ($slug === 'linkedin') {
            $typeKey = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'linkedin_type';
            $liType  = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'company');
            $identifier = self::normalizeLinkedInIdentifier($identifier, $liType);
        } elseif ($slug === 'tiktok') {
            $identifier = self::normalizeTikTokIdentifier($identifier);
        } elseif ($slug === 'pinterest') {
            $typeKey = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'pinterest_type';
            $pinType = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'profile');
            $identifier = self::normalizePinterestIdentifier($identifier, $pinType);
        } elseif ($slug === 'telegram') {
            $identifier = self::normalizeTelegramChannel($identifier);
        }

        $extraType = '';
        if ($slug === 'linkedin') {
            $extraType = $liType;
        } elseif ($slug === 'pinterest') {
            $extraType = $pinType;
        }

        $columns = (int) $cfg['default_columns'];
        if (!empty($cfg['columns_key'])) {
            $columns = (int) $params->get($cfg['columns_key'], $columns);
        }

        $profileUrl = self::buildProfileUrl($slug, $identifier);
        if ($slug === 'pinterest') {
            $profileUrl = self::pinterestProfileUrl($identifier, $extraType);
        }

        $fetchLimit = $showFeedPosts ? (int) $postsLimit : 1;

        $entry = array(
            'key'         => $slug,
            'label'       => $cfg['label'],
            'class'       => $cfg['tab_class'],
            'icon'        => $cfg['icon'],
            'accent'      => $cfg['accent'],
            'profile_url' => $profileUrl,
            'html'        => $lazy
                ? self::renderFeedPlaceholder($slug, $theme)
                : self::renderPlatformFeedHtml($slug, $params, $apiUrl, $apiKey, $widgetId, $theme, $fetchLimit, $showFeedPosts),
        );

        if ($lazy) {
            $entry['lazy'] = true;
        }

        return $entry;
    }

    /**
     * Fetch and render one platform feed tab (used on page load and lazy AJAX).
     *
     * @param object $params Joomla module params.
     */
    public static function renderPlatformFeedHtml($slug, $params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12, $showFeedPosts = true, $syncCold = false)
    {
        $resolved = self::resolvePlatformIdentifier($slug, $params);
        if ($resolved === null) {
            return '';
        }

        $cfg = self::getPlatform($slug);
        $columns = (int) $cfg['default_columns'];
        if (!empty($cfg['columns_key'])) {
            $columns = (int) $params->get($cfg['columns_key'], $columns);
        }

        $identifier = $resolved['identifier'];
        $profileUrl = self::buildProfileUrl($slug, $identifier);
        if ($slug === 'pinterest') {
            $profileUrl = self::pinterestProfileUrl($identifier, $resolved['type']);
        }

        $limit = (int) $postsLimit;
        $data  = self::getFeed($apiUrl, $apiKey, $slug, $identifier, $widgetId, $limit, $resolved['type'], $syncCold);
        if (!$syncCold && self::needsBlockingFeedFetch($slug, $data, $showFeedPosts)) {
            $data = self::getFeed($apiUrl, $apiKey, $slug, $identifier, $widgetId, $limit, $resolved['type'], true);
        }

        return self::renderFeed(
            $slug,
            $data,
            $profileUrl,
            $identifier,
            $columns,
            $apiUrl,
            $theme,
            $showFeedPosts
        );
    }

    /** First enabled social platform slug, or empty string. */
    public static function getFirstEnabledPlatformSlug($params)
    {
        foreach (self::PLATFORM_ORDER as $slug) {
            if (self::resolvePlatformIdentifier($slug, $params) !== null) {
                return $slug;
            }
        }

        return '';
    }

    /** Collect icon links for the social proof bar (no API). */
    public static function collectSocialBarLinks($params)
    {
        $links = array();
        foreach (self::PLATFORM_ORDER as $slug) {
            $resolved = self::resolvePlatformIdentifier($slug, $params);
            if ($resolved === null) {
                continue;
            }
            $cfg = self::getPlatform($slug);
            if ($cfg === null) {
                continue;
            }
            $profileUrl = self::buildProfileUrl($slug, $resolved['identifier']);
            if ($slug === 'pinterest') {
                $profileUrl = self::pinterestProfileUrl($resolved['identifier'], $resolved['type']);
            }
            $links[] = array(
                'slug'  => $slug,
                'url'   => $profileUrl,
                'icon'  => $cfg['icon'],
                'label' => $cfg['label'],
                'accent'=> $cfg['accent'],
            );
        }

        return $links;
    }

    /** Shell HTML for the social proof bar (icons + lazy post slot). */
    public static function renderSocialBarShell($params, $theme, $position, $align, $moduleId, $ajaxUrl)
    {
        $links = self::collectSocialBarLinks($params);
        if ($links === []) {
            return '';
        }

        $theme    = self::normalizeTheme($theme);
        $position = ($position === 'top') ? 'top' : 'bottom';
        $align    = in_array($align, array('left', 'right', 'center'), true) ? $align : 'center';
        $first    = self::getFirstEnabledPlatformSlug($params);
        $closable = (int) $params->get('social_bar_closable', 1) === 1;
        $remember = (int) $params->get('social_bar_remember_close', 1) === 1;

        ob_start();
        ?>
        <div class="jssocial_bar jssocial_bar--<?php echo htmlspecialchars($position); ?> jssocial_bar--align-<?php echo htmlspecialchars($align); ?> jssocial_bar--<?php echo htmlspecialchars($theme); ?>"
             data-jssocial-bar="1"
             data-jssocial-bar-tab="<?php echo htmlspecialchars($first); ?>"
             data-jssocial-module-id="<?php echo (int) $moduleId; ?>"
             data-jssocial-ajax-url="<?php echo htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>"
             <?php echo $closable ? ' data-jssocial-bar-closable="1"' : ''; ?>
             <?php echo $remember ? ' data-jssocial-bar-remember="1"' : ''; ?>>
            <div class="jssocial_bar_inner">
                <div class="jssocial_bar_icons" aria-label="Social profiles">
                    <?php foreach ($links as $link) : ?>
                        <a class="jssocial_bar_icon jssocial_bar_icon--<?php echo htmlspecialchars($link['slug']); ?>"
                           href="<?php echo htmlspecialchars($link['url']); ?>"
                           target="_blank" rel="noopener"
                           style="--jssocial-accent: <?php echo htmlspecialchars($link['accent']); ?>;"
                           title="<?php echo htmlspecialchars(ucfirst($link['label'])); ?>">
                            <i class="<?php echo htmlspecialchars($link['icon']); ?>" aria-hidden="true"></i>
                        </a>
                    <?php endforeach; ?>
                </div>
                <div class="jssocial_bar_post" data-jssocial-bar-post="1" aria-live="polite">
                    <div class="jssocial_bar_post_skeleton" aria-hidden="true">
                        <span class="jssocial_bar_post_sk_thumb"></span>
                        <span class="jssocial_bar_post_sk_lines">
                            <span class="jssocial_bar_post_sk_line"></span>
                            <span class="jssocial_bar_post_sk_line jssocial_bar_post_sk_line--short"></span>
                        </span>
                    </div>
                </div>
                <?php if ($closable) : ?>
                    <button type="button" class="jssocial_bar_close" data-jssocial-bar-close="1" aria-label="Close social bar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <?php

        return ob_get_clean();
    }

    /** Compact latest-post preview for the social proof bar. */
    public static function renderSocialBarPost($platform, $data, $theme = 'light', $apiUrl = '')
    {
        if (!is_array($data)) {
            return '';
        }

        $posts = isset($data['posts']) && is_array($data['posts']) ? $data['posts'] : array();
        $post = self::pickSocialBarPost($posts);
        if (!is_array($post)) {
            return '<p class="jssocial_bar_post_empty">No recent posts.</p>';
        }
        $meta = self::platformMeta($platform);
        $theme = self::normalizeTheme($theme);
        $url   = (string) ($post['url'] ?? '');
        $caption = trim(strip_tags((string) ($post['caption'] ?? '')));
        if (strlen($caption) > 120) {
            $caption = substr($caption, 0, 117) . '…';
        }
        $image = (string) ($post['image'] ?? '');
        if ($image === '' && is_array($post['video'] ?? null) && !empty($post['video']['thumb'])) {
            $image = (string) $post['video']['thumb'];
        }
        if ($image !== '' && $apiUrl !== '') {
            $image = self::proxied($apiUrl, $image);
        }

        ob_start();
        ?>
        <a class="jssocial_bar_post_link jssocial_bar_post_link--<?php echo htmlspecialchars($platform); ?>"
           href="<?php echo htmlspecialchars($url !== '' ? $url : '#'); ?>"
           <?php echo $url !== '' ? 'target="_blank" rel="noopener"' : ''; ?>
           style="--jssocial-accent: <?php echo htmlspecialchars($meta['accent']); ?>;">
            <?php if ($image !== '') : ?>
                <span class="jssocial_bar_post_thumb" style="background-image:url('<?php echo htmlspecialchars($image, ENT_QUOTES); ?>')"></span>
            <?php else : ?>
                <span class="jssocial_bar_post_thumb jssocial_bar_post_thumb--icon"><i class="<?php echo htmlspecialchars($meta['icon']); ?>"></i></span>
            <?php endif; ?>
            <span class="jssocial_bar_post_text">
                <span class="jssocial_bar_post_label"><?php echo htmlspecialchars(ucfirst($platform)); ?></span>
                <?php if ($caption !== '') : ?>
                    <span class="jssocial_bar_post_caption"><?php echo htmlspecialchars($caption); ?></span>
                <?php endif; ?>
            </span>
        </a>
        <?php

        return ob_get_clean();
    }

    /**
     * Newest post that is not a Facebook event and has a caption.
     * Events sort first when their start time is in the future.
     *
     * @param array<int, mixed> $posts
     * @return array|null
     */
    private static function pickSocialBarPost(array $posts)
    {
        $fallback = null;
        foreach ($posts as $post) {
            if (!is_array($post) || self::isSocialBarEvent($post)) {
                continue;
            }
            if ($fallback === null) {
                $fallback = $post;
            }
            $caption = trim(strip_tags((string) ($post['caption'] ?? '')));
            if ($caption !== '') {
                return $post;
            }
        }

        return $fallback;
    }

    /** Facebook event listings are not post descriptions. */
    private static function isSocialBarEvent(array $post)
    {
        $url = strtolower((string) ($post['url'] ?? ''));
        if ($url !== '' && (strpos($url, '/events') !== false || strpos($url, 'events.php') !== false)) {
            return true;
        }

        $caption = strtolower(trim(strip_tags((string) ($post['caption'] ?? ''))));

        return $caption === 'event' || $caption === 'events';
    }

    /**
     * Latest post for the social bar — prefer tab disk cache, else one API fetch.
     *
     * @return array{slug:string,data:array}|null
     */
    private static function resolveSocialBarFeed(Registry $params, array $ctx)
    {
        foreach (self::PLATFORM_ORDER as $slug) {
            $resolved = self::resolvePlatformIdentifier($slug, $params);
            if ($resolved === null) {
                continue;
            }
            $data = self::getFeedFromModuleCache(
                $slug,
                $resolved['identifier'],
                12,
                $resolved['type'],
                true
            );
            if (is_array($data) && self::feedHasPosts($data)) {
                return array(
                    'slug' => $slug,
                    'data' => $data,
                );
            }
        }

        $slug = self::getFirstEnabledPlatformSlug($params);
        if ($slug === '') {
            return null;
        }

        $resolved = self::resolvePlatformIdentifier($slug, $params);
        if ($resolved === null) {
            return null;
        }

        $apiUrl   = (string) $ctx['api_url'];
        $apiKey   = (string) $ctx['api_key'];
        $widgetId = (string) $ctx['widget_id'];

        $data = self::getFeed(
            $apiUrl,
            $apiKey,
            $slug,
            $resolved['identifier'],
            $widgetId,
            12,
            $resolved['type'],
            false
        );
        if (self::needsBlockingFeedFetch($slug, $data, true)) {
            $data = self::getFeed(
                $apiUrl,
                $apiKey,
                $slug,
                $resolved['identifier'],
                $widgetId,
                12,
                $resolved['type'],
                true
            );
        }

        if (!is_array($data) || !self::feedHasPosts($data)) {
            return null;
        }

        return array(
            'slug' => $slug,
            'data' => $data,
        );
    }

    /** Skeleton shown until a lazy tab is loaded on hover or click. */
    public static function renderFeedPlaceholder($slug, $theme = 'light')
    {
        $meta  = self::platformMeta($slug === 'unified' ? 'facebook' : $slug);
        $theme = self::normalizeTheme($theme);
        $platform = $slug === 'unified' ? 'unified' : $slug;

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo htmlspecialchars($theme); ?> jssocial_feed--<?php echo htmlspecialchars($platform); ?> jssocial_feed--pending" style="--jssocial-accent: <?php echo htmlspecialchars($meta['accent']); ?>;">
            <div class="jssocial_feed_skeleton" aria-busy="true" aria-live="polite">
                <span class="jssocial_sr_only">Loading feed</span>
                <div class="jssocial_feed_skeleton_profile">
                    <div class="jssocial_sk jssocial_sk_cover"></div>
                    <div class="jssocial_feed_skeleton_profile_body">
                        <div class="jssocial_sk jssocial_sk_avatar"></div>
                        <div class="jssocial_feed_skeleton_lines">
                            <div class="jssocial_sk jssocial_sk_line jssocial_sk_line--lg"></div>
                            <div class="jssocial_sk jssocial_sk_line jssocial_sk_line--sm"></div>
                            <div class="jssocial_feed_skeleton_stats">
                                <div class="jssocial_sk jssocial_sk_pill"></div>
                                <div class="jssocial_sk jssocial_sk_pill"></div>
                                <div class="jssocial_sk jssocial_sk_pill"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="jssocial_feed_skeleton_posts">
                    <div class="jssocial_sk_card">
                        <div class="jssocial_sk jssocial_sk_media"></div>
                        <div class="jssocial_sk jssocial_sk_line"></div>
                        <div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div>
                    </div>
                    <div class="jssocial_sk_card">
                        <div class="jssocial_sk jssocial_sk_media"></div>
                        <div class="jssocial_sk jssocial_sk_line"></div>
                        <div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div>
                    </div>
                </div>
                <div class="jssocial_feed_skeleton_spinner" aria-hidden="true">
                    <span class="jssocial_feed_skeleton_spinner_ring"></span>
                </div>
            </div>
        </div>
        <?php

        return ob_get_clean();
    }

    /**
     * Build optional feature tabs: unified feed, contact, WhatsApp, testimonials.
     * Order: unified → contact → WhatsApp → Calendly → FAQ → testimonials.
     * Platform feeds are merged before these in mod_js_like_box_pro.php.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function buildSpecialTabs($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12, $beaconToken = '', $moduleId = 0, $lazyApiFeeds = true)
    {
        $tabs = array();

        if ((int) $params->get('unified_feed_enabled', 0) === 1) {
            $entry = self::buildUnifiedFeedEntry($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit, $lazyApiFeeds);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('contact_enabled', 0) === 1) {
            $entry = self::buildContactEntry($params, $theme, $moduleId);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('whatsapp_enabled', 0) === 1) {
            $entry = self::buildWhatsAppEntry($params, $theme);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        // ponytail: Calendly tab is parked; leave builder in place if we turn it back on.

        if ((int) $params->get('faq_enabled', 0) === 1) {
            $entry = self::buildFaqEntry($params, $theme);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        if ((int) $params->get('testimonials_enabled', 0) === 1) {
            $entry = self::buildTestimonialsEntry($params, $theme, $apiUrl, $apiKey, $widgetId, $postsLimit, $lazyApiFeeds);
            if ($entry !== null) {
                $tabs[] = $entry;
            }
        }

        return $tabs;
    }

    /** @return array{slug:string,identifier:string,type:string}|null */
    private static function resolvePlatformIdentifier($slug, $params)
    {
        $cfg = self::getPlatform($slug);
        if ($cfg === null || (int) $params->get($cfg['enabled_key'], 0) !== 1) {
            return null;
        }

        $identifier = trim((string) $params->get($cfg['id_key']));
        if ($identifier === '') {
            return null;
        }

        $type = '';
        if ($slug === 'linkedin') {
            $typeKey    = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'linkedin_type';
            $type       = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'company');
            $identifier = self::normalizeLinkedInIdentifier($identifier, $type);
        } elseif ($slug === 'tiktok') {
            $identifier = self::normalizeTikTokIdentifier($identifier);
        } elseif ($slug === 'pinterest') {
            $typeKey    = !empty($cfg['type_key']) ? (string) $cfg['type_key'] : 'pinterest_type';
            $type       = (string) $params->get($typeKey, isset($cfg['default_type']) ? $cfg['default_type'] : 'profile');
            $identifier = self::normalizePinterestIdentifier($identifier, $type);
        } elseif ($slug === 'telegram') {
            $identifier = self::normalizeTelegramChannel($identifier);
        }

        if ($identifier === '') {
            return null;
        }

        return array('slug' => $slug, 'identifier' => $identifier, 'type' => $type);
    }

    /** @return array<int, array{slug:string,identifier:string,type:string}> */
    public static function collectEnabledPlatforms($params)
    {
        $out = array();
        foreach (self::PLATFORM_ORDER as $slug) {
            $resolved = self::resolvePlatformIdentifier($slug, $params);
            if ($resolved !== null) {
                $out[] = $resolved;
            }
        }

        return $out;
    }

    /**
     * Merge per-platform feeds from module disk cache only (filled when slider tabs load).
     *
     * @return array<string, array>|null  platform slug => feed payload
     */
    private static function aggregatePlatformFeedsFromCache($params, $limit, $minPlatforms = 1)
    {
        $enabled = self::collectEnabledPlatforms($params);
        if (count($enabled) < $minPlatforms) {
            return null;
        }

        $results = array();
        foreach ($enabled as $item) {
            $slug = (string) $item['slug'];
            $type = isset($item['type']) ? (string) $item['type'] : '';
            $data = self::getFeedFromModuleCache($slug, $item['identifier'], (int) $limit, $type, true);
            if (is_array($data) && self::feedHasContent($slug, $data)) {
                $results[$slug] = $data;
            }
        }

        if (count($results) < $minPlatforms) {
            return null;
        }

        return $results;
    }

    /**
     * Merge per-platform feeds using the same versioned disk cache as tabs.
     * Avoids a separate unified cache layer that can serve stale TikTok image URLs.
     *
     * @return array<string, array>|null  platform slug => feed payload
     */
    private static function aggregatePlatformFeeds($apiUrl, $apiKey, $params, $widgetId, $limit, $minPlatforms = 2)
    {
        $enabled = self::collectEnabledPlatforms($params);
        if (count($enabled) < $minPlatforms) {
            return null;
        }

        $results = array();
        foreach ($enabled as $item) {
            $slug = (string) $item['slug'];
            $type = isset($item['type']) ? (string) $item['type'] : '';
            $data = self::getFeed($apiUrl, $apiKey, $slug, $item['identifier'], $widgetId, (int) $limit, $type);
            if (is_array($data) && self::feedHasContent($slug, $data)) {
                $results[$slug] = $data;
            }
        }

        if (count($results) < $minPlatforms) {
            return null;
        }

        return $results;
    }

    /** @return array|null Unified tab feed — requires at least two enabled platforms. */
    public static function getUnifiedFeed($apiUrl, $apiKey, $params, $widgetId, $limit = 12)
    {
        return self::aggregatePlatformFeeds($apiUrl, $apiKey, $params, $widgetId, $limit, 2);
    }

    /** @return array|null Social wall feeds — one or more enabled platforms (API). */
    public static function getWallFeedsByPlatform($apiUrl, $apiKey, $params, $widgetId, $limit = 12)
    {
        return self::aggregatePlatformFeeds($apiUrl, $apiKey, $params, $widgetId, $limit, 1);
    }

    /** @return array|null Social wall feeds from module cache only (after tabs loaded). */
    public static function getWallFeedsFromModuleCache($params, $limit = 12)
    {
        return self::aggregatePlatformFeedsFromCache($params, $limit, 1);
    }

    public static function buildUnifiedFeedEntry($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12, $lazy = false)
    {
        $label = trim((string) $params->get('unified_feed_label', ''));
        if ($label === '') {
            $label = 'Social';
        }

        if ($lazy) {
            return array(
                'key'         => 'unified',
                'label'       => $label,
                'class'       => 'unified_icon',
                'icon'        => 'fas fa-layer-group',
                'accent'      => '#7C3AED',
                'profile_url' => '',
                'lazy'        => true,
                'html'        => self::renderFeedPlaceholder('unified', $theme),
            );
        }

        $data = self::getUnifiedFeed($apiUrl, $apiKey, $params, $widgetId, $postsLimit);
        if (!is_array($data) || empty($data)) {
            return null;
        }

        return array(
            'key'         => 'unified',
            'label'       => $label,
            'class'       => 'unified_icon',
            'icon'        => 'fas fa-layer-group',
            'accent'      => '#7C3AED',
            'profile_url' => '',
            'html'        => self::renderUnifiedFeed($data, $apiUrl, $theme),
        );
    }

    /** Render the unified feed tab HTML (lazy AJAX + direct render). */
    public static function renderUnifiedFeedHtml($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit = 12)
    {
        $data = self::getUnifiedFeed($apiUrl, $apiKey, $params, $widgetId, $postsLimit);

        return is_array($data) && !empty($data)
            ? self::renderUnifiedFeed($data, $apiUrl, $theme)
            : self::renderFeedPlaceholder('unified', $theme);
    }

    public static function buildContactEntry($params, $theme, $moduleId)
    {
        $recipient = trim((string) $params->get('contact_recipient', ''));
        if ($recipient === '' || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            return null;
        }

        $label = trim((string) $params->get('contact_tab_label', ''));
        if ($label === '') {
            $label = 'Contact';
        }

        return array(
            'key'         => 'contact',
            'label'       => $label,
            'class'       => 'contact_icon',
            'icon'        => 'fas fa-envelope',
            'accent'      => '#6366F1',
            'profile_url' => 'mailto:' . $recipient,
            'html'        => self::renderContactForm($params, $theme, (int) $moduleId),
        );
    }

    /**
     * com_ajax handler: send contact-tab leads via Joomla Mail (site SMTP plugin).
     * URL: index.php?option=com_ajax&module=js_like_box_pro&method=submitContact&format=json&module_id={moduleId}
     *
     * @return array{success:bool,error?:string}
     */
    public static function submitContactAjax()
    {
        $app = Factory::getApplication();

        if (!self::checkPostToken()) {
            return self::contactAjaxResult(false, 'Invalid session. Please reload the page and try again.');
        }

        $moduleId = $app->input->post->getInt('module_id', 0);
        if ($moduleId <= 0) {
            $moduleId = $app->input->getInt('module_id', 0);
        }
        if ($moduleId <= 0) {
            return self::contactAjaxResult(false, 'Contact form is not configured (missing module id).');
        }

        $module = self::loadModuleById($moduleId);
        if ($module === null) {
            return self::contactAjaxResult(false, 'Contact form is not configured (module not found).');
        }

        $params = new Registry($module->params);
        if ((int) $params->get('contact_enabled', 0) !== 1) {
            return self::contactAjaxResult(false, 'Contact tab is disabled.');
        }

        $recipient = trim((string) $params->get('contact_recipient', ''));
        if ($recipient === '' || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
            return self::contactAjaxResult(false, 'Recipient email is not configured.');
        }

        // Honeypots — obscure names so browsers/password managers do not autofill them.
        if (trim($app->input->post->getString('contact_hp_a', '')) !== ''
            || trim($app->input->post->getString('contact_hp_b', '')) !== '') {
            return self::contactAjaxResult(true);
        }

        if (!self::contactVerifyTimestamp(
            $moduleId,
            $app->input->post->getInt('contact_ts', 0),
            $app->input->post->getString('contact_sig', '')
        )) {
            return self::contactAjaxResult(false, 'Please wait a moment and try again.');
        }

        if (!self::contactRateLimitOk()) {
            return self::contactAjaxResult(false, 'Too many messages sent. Please try again later.');
        }

        $name    = trim($app->input->post->getString('name', ''));
        $email   = trim($app->input->post->getString('email', ''));
        $message = trim($app->input->post->getString('message', ''));
        $phone   = trim($app->input->post->getString('phone', ''));
        $showPhone = (int) $params->get('contact_show_phone', 0) === 1;

        if ($name === '' || $email === '' || $message === '') {
            return self::contactAjaxResult(false, 'Please fill in all required fields.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return self::contactAjaxResult(false, 'Invalid email address.');
        }
        if (strlen($name) > 120 || strlen($email) > 200 || strlen($message) > 5000 || strlen($phone) > 40) {
            return self::contactAjaxResult(false, 'One of the fields is too long.');
        }
        if (self::contactCountLinks($message) > 3) {
            return self::contactAjaxResult(false, 'Your message contains too many links.');
        }

        $subject = 'Js Like Box Slider contact: ' . $name;
        $body    = "New message from Js Like Box Slider\n\n"
            . "Name: {$name}\n"
            . "Email: {$email}\n"
            . (($showPhone && $phone !== '') ? "Phone: {$phone}\n" : '')
            . "Site: " . (string) Factory::getApplication()->get('sitename') . "\n"
            . "Page: " . Uri::getInstance()->toString(array('scheme', 'host', 'path')) . "\n\n"
            . "Message:\n{$message}\n";

        $mailError = self::sendContactMail($recipient, $email, $name, $subject, $body);
        if ($mailError !== '') {
            return self::contactAjaxResult(false, $mailError);
        }

        return self::contactAjaxResult(true);
    }

    /**
     * com_ajax handler: lazy-load an API-backed feed tab on widget hover or tab click.
     * URL: index.php?option=com_ajax&module=js_like_box_pro&method=loadFeed&format=json&module_id={id}&tab={key}
     *
     * @return array{success:bool,html?:string,error?:string}
     */
    public static function loadFeedAjax()
    {
        try {
            $app = Factory::getApplication();
            $input = $app->input;

            $moduleId = $input->getInt('module_id', 0);
            if ($moduleId <= 0) {
                return self::feedAjaxResult(false, 'Missing module id.');
            }

            if (!self::feedAjaxRateLimitOk($moduleId)) {
                return self::feedAjaxResult(false, 'Too many requests. Please try again shortly.');
            }

            $context = strtolower(trim($input->getString('context', '')));
            $context = preg_replace('/[^a-z_]/', '', $context);

            $module = self::loadModuleById($moduleId);
            if ($module === null) {
                return self::feedAjaxResult(false, 'Widget not found.');
            }

            $params = new Registry($module->params);
            $ctx    = self::resolveModuleFeedContext($module, $params);
            if ($ctx['api_key'] === '') {
                return self::feedAjaxResult(false, 'Widget is not configured.');
            }

            $showFeedPosts = (int) $params->get('show_feed_posts', 1) === 1;
            $fetchLimit    = $showFeedPosts ? $ctx['posts_limit'] : 1;

            if ($context === 'wall') {
                $plan = isset($ctx['plan']) ? (string) $ctx['plan'] : '';
                if (!self::isProOrPremiumPlan($plan)) {
                    return self::feedAjaxResult(false, 'Social Wall requires Pro or Premium.');
                }
                $html = self::renderWallFeedHtml($module, $params, $ctx);
                if ($html === '') {
                    return self::feedAjaxResult(false, 'cache_miss', array('cache_miss' => true));
                }

                return self::feedAjaxResult(true, $html);
            }

            if ($context === 'social_bar') {
                $feed = self::resolveSocialBarFeed($params, $ctx);
                if ($feed === null) {
                    return self::feedAjaxResult(false, 'Feed is unavailable right now.');
                }
                $html = self::renderSocialBarPost($feed['slug'], $feed['data'], $ctx['theme'], $ctx['api_url']);
                if ($html === '') {
                    return self::feedAjaxResult(false, 'Feed is unavailable right now.');
                }

                return self::feedAjaxResult(true, $html);
            }

            $tab = strtolower(trim($input->getString('tab', '')));
            $tab = preg_replace('/[^a-z0-9_]/', '', $tab);
            if ($tab === '') {
                return self::feedAjaxResult(false, 'Missing tab.');
            }

            if ($ctx['over_limit'] && !in_array($tab, self::PLATFORM_ORDER, true) && !in_array($tab, array('testimonials', 'unified'), true)) {
                return self::feedAjaxResult(false, 'This tab is unavailable on your current plan usage.');
            }

            if ($tab === 'unified') {
                if ((int) $params->get('unified_feed_enabled', 0) !== 1) {
                    return self::feedAjaxResult(false, 'Tab is not enabled.');
                }
                $html = self::renderUnifiedFeedHtml(
                    $params,
                    $ctx['api_url'],
                    $ctx['api_key'],
                    $ctx['widget_id'],
                    $ctx['theme'],
                    $fetchLimit
                );
            } elseif ($tab === 'testimonials') {
                if ((int) $params->get('testimonials_enabled', 0) !== 1) {
                    return self::feedAjaxResult(false, 'Tab is not enabled.');
                }
                @set_time_limit(180);
                $entry = self::buildTestimonialsEntry(
                    $params,
                    $ctx['theme'],
                    $ctx['api_url'],
                    $ctx['api_key'],
                    $ctx['widget_id'],
                    $ctx['posts_limit'],
                    false
                );
                $html = is_array($entry) ? (string) ($entry['html'] ?? '') : '';
            } elseif (in_array($tab, self::PLATFORM_ORDER, true)) {
                if (self::resolvePlatformIdentifier($tab, $params) === null) {
                    return self::feedAjaxResult(false, 'Tab is not enabled.');
                }
                $html = self::renderPlatformFeedHtml(
                    $tab,
                    $params,
                    $ctx['api_url'],
                    $ctx['api_key'],
                    $ctx['widget_id'],
                    $ctx['theme'],
                    $fetchLimit,
                    $showFeedPosts,
                    $input->getInt('sync', 0) === 1
                );
            } else {
                return self::feedAjaxResult(false, 'Unknown tab.');
            }

            if ($html === '') {
                return self::feedAjaxResult(false, 'Feed is unavailable right now.');
            }

            return self::feedAjaxResult(true, $html);
        } catch (\Throwable $e) {
            Log::add('JS Like Box loadFeedAjax: ' . $e->getMessage(), Log::ERROR, 'mod_js_like_box_pro');

            return self::feedAjaxResult(false, 'Could not load feed.');
        }
    }

    /** @return array{success:bool,html?:string,error?:string,cache_miss?:bool} */
    private static function feedAjaxResult($success, $payload = '', array $extra = array())
    {
        if ($success) {
            return array_merge(
                array(
                    'success' => true,
                    'html'    => (string) $payload,
                ),
                $extra
            );
        }

        return array_merge(
            array(
                'success' => false,
                'error'   => (string) $payload,
            ),
            $extra
        );
    }

    /**
     * Shared context for server-side feed rendering (lazy AJAX).
     *
     * @return array{api_url:string,api_key:string,widget_id:string,theme:string,posts_limit:int,over_limit:bool}
     */
    private static function resolveModuleFeedContext($module, Registry $params)
    {
        $apiUrl   = self::API_BASE_URL;
        $apiKey   = trim((string) $params->get('api_key'));
        $domain   = self::getSiteDomain();
        $widgetId = substr(hash('sha256', $domain . '|' . (int) $module->id), 0, 24);
        $theme    = self::normalizeTheme($params->get('theme', 'rounded_dark'));
        $postsLimit = 12;
        $overLimit  = false;
        $plan       = '';

        if ($apiKey !== '' && $apiUrl !== '') {
            $status = self::fetchStatus($apiUrl, $apiKey, $widgetId);
            if (!empty($status['ok']) && is_array($status['meta'])) {
                $plan = isset($status['plan']) ? (string) $status['plan'] : '';
                if ($plan === '' && !empty($status['meta']['plan'])) {
                    $plan = (string) $status['meta']['plan'];
                }
                $postsLimit = isset($status['meta']['posts_limit'])
                    ? (int) $status['meta']['posts_limit']
                    : self::postsLimitForPlan($plan);
                if ($postsLimit <= 0) {
                    $postsLimit = self::postsLimitForPlan($plan);
                }
                $overLimit = !empty($status['meta']['over_limit']);
            }
        }

        return array(
            'api_url'     => $apiUrl,
            'api_key'     => $apiKey,
            'widget_id'   => $widgetId,
            'theme'       => $theme,
            'posts_limit' => $postsLimit,
            'over_limit'  => $overLimit,
            'plan'        => $plan,
        );
    }

    /** URL for lazy feed loading. */
    public static function buildFeedAjaxUrl($moduleId)
    {
        $itemId = Factory::getApplication()->input->getInt('Itemid', 0);
        $query  = array(
            'option'         => 'com_ajax',
            'module'         => 'js_like_box_pro',
            'method'         => 'loadFeed',
            'format'         => 'json',
            'module_id'      => (int) $moduleId,
            'ignoreMessages' => 1,
        );
        if ($itemId > 0) {
            $query['Itemid'] = $itemId;
        }

        return Uri::base() . 'index.php?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    private static function feedAjaxRateLimitOk($moduleId)
    {
        $ip = (string) ($_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $file = (JPATH_CACHE . '/mod_js_like_box_pro') . '/feed_rl_' . md5($ip . '|' . (int) $moduleId) . '.txt';
        $now  = time();
        $window = 60;
        $max    = 40;
        $hits   = array();

        if (is_file($file)) {
            $raw = @file_get_contents($file);
            if ($raw !== false && $raw !== '') {
                foreach (explode("\n", $raw) as $line) {
                    $ts = (int) $line;
                    if ($ts > ($now - $window)) {
                        $hits[] = $ts;
                    }
                }
            }
        }

        if (count($hits) >= $max) {
            return false;
        }

        $hits[] = $now;
        $dir = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        @file_put_contents($file, implode("\n", $hits));

        return true;
    }

    /** @return string Empty on success, user-facing error otherwise. */
    private static function sendContactMail($recipient, $replyEmail, $replyName, $subject, $body)
    {
        $app      = Factory::getApplication();
        $mailfrom = trim((string) $app->get('mailfrom'));
        $fromname = trim((string) $app->get('fromname'));

        if ($mailfrom === '' || !filter_var($mailfrom, FILTER_VALIDATE_EMAIL)) {
            return 'Site mail is not configured. Set a valid From Email in System → Global Configuration → Mail.';
        }

        try {
            $mailer = Factory::getMailer();

            if (method_exists($mailer, 'clearAllRecipients')) {
                $mailer->clearAllRecipients();
            }
            if (method_exists($mailer, 'clearReplyTos')) {
                $mailer->clearReplyTos();
            }
            if (method_exists($mailer, 'clearAttachments')) {
                $mailer->clearAttachments();
            }
            if (method_exists($mailer, 'clearCustomHeaders')) {
                $mailer->clearCustomHeaders();
            }

            $mailer->setSender(array($mailfrom, $fromname !== '' ? $fromname : $mailfrom));
            $mailer->addRecipient($recipient);
            $mailer->addReplyTo($replyEmail, $replyName);
            $mailer->setSubject($subject);
            $mailer->setBody($body);

            if (method_exists($mailer, 'isHtml')) {
                $mailer->isHtml(false);
            } elseif (method_exists($mailer, 'IsHTML')) {
                $mailer->IsHTML(false);
            }

            $sent = method_exists($mailer, 'send') ? $mailer->send() : $mailer->Send();

            if ($sent === true) {
                return '';
            }

            $detail = '';
            if ($sent instanceof \Throwable) {
                $detail = $sent->getMessage();
            } elseif (is_string($sent) && $sent !== '') {
                $detail = $sent;
            } elseif (!empty($mailer->ErrorInfo)) {
                $detail = (string) $mailer->ErrorInfo;
            }

            if ($detail !== '') {
                Log::add('JS Like Box contact mail failed to ' . $recipient . ': ' . $detail, Log::ERROR, 'mod_js_like_box_pro');
            }

            return 'Could not send message. Configure SMTP in System → Global Configuration → Mail (PHP mail often fails on hosting).';
        } catch (\Throwable $e) {
            Log::add('JS Like Box contact mail exception: ' . $e->getMessage(), Log::ERROR, 'mod_js_like_box_pro');

            return 'Could not send message. Configure SMTP in System → Global Configuration → Mail (PHP mail often fails on hosting).';
        }
    }

    /** URL for the contact form POST. */
    public static function buildContactAjaxUrl($moduleId)
    {
        $itemId = Factory::getApplication()->input->getInt('Itemid', 0);
        $query  = array(
            'option'    => 'com_ajax',
            'module'    => 'js_like_box_pro',
            'method'    => 'submitContact',
            'format'    => 'json',
            'module_id' => (int) $moduleId,
        );
        if ($itemId > 0) {
            $query['Itemid'] = $itemId;
        }

        return Uri::base() . 'index.php?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    /** @return object|null */
    private static function loadModuleById($moduleId)
    {
        $moduleId = (int) $moduleId;
        if ($moduleId <= 0) {
            return null;
        }

        if (!self::isJoomla4()) {
            jimport('joomla.application.module.helper');
        }

        $module = ModuleHelper::getModuleById($moduleId);
        if ($module && (int) $module->id === $moduleId && $module->module === 'mod_js_like_box_pro') {
            return $module;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__modules'))
            ->where($db->quoteName('id') . ' = ' . $moduleId)
            ->where($db->quoteName('module') . ' = ' . $db->quote('mod_js_like_box_pro'));
        $db->setQuery($query);

        try {
            $row = $db->loadObject();
        } catch (\Exception $e) {
            return null;
        }

        return ($row && (int) $row->id === $moduleId) ? $row : null;
    }

    /** @deprecated Use loadModuleById() */
    private static function loadContactModule($moduleId)
    {
        return self::loadModuleById($moduleId);
    }

    /** @return array{ts:int,sig:string} */
    private static function contactSignTimestamp($moduleId)
    {
        $ts  = time();
        $sig = hash_hmac('sha256', (int) $moduleId . '|' . $ts, self::contactSpamSecret());

        return array('ts' => $ts, 'sig' => $sig);
    }

    private static function contactVerifyTimestamp($moduleId, $ts, $sig)
    {
        if ($ts <= 0 || $sig === '') {
            return false;
        }

        $expected = hash_hmac('sha256', (int) $moduleId . '|' . $ts, self::contactSpamSecret());
        if (!hash_equals($expected, $sig)) {
            return false;
        }

        $age = time() - $ts;

        return $age >= 3 && $age <= 7200;
    }

    private static function contactSpamSecret()
    {
        return (string) Factory::getApplication()->get('secret') . '|mod_js_like_box_pro|contact';
    }

    private static function contactRateLimitOk($max = 5, $windowSec = 3600)
    {
        $ip = (string) Factory::getApplication()->input->server->getString('REMOTE_ADDR', 'unknown');
        $dir = (JPATH_CACHE . '/mod_js_like_box_pro');

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $file = $dir . '/contact_rate_' . md5($ip) . '.json';
        $now  = time();
        $data = array('count' => 0, 'start' => $now);

        if (is_file($file)) {
            $decoded = json_decode((string) file_get_contents($file), true);
            if (is_array($decoded)) {
                $data = $decoded;
            }
            if ($now - (int) $data['start'] > $windowSec) {
                $data = array('count' => 0, 'start' => $now);
            }
        }

        if ((int) $data['count'] >= $max) {
            return false;
        }

        $data['count'] = (int) $data['count'] + 1;
        @file_put_contents($file, json_encode($data));

        return true;
    }

    private static function contactCountLinks($text)
    {
        if (preg_match_all('/https?:\/\/|www\./i', $text, $matches)) {
            return count($matches[0]);
        }

        return 0;
    }

    /** @return array{success:bool,error?:string} */
    private static function contactAjaxResult($success, $error = '')
    {
        $result = array('success' => (bool) $success);
        if ($error !== '') {
            $result['error'] = $error;
        }

        return $result;
    }

    private static function sanitizeMapEmbedUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }

        if (!preg_match('#^https://(www\.)?google\.[a-z.]{2,}/maps/#i', $url)) {
            return '';
        }

        return $url;
    }

    private static function buildMapsSearchUrl($address)
    {
        $address = trim((string) $address);
        if ($address === '') {
            return '';
        }

        return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($address);
    }

    private static function renderContactDetails($params)
    {
        if ((int) $params->get('contact_show_details', 0) !== 1) {
            return '';
        }

        $phone   = trim((string) $params->get('contact_display_phone', ''));
        $email   = trim((string) $params->get('contact_display_email', ''));
        $address = trim((string) $params->get('contact_address', ''));
        $mapsUrl = trim((string) $params->get('contact_maps_url', ''));

        if ($mapsUrl === '' && $address !== '') {
            $mapsUrl = self::buildMapsSearchUrl($address);
        }

        if ($phone === '' && $email === '' && $address === '') {
            return '';
        }

        ob_start();
        ?>
        <div class="jssocial_contact_details">
            <?php if ($address !== '') : ?>
                <div class="jssocial_contact_detail">
                    <i class="fas fa-location-dot" aria-hidden="true"></i>
                    <div class="jssocial_contact_detail_body">
                        <span class="jssocial_contact_detail_label">Address</span>
                        <?php if ($mapsUrl !== '') : ?>
                            <a class="jssocial_contact_detail_value" href="<?php echo htmlspecialchars($mapsUrl); ?>" target="_blank" rel="noopener">
                                <?php echo nl2br(htmlspecialchars($address)); ?>
                            </a>
                        <?php else : ?>
                            <span class="jssocial_contact_detail_value"><?php echo nl2br(htmlspecialchars($address)); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($phone !== '') : ?>
                <div class="jssocial_contact_detail">
                    <i class="fas fa-phone" aria-hidden="true"></i>
                    <div class="jssocial_contact_detail_body">
                        <span class="jssocial_contact_detail_label">Phone</span>
                        <a class="jssocial_contact_detail_value" href="tel:<?php echo htmlspecialchars(preg_replace('/\s+/', '', $phone)); ?>">
                            <?php echo htmlspecialchars($phone); ?>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) : ?>
                <div class="jssocial_contact_detail">
                    <i class="fas fa-envelope" aria-hidden="true"></i>
                    <div class="jssocial_contact_detail_body">
                        <span class="jssocial_contact_detail_label">Email</span>
                        <a class="jssocial_contact_detail_value" href="mailto:<?php echo htmlspecialchars($email); ?>">
                            <?php echo htmlspecialchars($email); ?>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function renderContactMap($params)
    {
        if ((int) $params->get('contact_show_map', 0) !== 1) {
            return '';
        }

        $embed = self::sanitizeMapEmbedUrl((string) $params->get('contact_map_embed', ''));
        if ($embed === '') {
            return '';
        }

        ob_start();
        ?>
        <div class="jssocial_contact_map">
            <iframe
                src="<?php echo htmlspecialchars($embed); ?>"
                title="Location map"
                loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"
                allowfullscreen></iframe>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function buildWhatsAppEntry($params, $theme)
    {
        $phone = self::normalizeWhatsAppPhone((string) $params->get('whatsapp_phone', ''));
        if (strlen($phone) < 8) {
            return null;
        }

        $message = trim((string) $params->get('whatsapp_message', ''));
        $url     = self::buildWhatsAppUrl($phone, $message);
        $telUrl  = 'tel:+' . $phone;

        $label = trim((string) $params->get('whatsapp_tab_label', ''));
        if ($label === '') {
            $label = 'WhatsApp';
        }

        return array(
            'key'         => 'whatsapp',
            'label'       => $label,
            'class'       => 'whatsapp_icon',
            'icon'        => 'fab fa-whatsapp',
            'accent'      => '#25D366',
            'profile_url' => $url,
            'html'        => self::renderWhatsAppTab($params, $theme, $url, $telUrl, $phone),
        );
    }

    private static function formatWhatsAppPhoneDisplay($digits)
    {
        $digits = self::normalizeWhatsAppPhone($digits);
        if ($digits === '') {
            return '';
        }

        return '+' . $digits;
    }

    /** @return array<int, string> */
    private static function parseWhatsAppBullets($params)
    {
        $raw = trim((string) $params->get('whatsapp_bullets', ''));
        if ($raw === '') {
            return array();
        }

        $lines = preg_split('/\r\n|\r|\n/', $raw);
        $out   = array();

        foreach ((array) $lines as $line) {
            $line = trim((string) $line);
            if ($line !== '') {
                $out[] = $line;
            }
        }

        return $out;
    }

    public static function renderWhatsAppTab($params, $theme, $url, $telUrl = '', $phoneDigits = '')
    {
        $theme       = self::normalizeTheme($theme);
        $intro       = trim((string) $params->get('whatsapp_intro', ''));
        $displayName = trim((string) $params->get('whatsapp_display_name', ''));
        $hours       = trim((string) $params->get('whatsapp_hours', ''));
        $replyNote   = trim((string) $params->get('whatsapp_reply_note', ''));
        $cta         = trim((string) $params->get('whatsapp_cta', ''));
        $callCta     = trim((string) $params->get('whatsapp_call_cta', ''));
        if ($cta === '') {
            $cta = 'Chat on WhatsApp';
        }
        if ($callCta === '') {
            $callCta = 'Call instead';
        }
        $showCall    = (int) $params->get('whatsapp_show_call', 1) === 1;
        $phoneDisp   = self::formatWhatsAppPhoneDisplay($phoneDigits);
        $bullets     = self::parseWhatsAppBullets($params);

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--whatsapp" style="--jssocial-accent: #25D366;">
            <div class="jssocial_whatsapp">
                <div class="jssocial_whatsapp_hero">
                    <div class="jssocial_whatsapp_icon"><i class="fab fa-whatsapp" aria-hidden="true"></i></div>
                    <div class="jssocial_whatsapp_hero_text">
                        <?php if ($displayName !== '') : ?>
                            <div class="jssocial_whatsapp_name"><?php echo htmlspecialchars($displayName); ?></div>
                        <?php endif; ?>
                        <?php if ($phoneDisp !== '') : ?>
                            <div class="jssocial_whatsapp_phone"><?php echo htmlspecialchars($phoneDisp); ?></div>
                        <?php endif; ?>
                        <?php if ($hours !== '') : ?>
                            <div class="jssocial_whatsapp_hours"><i class="fas fa-clock" aria-hidden="true"></i> <?php echo htmlspecialchars($hours); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($replyNote !== '') : ?>
                    <div class="jssocial_whatsapp_note">
                        <i class="fas fa-bolt" aria-hidden="true"></i>
                        <?php echo htmlspecialchars($replyNote); ?>
                    </div>
                <?php endif; ?>

                <?php if ($intro !== '') : ?>
                    <p class="jssocial_whatsapp_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>

                <?php if (!empty($bullets)) : ?>
                    <ul class="jssocial_whatsapp_bullets">
                        <?php foreach ($bullets as $bullet) : ?>
                            <li><?php echo htmlspecialchars($bullet); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <div class="jssocial_whatsapp_actions">
                    <a class="jssocial_whatsapp_btn jssocial_whatsapp_btn--primary" href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener noreferrer">
                        <i class="fab fa-whatsapp" aria-hidden="true"></i>
                        <span><?php echo htmlspecialchars($cta); ?></span>
                    </a>
                    <?php if ($showCall && $telUrl !== '') : ?>
                        <a class="jssocial_whatsapp_btn jssocial_whatsapp_btn--secondary" href="<?php echo htmlspecialchars($telUrl); ?>">
                            <i class="fas fa-phone" aria-hidden="true"></i>
                            <span><?php echo htmlspecialchars($callCta); ?></span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function sanitizeCalendlyEmbedUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return '';
        }

        $host = strtolower((string) parse_url($url, PHP_URL_SCHEME));
        if ($host !== 'https') {
            return '';
        }

        $hostname = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (!preg_match('/(^|\.)calendly\.com$/', $hostname)) {
            return '';
        }

        return $url;
    }

    private static function calendlyPublicUrl($embedUrl)
    {
        $embedUrl = trim((string) $embedUrl);
        if ($embedUrl === '') {
            return '';
        }

        $parts = parse_url($embedUrl);
        if (empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }

        $path = isset($parts['path']) ? $parts['path'] : '';

        return $parts['scheme'] . '://' . $parts['host'] . $path;
    }

    public static function buildCalendlyEntry($params, $theme)
    {
        $embedUrl = self::sanitizeCalendlyEmbedUrl((string) $params->get('calendly_embed_url', ''));
        if ($embedUrl === '') {
            return null;
        }

        $link = trim((string) $params->get('calendly_link', ''));
        if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
            $link = '';
        }
        if ($link === '') {
            $link = self::calendlyPublicUrl($embedUrl);
        }

        $label = trim((string) $params->get('calendly_tab_label', ''));
        if ($label === '') {
            $label = 'Book a call';
        }

        return array(
            'key'         => 'calendly',
            'label'       => $label,
            'class'       => 'calendly_icon',
            'icon'        => 'fas fa-calendar-check',
            'accent'      => '#0EA5E9',
            'profile_url' => '',
            'html'        => self::renderCalendlyTab($params, $theme, $embedUrl, $link),
        );
    }

    public static function renderCalendlyTab($params, $theme, $embedUrl, $publicUrl = '')
    {
        $theme   = self::normalizeTheme($theme);
        $intro   = trim((string) $params->get('calendly_intro', ''));
        $cta     = trim((string) $params->get('calendly_cta', ''));
        if ($cta === '') {
            $cta = 'Open in Calendly';
        }
        $height  = (int) $params->get('calendly_height', 480);
        if ($height < 320) {
            $height = 320;
        }
        if ($height > 900) {
            $height = 900;
        }
        $publicUrl = trim((string) $publicUrl);

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--calendly" style="--jssocial-accent: #0EA5E9;">
            <div class="jssocial_calendly">
                <?php if ($intro !== '') : ?>
                    <p class="jssocial_calendly_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>
                <div class="jssocial_calendly_embed">
                    <iframe
                        src="<?php echo htmlspecialchars($embedUrl); ?>"
                        title="Book a meeting"
                        loading="lazy"
                        style="min-height:<?php echo $height; ?>px;"></iframe>
                </div>
                <?php if ($publicUrl !== '') : ?>
                    <a class="jssocial_calendly_fallback" href="<?php echo htmlspecialchars($publicUrl); ?>" target="_blank" rel="noopener noreferrer">
                        <i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i>
                        <?php echo htmlspecialchars($cta); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /** @return array<int, array{question:string,answer:string}> */
    public static function parseFaqItems($params)
    {
        $raw   = $params->get('faq_items');
        $items = array();

        foreach ((array) $raw as $row) {
            $row      = (object) $row;
            $question = trim((string) ($row->question ?? ''));
            $answer   = trim((string) ($row->answer ?? ''));
            if ($question === '' || $answer === '') {
                continue;
            }

            $items[] = array(
                'question' => $question,
                'answer'   => $answer,
            );
        }

        return $items;
    }

    public static function buildFaqEntry($params, $theme)
    {
        $items = self::parseFaqItems($params);
        if (empty($items)) {
            return null;
        }

        $label = trim((string) $params->get('faq_tab_label', ''));
        if ($label === '') {
            $label = 'FAQ';
        }

        return array(
            'key'         => 'faq',
            'label'       => $label,
            'class'       => 'faq_icon',
            'icon'        => 'fas fa-circle-question',
            'accent'      => '#6366F1',
            'profile_url' => '',
            'html'        => self::renderFaqTab($items, $theme, $params),
        );
    }

    public static function renderFaqTab(array $items, $theme, $params)
    {
        $theme = self::normalizeTheme($theme);
        $intro = trim((string) $params->get('faq_intro', ''));
        if ($intro === '') {
            $intro = 'Quick answers before you reach out.';
        }

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--faq" style="--jssocial-accent: #6366F1;">
            <div class="jssocial_faq">
                <p class="jssocial_faq_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <div class="jssocial_faq_list">
                    <?php foreach ($items as $i => $item) : ?>
                        <details class="jssocial_faq_item"<?php echo $i === 0 ? ' open' : ''; ?>>
                            <summary class="jssocial_faq_question"><?php echo htmlspecialchars($item['question']); ?></summary>
                            <div class="jssocial_faq_answer"><?php echo nl2br(htmlspecialchars($item['answer'])); ?></div>
                        </details>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function buildTestimonialsEntry($params, $theme, $apiUrl = '', $apiKey = '', $widgetId = '', $postsLimit = 12, $lazy = false)
    {
        $items = self::parseTestimonials($params);
        $embed = self::sanitizeReviewsEmbedUrl((string) $params->get('testimonials_embed_url', ''));
        $live  = self::reviewLiveSources($params);
        if (empty($items) && $embed === '' && $live === []) {
            return null;
        }

        $label = trim((string) $params->get('testimonials_tab_label', ''));
        if ($label === '') {
            $label = 'Reviews';
        }

        $entry = array(
            'key'         => 'testimonials',
            'label'       => $label,
            'class'       => 'testimonials_icon',
            'icon'        => 'fas fa-quote-left',
            'accent'      => '#F59E0B',
            'profile_url' => '',
            'html'        => '',
        );

        if ($lazy && $live !== []) {
            $entry['html'] = self::renderFeedPlaceholder('testimonials', $theme);
            $entry['lazy'] = true;

            return $entry;
        }

        $items = self::mergeLiveReviews($items, $live, $apiUrl, $apiKey, $widgetId, $postsLimit);
        $entry['html'] = self::renderTestimonials($items, $theme, $params);

        return $entry;
    }

    /** @return array<int, array{slug:string,identifier:string,source:string}> */
    private static function reviewLiveSources($params)
    {
        $sources = array();
        $google = self::normalizeGooglePlace((string) $params->get('google_reviews_place', ''));
        if ($google !== '') {
            $sources[] = array('slug' => 'google_reviews', 'identifier' => $google, 'source' => 'google');
        }

        return $sources;
    }

    public static function normalizeGooglePlace($identifier)
    {
        $identifier = trim((string) $identifier);
        if ($identifier === '') {
            return '';
        }

        // FILTER_VALIDATE_URL rejects long/unicode Maps links and share.google shorts.
        if (preg_match('#(google\.[^/\s]+/maps|maps\.google\.|maps\.app\.goo\.gl|share\.google/|goo\.gl/maps)#i', $identifier)) {
            return $identifier;
        }

        if (preg_match('#^https?://#i', $identifier)) {
            $host = strtolower((string) parse_url($identifier, PHP_URL_HOST));
            if ($host !== '' && (
                preg_match('/(^|\.)google\.[a-z.]+$/', $host)
                || $host === 'maps.app.goo.gl'
                || $host === 'share.google'
                || preg_match('/(^|\.)goo\.gl$/', $host)
            )) {
                return $identifier;
            }

            return '';
        }

        return preg_match('/^0x[0-9a-f]+:0x[0-9a-f]+$/i', $identifier)
            || preg_match('/^[A-Za-z0-9_-]{16,}$/', $identifier) ? $identifier : '';
    }

    /**
     * @param array<int, array<string, mixed>> $manual
     * @param array<int, array{slug:string,identifier:string,source:string}> $live
     * @return array<int, array<string, mixed>>
     */
    private static function mergeLiveReviews(array $manual, array $live, $apiUrl, $apiKey, $widgetId, $postsLimit)
    {
        if ($live === [] || $apiKey === '') {
            return $manual;
        }

        $order = count($manual);
        $blockedOnce = false;
        foreach ($live as $src) {
            $limit = max(1, (int) $postsLimit);
            $data  = self::getFeed($apiUrl, $apiKey, $src['slug'], $src['identifier'], $widgetId, $limit, '', false);
            // ponytail: one blocking Apify run per tab open; the other source warms in the background.
            if (!self::feedHasPosts($data) && !$blockedOnce) {
                $data = self::getFeed($apiUrl, $apiKey, $src['slug'], $src['identifier'], $widgetId, $limit, '', true);
                $blockedOnce = true;
            }
            if (!is_array($data) || empty($data['posts']) || !is_array($data['posts'])) {
                continue;
            }

            foreach ($data['posts'] as $post) {
                if (!is_array($post)) {
                    continue;
                }
                $quote = trim((string) ($post['caption'] ?? ''));
                $rating = (int) ($post['rating'] ?? $post['likes'] ?? 0);
                if ($rating < 0) {
                    $rating = 0;
                }
                if ($rating > 5) {
                    $rating = 5;
                }
                if ($quote === '' && $rating > 0) {
                    $quote = $rating . '/5';
                }
                if ($quote === '') {
                    continue;
                }
                $name = trim((string) ($post['author'] ?? ''));
                if ($name === '') {
                    $name = 'Google review';
                }
                $link = trim((string) ($post['url'] ?? ''));
                if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
                    $link = '';
                }

                $manual[] = array(
                    'name'     => $name,
                    'quote'    => $quote,
                    'rating'   => $rating,
                    'company'  => '',
                    'avatar'   => self::sanitizeTestimonialAvatarUrl((string) ($post['image'] ?? '')),
                    'date'     => self::formatDate((string) ($post['created_at'] ?? '')),
                    'source'   => $src['source'],
                    'link'     => $link,
                    'featured' => false,
                    'order'    => $order++,
                );
            }
        }

        usort($manual, function ($a, $b) {
            $af = !empty($a['featured']) ? 0 : 1;
            $bf = !empty($b['featured']) ? 0 : 1;
            if ($af !== $bf) {
                return $af - $bf;
            }

            return (int) $a['order'] - (int) $b['order'];
        });

        return $manual;
    }

    /** @return array<int, array<string, mixed>> */
    public static function parseTestimonials($params)
    {
        $raw   = $params->get('testimonials');
        $items = array();
        $order = 0;

        foreach ((array) $raw as $row) {
            $row   = (object) $row;
            $quote = trim((string) ($row->quote ?? ''));
            $name  = trim((string) ($row->name ?? ''));
            if ($quote === '' || $name === '') {
                continue;
            }

            $rating = (int) ($row->rating ?? 0);
            if ($rating < 0) {
                $rating = 0;
            }
            if ($rating > 5) {
                $rating = 5;
            }

            $source = strtolower(trim((string) ($row->source ?? 'manual')));
            if (!in_array($source, array('manual', 'google', 'trustmate', 'trustpilot', 'facebook', 'tripadvisor', 'opineo', 'other'), true)) {
                $source = 'manual';
            }

            $link = trim((string) ($row->link ?? ''));
            if ($link !== '' && !filter_var($link, FILTER_VALIDATE_URL)) {
                $link = '';
            }

            $items[] = array(
                'name'     => $name,
                'quote'    => $quote,
                'rating'   => $rating,
                'company'  => trim((string) ($row->company ?? '')),
                'avatar'   => self::sanitizeTestimonialAvatarUrl((string) ($row->avatar ?? '')),
                'date'     => trim((string) ($row->date ?? '')),
                'source'   => $source,
                'link'     => $link,
                'featured' => (int) ($row->featured ?? 0) === 1,
                'order'    => $order++,
            );
        }

        usort($items, function ($a, $b) {
            $af = !empty($a['featured']) ? 0 : 1;
            $bf = !empty($b['featured']) ? 0 : 1;
            if ($af !== $bf) {
                return $af - $bf;
            }

            return (int) $a['order'] - (int) $b['order'];
        });

        return $items;
    }

    private static function sanitizeTestimonialAvatarUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return '';
        }

        $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
        if (!in_array($scheme, array('http', 'https'), true)) {
            return '';
        }

        return $url;
    }

    /** Allowlisted https iframe src for Google / TrustMate / Trustpilot widgets. */
    private static function sanitizeReviewsEmbedUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '' || stripos($url, 'https://') !== 0 || !filter_var($url, FILTER_VALIDATE_URL)) {
            return '';
        }

        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ($host === '') {
            return '';
        }

        if (preg_match('/(^|\.)(google|gstatic)\.[a-z.]+$/', $host)
            || preg_match('/(^|\.)trustmate\.io$/', $host)
            || preg_match('/(^|\.)trustpilot\.(com|pl)$/', $host)
            || preg_match('/(^|\.)tripadvisor\.[a-z.]+$/', $host)
            || preg_match('/(^|\.)opineo\.pl$/', $host)) {
            return $url;
        }

        return '';
    }

    private static function testimonialInitials($name)
    {
        $name = trim((string) $name);
        if ($name === '') {
            return '?';
        }

        $parts = preg_split('/\s+/u', $name, -1, PREG_SPLIT_NO_EMPTY);
        if (!$parts) {
            return '?';
        }

        if (count($parts) === 1) {
            return mb_strtoupper(mb_substr($parts[0], 0, 2));
        }

        return mb_strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[count($parts) - 1], 0, 1));
    }

    /** @return array{count:int,average:float,rated_count:int} */
    private static function testimonialStats(array $items)
    {
        $rated = 0;
        $sum   = 0;

        foreach ($items as $item) {
            $rating = (int) ($item['rating'] ?? 0);
            if ($rating > 0) {
                $rated++;
                $sum += $rating;
            }
        }

        return array(
            'count'       => count($items),
            'rated_count' => $rated,
            'average'     => $rated > 0 ? round($sum / $rated, 1) : 0.0,
        );
    }

    private static function testimonialSourceLabel($source)
    {
        $map = array(
            'manual'       => 'Verified review',
            'google'       => 'Google',
            'trustmate'    => 'TrustMate',
            'trustpilot'   => 'Trustpilot',
            'facebook'     => 'Facebook',
            'tripadvisor'  => 'Tripadvisor',
            'opineo'       => 'Opineo',
            'other'        => 'Review',
        );

        return isset($map[$source]) ? $map[$source] : 'Review';
    }

    private static function testimonialSourceIcon($source)
    {
        $map = array(
            'manual'       => 'fas fa-circle-check',
            'google'       => 'fab fa-google',
            'trustmate'    => 'fas fa-shield-heart',
            'trustpilot'   => 'fas fa-star',
            'facebook'     => 'fab fa-facebook-f',
            'tripadvisor'  => 'fas fa-plane',
            'opineo'       => 'fas fa-comments',
            'other'        => 'fas fa-quote-left',
        );

        return isset($map[$source]) ? $map[$source] : 'fas fa-quote-left';
    }

    private static function renderTestimonialAvatar($name, $avatarUrl)
    {
        $initials = self::testimonialInitials($name);
        ob_start();
        ?>
        <div class="jssocial_testimonial_avatarwrap">
            <span class="jssocial_testimonial_avatar_initials" aria-hidden="true"><?php echo htmlspecialchars($initials); ?></span>
            <?php if ($avatarUrl !== '') : ?>
                <img class="jssocial_testimonial_avatar" src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="" loading="lazy" decoding="async" />
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function normalizeWhatsAppPhone($phone)
    {
        return preg_replace('/\D+/', '', trim((string) $phone));
    }

    public static function buildWhatsAppUrl($phone, $message = '')
    {
        $phone = self::normalizeWhatsAppPhone($phone);
        if ($phone === '') {
            return '';
        }

        $url = 'https://wa.me/' . rawurlencode($phone);
        $message = trim((string) $message);
        if ($message !== '') {
            $url .= '?text=' . rawurlencode($message);
        }

        return $url;
    }

    public static function renderUnifiedFeed(array $feedsByPlatform, $apiUrl, $theme)
    {
        $theme   = self::normalizeTheme($theme);
        $posts   = array();
        $profiles = array();

        foreach ($feedsByPlatform as $platform => $feed) {
            if (!is_array($feed)) {
                continue;
            }
            $platform = (string) $platform;
            if (!empty($feed['profile']) && is_array($feed['profile'])) {
                $profiles[$platform] = $feed['profile'];
            }
            if (empty($feed['posts']) || !is_array($feed['posts'])) {
                continue;
            }
            foreach ($feed['posts'] as $post) {
                if (!is_array($post)) {
                    continue;
                }
                $post['_platform'] = $platform;
                $posts[] = $post;
            }
        }

        $posts = self::sortPostsByDateDesc($posts);

        $ctx = array(
            'apiUrl'     => $apiUrl,
            'avatar'     => '',
            'handle'     => '',
            'profileUrl' => '#',
            'meta'       => array('icon' => 'fa-layer-group', 'accent' => '#7C3AED', 'button' => 'Follow'),
            'platform'   => 'unified',
            'isX'        => false,
            'verified'   => false,
            'profiles'   => $profiles,
        );

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--unified" style="--jssocial-accent: #7C3AED;">
            <div class="jssocial_profile jssocial_profile--compact">
                <div class="jssocial_profile_body">
                    <div class="jssocial_ident">
                        <div class="jssocial_name">Latest updates</div>
                        <div class="jssocial_tagline">Posts from all your connected social accounts</div>
                    </div>
                </div>
            </div>
            <?php if (!empty($posts)) : ?>
                <?php echo self::renderPostList($posts, $ctx); ?>
            <?php else : ?>
                <div class="jssocial_empty"><p>No posts to show right now.</p></div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Masonry wall of posts from all enabled platforms (Pro / Premium). */
    public static function renderSocialWall(array $feedsByPlatform, $apiUrl, $theme, $title = '', $columns = 3, $initialCount = 6, $batchSize = 6)
    {
        $theme        = self::normalizeTheme($theme);
        $columns      = max(2, min(4, (int) $columns));
        $initialCount = max(1, (int) $initialCount);
        $batchSize    = max(1, (int) $batchSize);
        $posts   = array();
        $profiles = array();

        foreach ($feedsByPlatform as $platform => $feed) {
            if (!is_array($feed)) {
                continue;
            }
            $platform = (string) $platform;
            if (!empty($feed['profile']) && is_array($feed['profile'])) {
                $profiles[$platform] = $feed['profile'];
            }
            if (empty($feed['posts']) || !is_array($feed['posts'])) {
                continue;
            }
            foreach ($feed['posts'] as $post) {
                if (!is_array($post)) {
                    continue;
                }
                $post['_platform'] = $platform;
                $posts[] = $post;
            }
        }

        $posts = self::sortPostsByDateDesc($posts);

        $ctx = array(
            'apiUrl'     => $apiUrl,
            'avatar'     => '',
            'handle'     => '',
            'profileUrl' => '#',
            'meta'       => array('icon' => 'fa-layer-group', 'accent' => '#7C3AED', 'button' => 'Follow'),
            'platform'   => 'unified',
            'isX'        => false,
            'verified'   => false,
            'profiles'   => $profiles,
        );

        $total = count($posts);

        ob_start();
        ?>
        <div class="jssocial_wall jssocial_wall--cols-<?php echo (int) $columns; ?>"
             data-jssocial-wall="1"
             data-jssocial-wall-batch="<?php echo (int) $batchSize; ?>">
            <?php if ($title !== '') : ?>
                <h2 class="jssocial_wall_title"><?php echo htmlspecialchars($title); ?></h2>
            <?php endif; ?>
            <div class="jssocial_feed jssocial_feed--<?php echo htmlspecialchars($theme); ?> jssocial_feed--wall">
            <?php if ($total > 0) : ?>
                <?php echo self::renderPostList($posts, $ctx, 'jssocial_posts jssocial_posts--masonry', array('wallInitial' => $initialCount)); ?>
                <?php if ($total > $initialCount) : ?>
                    <div class="jssocial_wall_footer">
                        <button type="button" class="jssocial_wall_loadmore jssocial_action" data-jssocial-wall-loadmore="1">
                            Load more
                        </button>
                    </div>
                <?php endif; ?>
            <?php else : ?>
                <div class="jssocial_empty"><p>No posts to show right now.</p></div>
            <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Lazy wall shell — no API calls until the visitor scrolls near the wall. */
    public static function renderWallLazyShell($moduleId, Registry $params, $theme, $title = '', $columns = 3, $batchSize = 6)
    {
        $theme     = self::normalizeTheme($theme);
        $columns   = max(2, min(4, (int) $columns));
        $batchSize = max(1, (int) $batchSize);
        $moduleId  = (int) $moduleId;
        $ajaxUrl   = self::buildFeedAjaxUrl($moduleId);

        ob_start();
        ?>
        <div class="jssocial_wall jssocial_wall--cols-<?php echo (int) $columns; ?> jssocial_wall--lazy"
             data-jssocial-wall="1"
             data-jssocial-wall-lazy="1"
             data-jssocial-module-id="<?php echo $moduleId; ?>"
             data-jssocial-ajax-url="<?php echo htmlspecialchars($ajaxUrl, ENT_QUOTES); ?>"
             data-jssocial-wall-batch="<?php echo (int) $batchSize; ?>">
            <?php if ($title !== '') : ?>
                <h2 class="jssocial_wall_title"><?php echo htmlspecialchars($title); ?></h2>
            <?php endif; ?>
            <div class="jssocial_feed jssocial_feed--<?php echo htmlspecialchars($theme); ?> jssocial_feed--wall jssocial_feed--pending">
                <div class="jssocial_wall_skeleton" aria-busy="true" aria-live="polite">
                    <span class="jssocial_sr_only">Loading social wall</span>
                    <div class="jssocial_posts jssocial_posts--masonry">
                        <div class="jssocial_sk_card"><div class="jssocial_sk jssocial_sk_media"></div><div class="jssocial_sk jssocial_sk_line"></div><div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div></div>
                        <div class="jssocial_sk_card"><div class="jssocial_sk jssocial_sk_media"></div><div class="jssocial_sk jssocial_sk_line"></div><div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div></div>
                        <div class="jssocial_sk_card"><div class="jssocial_sk jssocial_sk_media"></div><div class="jssocial_sk jssocial_sk_line"></div><div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div></div>
                        <div class="jssocial_sk_card"><div class="jssocial_sk jssocial_sk_media"></div><div class="jssocial_sk jssocial_sk_line"></div><div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div></div>
                        <div class="jssocial_sk_card"><div class="jssocial_sk jssocial_sk_media"></div><div class="jssocial_sk jssocial_sk_line"></div><div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div></div>
                        <div class="jssocial_sk_card"><div class="jssocial_sk jssocial_sk_media"></div><div class="jssocial_sk jssocial_sk_line"></div><div class="jssocial_sk jssocial_sk_line jssocial_sk_line--short"></div></div>
                    </div>
                    <div class="jssocial_feed_skeleton_spinner" aria-hidden="true">
                        <span class="jssocial_feed_skeleton_spinner_ring"></span>
                    </div>
                </div>
            </div>
        </div>
        <?php

        return ob_get_clean();
    }

    /** Fetch and render wall HTML (lazy AJAX). */
    public static function renderWallFeedHtml($module, Registry $params, array $ctx)
    {
        if (self::collectEnabledPlatforms($params) === []) {
            return '';
        }

        $columns      = max(2, min(4, (int) $params->get('wall_columns', 3)));
        $title        = trim((string) $params->get('wall_title', ''));
        $initialCount = max(1, (int) $params->get('wall_initial', 6));
        $batchSize    = max(1, (int) $params->get('wall_batch', 6));
        $data         = self::getWallFeedsFromModuleCache($params, (int) $ctx['posts_limit']);

        if (!is_array($data) || empty($data)) {
            return '';
        }

        return self::renderSocialWall(
            $data,
            (string) $ctx['api_url'],
            (string) $ctx['theme'],
            $title,
            $columns,
            $initialCount,
            $batchSize
        );
    }

    public static function renderWallUpgradeNotice()
    {
        ob_start();
        ?>
        <div class="social_feed_notice social_feed_upgrade">
            Social Wall is available on Pro and Premium plans.
            <a href="<?php echo htmlspecialchars(self::UPGRADE_URL); ?>" target="_blank" rel="noopener">Upgrade your plan</a>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Render wall HTML for a module instance (layout or shortcode). */
    public static function renderWallForModule($module, Registry $params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit, $plan)
    {
        if (!self::isProOrPremiumPlan($plan)) {
            return self::renderWallUpgradeNotice();
        }

        if ($apiKey === '' || $apiUrl === '') {
            return '<div class="social_feed_notice social_feed_error">Js Like Box Slider is not configured.</div>';
        }

        $enabled = self::collectEnabledPlatforms($params);
        if ($enabled === []) {
            return '<div class="jssocial_wall jssocial_wall--empty"><p>Enable at least one social platform in the module settings.</p></div>';
        }

        $columns   = max(2, min(4, (int) $params->get('wall_columns', 3)));
        $title     = trim((string) $params->get('wall_title', ''));
        $batchSize = max(1, (int) $params->get('wall_batch', 6));

        return self::renderWallLazyShell((int) $module->id, $params, $theme, $title, $columns, $batchSize);
    }

    /** Shortcode handler: {jslikebox wall} or {jslikebox wall id=123} */
    public static function renderWallShortcode($moduleId = 0)
    {
        self::enqueueModuleAssets();

        $moduleId = (int) $moduleId;
        if ($moduleId <= 0) {
            $moduleId = self::findFirstPublishedModuleId();
        }
        if ($moduleId <= 0) {
            return '<div class="social_feed_notice social_feed_error">No Js Like Box PRO module found.</div>';
        }

        $module = self::loadModuleById($moduleId);
        if ($module === null) {
            return '<div class="social_feed_notice social_feed_error">Module not found.</div>';
        }

        $params   = new Registry($module->params);
        $apiUrl   = self::API_BASE_URL;
        $apiKey   = trim((string) $params->get('api_key'));
        $domain   = self::getSiteDomain();
        $widgetId = substr(hash('sha256', $domain . '|' . (int) $module->id), 0, 24);
        $theme    = self::normalizeTheme($params->get('theme', 'rounded_dark'));
        $plan     = '';
        $postsLimit = 12;

        if ($apiKey !== '') {
            $status = self::fetchStatus($apiUrl, $apiKey, $widgetId);
            if (!empty($status['ok'])) {
                $plan = isset($status['plan']) ? (string) $status['plan'] : '';
                if ($plan === '' && is_array($status['meta']) && !empty($status['meta']['plan'])) {
                    $plan = (string) $status['meta']['plan'];
                }
                if (is_array($status['meta'])) {
                    $postsLimit = isset($status['meta']['posts_limit'])
                        ? (int) $status['meta']['posts_limit']
                        : self::postsLimitForPlan($plan);
                    if ($postsLimit <= 0) {
                        $postsLimit = self::postsLimitForPlan($plan);
                    }
                }
            }
        }

        return self::renderWallForModule($module, $params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit, $plan);
    }

    /** Load module CSS (and share/images JS) once per request for shortcode embeds. */
    public static function enqueueModuleAssets()
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;

        $document = Factory::getApplication()->getDocument();
        $cssPath  = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/css/style.min.css';
        $cssVer   = is_file($cssPath) ? (string) filemtime($cssPath) : '4.0';
        self::addDocumentStyleSheet($document, (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/css/style.min.css', $cssVer);

        $shareJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/share.js';
        self::addDocumentScript(
            $document,
            (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/share.js',
            is_file($shareJs) ? (string) filemtime($shareJs) : '4.0',
            true
        );

        $imagesJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/images.js';
        self::addDocumentScript(
            $document,
            (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/images.js',
            is_file($imagesJs) ? (string) filemtime($imagesJs) : '4.0',
            true
        );

        $wallJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/wall.js';
        self::addDocumentScript(
            $document,
            (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/wall.js',
            is_file($wallJs) ? (string) filemtime($wallJs) : '4.0',
            true
        );
    }

    /** First published mod_js_like_box_pro instance on this site. */
    public static function findFirstPublishedModuleId()
    {
        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__modules'))
            ->where($db->quoteName('module') . ' = ' . $db->quote('mod_js_like_box_pro'))
            ->where($db->quoteName('published') . ' = 1')
            ->order($db->quoteName('ordering') . ' ASC');
        $db->setQuery($query, 0, 1);

        return (int) $db->loadResult();
    }

    public static function renderContactForm($params, $theme, $moduleId)
    {
        $theme       = self::normalizeTheme($theme);
        $intro       = trim((string) $params->get('contact_intro', ''));
        $successMsg  = trim((string) $params->get('contact_success_msg', ''));
        if ($successMsg === '') {
            $successMsg = 'Thank you! Your message has been sent.';
        }
        $showPhone   = (int) $params->get('contact_show_phone', 0) === 1;
        $submitLabel = trim((string) $params->get('contact_submit_label', ''));
        if ($submitLabel === '') {
            $submitLabel = 'Send message';
        }

        $ajaxUrl = self::buildContactAjaxUrl((int) $moduleId);
        $guard   = self::contactSignTimestamp((int) $moduleId);
        $fieldId = 'jlb-c-' . (int) $moduleId;

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--contact" style="--jssocial-accent: #6366F1;"
             data-contact-form="1"
             data-contact-url="<?php echo htmlspecialchars($ajaxUrl); ?>"
             data-contact-success="<?php echo htmlspecialchars($successMsg); ?>">
            <div class="jssocial_contact">
                <?php echo self::renderContactMap($params); ?>
                <?php echo self::renderContactDetails($params); ?>
                <?php if ($intro !== '') : ?>
                    <p class="jssocial_contact_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>

                <div class="jssocial_contact_alert" role="alert" aria-live="polite" hidden></div>

                <form class="jssocial_contact_form" method="post" action="<?php echo htmlspecialchars($ajaxUrl); ?>" novalidate>
                    <?php echo HTMLHelper::_('form.token'); ?>
                    <input type="hidden" name="module_id" value="<?php echo (int) $moduleId; ?>" />
                    <input type="hidden" name="contact_ts" value="<?php echo (int) $guard['ts']; ?>" />
                    <input type="hidden" name="contact_sig" value="<?php echo htmlspecialchars($guard['sig']); ?>" />

                    <div class="jssocial_contact_field">
                        <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-name">Name <span class="jssocial_contact_req">*</span></label>
                        <input class="jssocial_contact_input" id="<?php echo $fieldId; ?>-name" type="text" name="name" required maxlength="120" autocomplete="name" placeholder="Your name" />
                    </div>

                    <div class="jssocial_contact_field">
                        <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-email">Email <span class="jssocial_contact_req">*</span></label>
                        <input class="jssocial_contact_input" id="<?php echo $fieldId; ?>-email" type="email" name="email" required maxlength="200" autocomplete="email" placeholder="you@example.com" />
                    </div>

                    <?php if ($showPhone) : ?>
                        <div class="jssocial_contact_field">
                            <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-phone">Phone</label>
                            <input class="jssocial_contact_input" id="<?php echo $fieldId; ?>-phone" type="tel" name="phone" maxlength="40" autocomplete="tel" placeholder="+48 123 456 789" />
                        </div>
                    <?php endif; ?>

                    <div class="jssocial_contact_field">
                        <label class="jssocial_contact_label" for="<?php echo $fieldId; ?>-message">Message <span class="jssocial_contact_req">*</span></label>
                        <textarea class="jssocial_contact_input jssocial_contact_textarea" id="<?php echo $fieldId; ?>-message" name="message" rows="4" required maxlength="5000" placeholder="How can we help?"></textarea>
                    </div>

                    <div class="jssocial_contact_hp" aria-hidden="true">
                        <input type="text" name="contact_hp_a" tabindex="-1" autocomplete="new-password" inputmode="none" value="" />
                    </div>
                    <div class="jssocial_contact_hp" aria-hidden="true">
                        <input type="text" name="contact_hp_b" tabindex="-1" autocomplete="new-password" inputmode="none" value="" />
                    </div>

                    <button type="submit" class="jssocial_contact_submit">
                        <span class="jssocial_contact_submit_icon" aria-hidden="true"><i class="fas fa-paper-plane"></i></span>
                        <span class="jssocial_contact_submit_text"><?php echo htmlspecialchars($submitLabel); ?></span>
                        <span class="jssocial_contact_submit_loading" hidden><i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Sending…</span>
                    </button>
                </form>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function renderTestimonials(array $items, $theme, $params = null)
    {
        $theme = self::normalizeTheme($theme);
        $intro = '';
        $showSummary = true;
        $embed = '';
        $embedHeight = 360;

        if ($params instanceof Registry) {
            $intro = trim((string) $params->get('testimonials_intro', ''));
            $showSummary = (int) $params->get('testimonials_show_summary', 1) === 1;
            $embed = self::sanitizeReviewsEmbedUrl((string) $params->get('testimonials_embed_url', ''));
            $embedHeight = (int) $params->get('testimonials_embed_height', 360);
            if ($embedHeight < 200) {
                $embedHeight = 200;
            }
            if ($embedHeight > 900) {
                $embedHeight = 900;
            }
        }

        $stats = self::testimonialStats($items);

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--testimonials" style="--jssocial-accent: #F59E0B;">
            <div class="jssocial_testimonials">
                <?php if ($showSummary && $stats['rated_count'] > 0) : ?>
                    <div class="jssocial_testimonials_summary">
                        <div class="jssocial_testimonials_score">
                            <span class="jssocial_testimonials_score_value"><?php echo number_format($stats['average'], 1); ?></span>
                            <div class="jssocial_testimonials_score_stars" aria-label="<?php echo number_format($stats['average'], 1); ?> out of 5 stars">
                                <?php echo self::renderStarRating((int) round($stats['average'])); ?>
                            </div>
                        </div>
                        <div class="jssocial_testimonials_score_meta">
                            <strong><?php echo (int) $stats['count']; ?> review<?php echo $stats['count'] === 1 ? '' : 's'; ?></strong>
                            <span>Curated customer feedback</span>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($intro !== '') : ?>
                    <p class="jssocial_testimonials_intro"><?php echo nl2br(htmlspecialchars($intro)); ?></p>
                <?php endif; ?>

                <?php if ($embed !== '') : ?>
                    <div class="jssocial_reviews_embed">
                        <iframe src="<?php echo htmlspecialchars($embed); ?>" title="Customer reviews" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" style="width:100%;min-height:<?php echo (int) $embedHeight; ?>px;border:0;border-radius:8px;"></iframe>
                    </div>
                <?php endif; ?>

                <?php if ($items !== []) : ?>
                <div class="jssocial_testimonials_list">
                <?php foreach ($items as $item) : ?>
                    <article class="jssocial_testimonial<?php echo !empty($item['featured']) ? ' jssocial_testimonial--featured' : ''; ?>">
                        <div class="jssocial_testimonial_top">
                            <?php if ((int) $item['rating'] > 0) : ?>
                                <div class="jssocial_testimonial_stars" aria-label="<?php echo (int) $item['rating']; ?> out of 5 stars">
                                    <?php echo self::renderStarRating((int) $item['rating']); ?>
                                </div>
                            <?php endif; ?>
                            <span class="jssocial_testimonial_source">
                                <i class="<?php echo self::testimonialSourceIcon($item['source']); ?>" aria-hidden="true"></i>
                                <?php echo htmlspecialchars(self::testimonialSourceLabel($item['source'])); ?>
                            </span>
                        </div>

                        <?php if ($item['quote'] !== '') : ?>
                            <blockquote class="jssocial_testimonial_quote">
                                <span class="jssocial_testimonial_quote_mark" aria-hidden="true">“</span>
                                <?php echo nl2br(htmlspecialchars($item['quote'])); ?>
                            </blockquote>
                        <?php endif; ?>

                        <div class="jssocial_testimonial_author">
                            <?php echo self::renderTestimonialAvatar($item['name'], $item['avatar']); ?>
                            <div class="jssocial_testimonial_author_meta">
                                <?php if ($item['name'] !== '') : ?>
                                    <div class="jssocial_testimonial_name"><?php echo htmlspecialchars($item['name']); ?></div>
                                <?php endif; ?>
                                <?php if ($item['company'] !== '') : ?>
                                    <div class="jssocial_testimonial_company"><?php echo htmlspecialchars($item['company']); ?></div>
                                <?php endif; ?>
                                <?php if ($item['date'] !== '') : ?>
                                    <div class="jssocial_testimonial_date"><?php echo htmlspecialchars($item['date']); ?></div>
                                <?php endif; ?>
                            </div>
                            <?php if (!empty($item['featured'])) : ?>
                                <span class="jssocial_testimonial_featured">Featured</span>
                            <?php endif; ?>
                        </div>

                        <?php if ($item['link'] !== '') : ?>
                            <a class="jssocial_testimonial_link" href="<?php echo htmlspecialchars($item['link']); ?>" target="_blank" rel="noopener noreferrer">
                                View original review <i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i>
                            </a>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function renderStarRating($rating)
    {
        $rating = max(0, min(5, (int) $rating));
        $out    = '';
        for ($i = 1; $i <= 5; $i++) {
            $out .= '<i class="fas fa-star' . ($i <= $rating ? '' : ' jssocial_star--off') . '"></i>';
        }

        return $out;
    }

    /** Whether the jsns.eu plan tier should show the free-tier branding footer. */
    public static function isFreePlan($plan)
    {
        return strtolower(trim((string) $plan)) === 'free';
    }

    /** Pro and Premium (full UI). */
    public static function isProOrPremiumPlan($plan)
    {
        $plan = strtolower(trim((string) $plan));

        return $plan === 'pro' || $plan === 'premium';
    }

    /** Default posts-per-feed when the API status block omits posts_limit (offline fallback; mirrors com_js_like_box). */
    public static function postsLimitForPlan($plan)
    {
        switch (strtolower(trim((string) $plan))) {
            case 'free':
                return 3;
            case 'basic':
                return 6;
            case 'pro':
                return 12;
            case 'premium':
                return 24;
            default:
                return 12;
        }
    }

    /** Small “Designed by jsns.eu” bar below the limit warning (free plan). */
    public static function renderBranding()
    {
        ob_start();
        ?>
        <div class="jssocial_branding">
            Designed with <span class="jssocial_branding__heart" aria-hidden="true">&#10084;</span> by
            <a href="https://jsns.eu" target="_blank" rel="noopener">jsns.eu</a>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Fetch the meta block (usage, limits, beacon token) from the API.
     * Cheap on the API side (no paid provider call), so it runs every request.
     *
     * @return array|null  The 'meta' array, or null when the key/API is invalid.
     */
    public static function getStatus($apiUrl, $apiKey, $widgetId)
    {
        $result = self::fetchStatus($apiUrl, $apiKey, $widgetId);

        return $result['ok'] ? $result['meta'] : null;
    }

    /**
     * Human-readable message for a failed API key / status request.
     *
     * @param array<string, mixed> $status
     */
    public static function formatApiKeyStatusMessage(array $status, $fallback = 'Invalid or inactive API key.')
    {
        if (!empty($status['message'])) {
            return (string) $status['message'];
        }

        $pinned = array();
        if (!empty($status['pinned_domains']) && is_array($status['pinned_domains'])) {
            foreach ($status['pinned_domains'] as $domain) {
                $domain = trim((string) $domain);
                if ($domain !== '') {
                    $pinned[$domain] = true;
                }
            }
        }

        if ($pinned === [] && !empty($status['pinned_domain'])) {
            $domain = trim((string) $status['pinned_domain']);
            if ($domain !== '') {
                $pinned[$domain] = true;
            }
        }

        if ($pinned !== []) {
            return 'This API key is registered for: ' . implode(', ', array_keys($pinned))
                . '. Generate a separate key for each site.';
        }

        return (string) $fallback;
    }

    /**
     * Fetch status with HTTP/error details (module admin + clearer frontend messages).
     *
     * @return array{ok:bool,meta:?array,plan:?string,http_code:int,error:?string,message:?string,pinned_domains:?array}
     */
    public static function fetchStatus($apiUrl, $apiKey, $widgetId)
    {
        $empty = array(
            'ok'             => false,
            'meta'           => null,
            'plan'           => null,
            'http_code'      => 0,
            'error'          => null,
            'message'        => null,
            'pinned_domains' => array(),
        );

        $apiKey = trim((string) $apiKey);
        if ($apiKey === '') {
            $empty['message'] = 'missing_api_key';
            return $empty;
        }

        $response = self::apiRequest($apiUrl, $apiKey, 'status', array('widget_id' => $widgetId), 8);
        $empty['http_code'] = $response['http_code'];
        $empty['error']     = $response['error'];

        $json = $response['json'];
        if ($response['http_code'] === 200 && is_array($json) && !empty($json['success']) && isset($json['meta']) && is_array($json['meta'])) {
            return array(
                'ok'        => true,
                'meta'      => $json['meta'],
                'plan'      => isset($json['plan']) ? (string) $json['plan'] : null,
                'user_id'   => isset($json['user_id']) ? (int) $json['user_id'] : 0,
                'http_code' => 200,
                'error'     => null,
                'message'   => null,
            );
        }

        if (is_array($json)) {
            if (!empty($json['error'])) {
                $empty['message'] = (string) $json['error'];
            } elseif (!empty($json['message'])) {
                $empty['message'] = (string) $json['message'];
            }
            if (!empty($json['pinned_domains']) && is_array($json['pinned_domains'])) {
                $empty['pinned_domains'] = array_values(array_filter(array_map('strval', $json['pinned_domains'])));
            } elseif (!empty($json['domain'])) {
                $empty['pinned_domains'] = array((string) $json['domain']);
            }
        }

        return $empty;
    }

    /** Usage panel HTML for the module admin screen. */
    public static function renderAdminUsageHtml(array $status, $upgradeUrl = null)
    {
        $upgradeUrl = trim((string) ($upgradeUrl ?? self::UPGRADE_URL));
        if ($upgradeUrl === '') {
            $upgradeUrl = self::UPGRADE_URL;
        }

        if (!empty($status['message']) && $status['message'] === 'missing_api_key') {
            return '<div class="alert alert-info" style="margin:0;">Enter your API key above and save to see monthly usage.</div>';
        }

        if (empty($status['ok'])) {
            $msg = 'Could not load usage from the API.';
            if ((int) $status['http_code'] === 401) {
                $msg = self::formatApiKeyStatusMessage(
                    $status,
                    'Invalid or inactive API key. Generate a key in your jsns.eu dashboard.'
                );
            } elseif (!empty($status['message'])) {
                $msg = htmlspecialchars($status['message'], ENT_QUOTES, 'UTF-8');
            } elseif (!empty($status['error'])) {
                $msg = 'Connection error: ' . htmlspecialchars($status['error'], ENT_QUOTES, 'UTF-8');
            } elseif ((int) $status['http_code'] > 0) {
                $msg = 'API returned HTTP ' . (int) $status['http_code'] . '.';
            }

            return '<div class="alert alert-warning" style="margin:0;">' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8')
                . ' <a href="' . htmlspecialchars(self::DASHBOARD_URL, ENT_QUOTES) . '" target="_blank" rel="noopener">Open API keys dashboard</a></div>';
        }

        $meta         = is_array($status['meta']) ? $status['meta'] : array();
        $viewsUsed    = isset($meta['views_used']) ? (int) $meta['views_used'] : 0;
        $viewLimit    = isset($meta['view_limit']) ? (int) $meta['view_limit'] : 0;
        $widgetsUsed  = isset($meta['widgets_used']) ? (int) $meta['widgets_used'] : 0;
        $widgetLimit  = isset($meta['widget_limit']) ? (int) $meta['widget_limit'] : 0;
        $overLimit    = !empty($meta['over_limit']);
        $widgetDenied = $widgetLimit > 0 && $widgetsUsed >= $widgetLimit;
        $viewPct      = self::usageBarPercent($viewsUsed, $viewLimit);
        $widgetPct    = self::usageBarPercent($widgetsUsed, $widgetLimit);
        $viewPctLabel = self::usagePercent($viewsUsed, $viewLimit);
        $widgetPctLabel = self::usagePercent($widgetsUsed, $widgetLimit);
        $viewColor    = $overLimit ? '#d9534f' : ($viewPctLabel >= 85 ? '#f0ad4e' : '#5cb85c');
        $userId       = isset($status['user_id']) && (int) $status['user_id'] > 0 ? (int) $status['user_id'] : 0;

        ob_start();
        ?>
        <div class="jslikebox-admin-usage" style="max-width:520px;padding:12px 14px;border:1px solid #ccd0d4;border-radius:4px;background:#fff;color:#212529;">
            <?php if ($userId > 0) : ?>
                <p style="margin:0 0 10px;color:#212529;"><strong style="color:#212529;">Account ID:</strong> <?php echo $userId; ?> <span style="color:#6c757d;font-size:12px;">(from your API key)</span></p>
            <?php endif; ?>

            <p style="margin:0 0 6px;font-size:13px;color:#212529;"><strong style="color:#212529;">Monthly views</strong> — <?php echo number_format($viewsUsed); ?> / <?php echo number_format($viewLimit); ?> (<?php echo $viewPctLabel; ?>%)</p>
            <div style="background:#e9ecef;height:18px;border-radius:4px;overflow:hidden;margin-bottom:12px;">
                <div style="width:<?php echo $viewPct; ?>%;min-width:<?php echo $viewsUsed > 0 ? '8px' : '0'; ?>;height:100%;background:<?php echo $viewColor; ?>;"></div>
            </div>

            <p style="margin:0 0 6px;font-size:13px;color:#212529;"><strong style="color:#212529;">Active sites</strong> — <?php echo (int) $widgetsUsed; ?> / <?php echo (int) $widgetLimit; ?> (<?php echo $widgetPctLabel; ?>%)</p>
            <div style="background:#e9ecef;height:18px;border-radius:4px;overflow:hidden;margin-bottom:12px;">
                <div style="width:<?php echo $widgetPct; ?>%;min-width:<?php echo $widgetsUsed > 0 ? '8px' : '0'; ?>;height:100%;background:#5bc0de;"></div>
            </div>

            <?php if ($overLimit) : ?>
                <div class="alert alert-warning" style="margin:0 0 10px;padding:8px 10px;">
                    You have reached your monthly view limit. Feeds keep showing cached data.
                </div>
            <?php endif; ?>

            <?php if ($widgetDenied) : ?>
                <div class="alert alert-warning" style="margin:0 0 10px;padding:8px 10px;">
                    This module exceeds your plan&rsquo;s widget limit and will not render on the site.
                </div>
            <?php endif; ?>

            <p style="margin:0;font-size:13px;color:#212529;">
                <a href="<?php echo htmlspecialchars($upgradeUrl, ENT_QUOTES); ?>" target="_blank" rel="noopener" style="color:#0d6efd;"><strong style="color:#0d6efd;">Upgrade your plan on jsns.eu</strong></a>
                to increase limits or manage API keys.
            </p>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Frontend notice shown inside the feed panel when the monthly view limit
     * is reached and cached posts are displayed.
     */
    public static function renderOverLimitNotice($theme = 'light')
    {
        $dark  = self::isDarkFeedTheme($theme);
        $class = 'social_feed_overlimit' . ($dark ? ' social_feed_overlimit--dark' : '');

        ob_start();
        ?>
        <div class="<?php echo $class; ?>" role="status">
            <p class="social_feed_overlimit__title">Monthly view limit reached</p>
            <p class="social_feed_overlimit__text">Showing cached posts. <a href="<?php echo htmlspecialchars(self::UPGRADE_URL); ?>" target="_blank" rel="noopener">Upgrade your plan</a></p>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Fetch a normalized feed ({profile, posts}) for a platform, with a disk
     * cache and stale fallback.
     *
     * @param string $accountType  linkedin|profile|board etc.
     * @param bool   $syncCold     When true, API may block on cold cache (Apify). Lazy AJAX should leave false.
     *
     * @return array|null  {platform, profile, posts} or null when unavailable.
     */
    public static function getFeed($apiUrl, $apiKey, $platform, $identifier, $widgetId, $limit = 12, $accountType = '', $syncCold = false)
    {
        $identifier = trim((string) $identifier);
        $cfg = self::getPlatform($platform);
        if ($identifier === '' || $cfg === null) {
            return null;
        }

        if ($platform === 'linkedin') {
            $accountType = ($accountType === 'profile') ? 'profile' : 'company';
            $identifier   = self::normalizeLinkedInIdentifier($identifier, $accountType);
            if ($identifier === '') {
                return null;
            }
        }

        if ($platform === 'pinterest') {
            $accountType = ($accountType === 'board') ? 'board' : 'profile';
            $identifier  = self::normalizePinterestIdentifier($identifier, $accountType);
            if ($identifier === '') {
                return null;
            }
        }

        if ($platform === 'google_reviews') {
            $identifier = self::normalizeGooglePlace($identifier);
            if ($identifier === '') {
                return null;
            }
        }

        $limit     = max(1, (int) $limit);
        $cacheDir  = (JPATH_CACHE . '/mod_js_like_box_pro');
        $cacheVer  = ($platform === 'linkedin') ? '_v10' : (($platform === 'twitter' || $platform === 'facebook') ? '_v11' : (($platform === 'instagram') ? '_v5' : (($platform === 'telegram') ? '_v5' : (($platform === 'tiktok') ? '_v6' : (($platform === 'pinterest') ? '_v6' : (($platform === 'google_reviews') ? '_v5' : '_v3'))))));
        $idHash    = md5(strtolower($identifier));

        $cached = self::getFeedFromModuleCache($platform, $identifier, $limit, $accountType, true);
        if (is_array($cached)) {
            return $cached;
        }

        $query = array(
            $cfg['api_param'] => ($platform === 'twitter' || $platform === 'tiktok') ? ltrim($identifier, '@') : $identifier,
            'widget_id'       => $widgetId,
            'limit'           => $limit,
        );
        if ($syncCold) {
            $query['sync'] = 1;
        }
        if ($platform === 'linkedin') {
            $query['type'] = $accountType;
        }
        if ($platform === 'pinterest') {
            $query['type'] = $accountType;
        }

        $timeout = in_array($platform, array('facebook', 'google_reviews'), true)
            ? ($syncCold ? 130 : 20)
            : ($syncCold ? 25 : 12);
        $json = self::apiCall($apiUrl, $apiKey, $cfg['endpoint'], $query, $timeout);
        $data = null;
        if (is_array($json) && empty($json['warming']) && isset($json['data']) && is_array($json['data'])) {
            $data = $json['data'];
        }

        if (is_array($data) && self::feedHasContent($platform, $data)) {
            $data = self::normalizeFeedPayload($data, $limit);
            // A stale API payload is only a stand-in while the scheduled refresh
            // runs. Saving it would reset the 30-minute disk cache and keep
            // month-old posts on screen.
            if (empty($json['stale'])) {
                if (!is_dir($cacheDir)) {
                    @mkdir($cacheDir, 0755, true);
                }
                @file_put_contents(
                    self::feedCacheFile($cacheDir, $platform, $cacheVer, $idHash, $limit),
                    json_encode($data)
                );
            }

            return $data;
        }

        $stale = self::getFeedFromModuleCache($platform, $identifier, $limit, $accountType);
        if (is_array($stale)) {
            return $stale;
        }

        return is_array($data) ? self::normalizeFeedPayload($data, $limit) : null;
    }

    /**
     * Read a platform feed from module disk cache only (populated when slider tabs load).
     * Tries richer limits (12/24) when a smaller limit was requested.
     *
     * @return array|null  {profile, posts} or null when not cached.
     */
    public static function getFeedFromModuleCache($platform, $identifier, $limit = 12, $accountType = '', $freshOnly = false)
    {
        $identifier = trim((string) $identifier);
        $cfg = self::getPlatform($platform);
        if ($identifier === '' || $cfg === null) {
            return null;
        }

        if ($platform === 'linkedin') {
            $accountType = ($accountType === 'profile') ? 'profile' : 'company';
            $identifier   = self::normalizeLinkedInIdentifier($identifier, $accountType);
            if ($identifier === '') {
                return null;
            }
        }

        if ($platform === 'pinterest') {
            $accountType = ($accountType === 'board') ? 'board' : 'profile';
            $identifier  = self::normalizePinterestIdentifier($identifier, $accountType);
            if ($identifier === '') {
                return null;
            }
        }

        if ($platform === 'google_reviews') {
            $identifier = self::normalizeGooglePlace($identifier);
            if ($identifier === '') {
                return null;
            }
        }

        $limit    = max(1, (int) $limit);
        $cacheDir = (JPATH_CACHE . '/mod_js_like_box_pro');
        $cacheVer = ($platform === 'linkedin') ? '_v10' : (($platform === 'twitter' || $platform === 'facebook') ? '_v11' : (($platform === 'instagram') ? '_v5' : (($platform === 'telegram') ? '_v5' : (($platform === 'tiktok') ? '_v6' : (($platform === 'pinterest') ? '_v6' : (($platform === 'google_reviews') ? '_v5' : '_v3'))))));
        $idHash   = md5(strtolower($identifier));

        $cached = self::readFeedCache($cacheDir, $platform, $cacheVer, $idHash, $limit, true);
        if (is_array($cached) && self::feedHasContent($platform, $cached)) {
            return $cached;
        }

        if ($freshOnly) {
            return null;
        }

        $stale = self::readFeedCache($cacheDir, $platform, $cacheVer, $idHash, $limit, false);

        return (is_array($stale) && self::feedHasContent($platform, $stale)) ? $stale : null;
    }

    /** Cache file path for a platform feed payload. */
    private static function feedCacheFile($cacheDir, $platform, $cacheVer, $idHash, $limit)
    {
        return $cacheDir . '/' . $platform . $cacheVer . '_' . $idHash . '_' . (int) $limit . '.json';
    }

    /** Prefer richer cached feeds (higher limit keys) so tabs match the wall. */
    private static function feedCacheLimitsToTry($limit)
    {
        $limit = max(1, (int) $limit);
        $candidates = array($limit, 24, 12, 6);
        $out = array();
        foreach ($candidates as $candidate) {
            if ($candidate >= $limit && !in_array($candidate, $out, true)) {
                $out[] = $candidate;
            }
        }
        rsort($out);

        return $out !== [] ? $out : array($limit);
    }

    /** Read cached feed JSON (fresh or stale), normalised to newest-first + limit cap. */
    private static function readFeedCache($cacheDir, $platform, $cacheVer, $idHash, $limit, $requireFresh)
    {
        foreach (self::feedCacheLimitsToTry($limit) as $tryLimit) {
            $cacheFile = self::feedCacheFile($cacheDir, $platform, $cacheVer, $idHash, $tryLimit);
            if (!is_file($cacheFile)) {
                continue;
            }
            if ($requireFresh && (time() - filemtime($cacheFile)) >= self::FEED_TTL) {
                continue;
            }

            $payload = json_decode(file_get_contents($cacheFile), true);
            if (!is_array($payload)) {
                continue;
            }

            return self::normalizeFeedPayload($payload, $limit);
        }

        return null;
    }

    /** Sort posts newest-first and cap count for display. */
    private static function normalizeFeedPayload(array $data, $limit)
    {
        if (!empty($data['posts']) && is_array($data['posts'])) {
            $data['posts'] = self::sortPostsByDateDesc($data['posts']);
            $limit = max(1, (int) $limit);
            if (count($data['posts']) > $limit) {
                $data['posts'] = array_slice($data['posts'], 0, $limit);
            }
        }

        return $data;
    }

    /** Parse created_at for sorting (ISO-8601, unix string, or empty). */
    private static function postTimestamp($post)
    {
        if (!is_array($post)) {
            return 0;
        }

        $raw = trim((string) ($post['created_at'] ?? ''));
        if ($raw === '') {
            return 0;
        }

        if (ctype_digit($raw)) {
            return (int) $raw;
        }

        $ts = strtotime($raw);

        return $ts !== false ? $ts : 0;
    }

    /** Newest posts first. */
    private static function sortPostsByDateDesc(array $posts)
    {
        usort($posts, function ($a, $b) {
            return self::postTimestamp($b) <=> self::postTimestamp($a);
        });

        return $posts;
    }

    /** True when a feed payload includes at least one post card. */
    private static function feedHasPosts($data)
    {
        return is_array($data)
            && !empty($data['posts'])
            && is_array($data['posts'])
            && count($data['posts']) > 0;
    }

    /**
     * Cold Apify-backed feeds need one blocking fetch when cache/warming returned no posts.
     */
    private static function needsBlockingFeedFetch($slug, $data, $showFeedPosts = true)
    {
        if (!in_array($slug, array('facebook', 'instagram', 'tiktok', 'pinterest', 'telegram', 'google_reviews'), true)) {
            return false;
        }

        if ($showFeedPosts) {
            return !self::feedHasPosts($data);
        }

        return !is_array($data) || !self::feedHasContent($slug, $data);
    }

    /** True when a feed response is worth caching and rendering. */
    private static function feedHasContent($platform, array $data)
    {
        if (!empty($data['posts']) && is_array($data['posts'])) {
            return true;
        }

        if (empty($data['profile']) || !is_array($data['profile'])) {
            return false;
        }

        $profile = $data['profile'];
        $name    = trim((string) ($profile['display_name'] ?? ''));
        $avatar  = trim((string) ($profile['avatar'] ?? ''));
        $bio     = trim((string) ($profile['bio'] ?? ''));
        $handle  = trim((string) ($profile['username'] ?? ''));
        $cover   = trim((string) ($profile['cover'] ?? ''));

        if ($platform === 'facebook') {
            if ($name === '' || self::isInvalidFacebookHandle($name)) {
                $name = '';
            }
            if (self::isInvalidFacebookHandle($handle)) {
                $handle = '';
            }
        }

        return $avatar !== '' || $bio !== '' || $cover !== ''
            || ($name !== '' && ($handle === '' || $name !== $handle));
    }

    /**
     * Perform an authenticated GET against the Like Box API.
     *
     * @return array|null  Decoded JSON, or null on failure.
     */
    private static function apiCall($apiUrl, $apiKey, $path, array $query, $timeout)
    {
        $response = self::apiRequest($apiUrl, $apiKey, $path, $query, $timeout);

        if ($response['http_code'] !== 200 || !is_array($response['json'])) {
            return null;
        }

        return $response['json'];
    }

    /** @return string Current site hostname (for API domain tracking). */
    public static function getSiteDomain()
    {
        try {
            $host = Uri::getInstance()->getHost();
            $host = strtolower(trim((string) $host));

            return preg_replace('#^www\.#', '', $host);
        } catch (Exception $e) {
            return '';
        }
    }

    /** @return bool True when the current user may manage site modules. */
    public static function canManageModules()
    {
        try {
            $app  = Factory::getApplication();
            $user = method_exists($app, 'getIdentity') ? $app->getIdentity() : Factory::getUser();

            if (!is_object($user) || !empty($user->guest)) {
                return false;
            }

            return (bool) $user->authorise('core.manage', 'com_modules');
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * @return array{http_code:int,json:?array,error:?string}
     */
    private static function apiRequest($apiUrl, $apiKey, $path, array $query, $timeout)
    {
        $result = array(
            'http_code' => 0,
            'json'      => null,
            'error'     => null,
        );

        $apiUrl = trim((string) $apiUrl);
        $apiKey = trim((string) $apiKey);
        if ($apiUrl === '' || $apiKey === '') {
            return $result;
        }

        $siteDomain = self::getSiteDomain();
        if ($siteDomain !== '' && !isset($query['domain'])) {
            $query['domain'] = $siteDomain;
        }

        $endpoint = rtrim($apiUrl, '/') . '/' . ltrim($path, '/');
        $endpoint .= (strpos($endpoint, '?') === false ? '?' : '&') . http_build_query($query);

        if (!function_exists('curl_init')) {
            $result['error'] = 'curl extension unavailable';
            return $result;
        }

        $headers = array(
            'X-API-Key: ' . $apiKey,
            'User-Agent: JSLikeBoxPro/4.1.0',
        );
        if ($siteDomain !== '') {
            $headers[] = 'X-Site-Domain: ' . $siteDomain;
        }

        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => (int) $timeout,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_HTTPHEADER     => $headers,
        ));

        $response = curl_exec($ch);
        $code     = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        $result['http_code'] = $code;

        if ($response === false) {
            $result['error'] = $curlErr !== '' ? $curlErr : 'request failed';
            return $result;
        }

        $json = json_decode($response, true);
        $result['json'] = is_array($json) ? $json : null;

        return $result;
    }

    /**
     * Render a feed tab (profile header + posts) for any platform.
     *
     * @param   string      $platform     instagram|twitter|facebook|youtube
     * @param   array|null  $data         Feed data from getFeed().
     * @param   string      $fallbackUrl  Profile URL for the follow button.
     * @param   string      $identifier   Raw identifier (fallback label).
     * @param   int         $columns      Grid columns (Instagram only).
     *
     * @return  string  HTML markup.
     */
    public static function renderFeed($platform, $data, $fallbackUrl, $identifier, $columns = 2, $apiUrl = '', $theme = 'light', $showPosts = true)
    {
        $isX  = ($platform === 'twitter' || $platform === 'x');
        $isYt = ($platform === 'youtube');

        $profile = (is_array($data) && isset($data['profile']) && is_array($data['profile'])) ? $data['profile'] : array();
        $posts   = (is_array($data) && isset($data['posts']) && is_array($data['posts'])) ? $data['posts'] : array();
        if ($posts !== []) {
            $posts = self::sortPostsByDateDesc($posts);
        }

        $username  = trim((string) ($profile['username'] ?? ''));
        $name      = trim((string) ($profile['display_name'] ?? ''));

        if ($platform === 'facebook') {
            if ($name === '' || self::isInvalidFacebookHandle($name)) {
                $name = self::resolveFacebookDisplayName($profile, $posts);
            }
            if ($username === '' || self::isInvalidFacebookHandle($username)) {
                $username = self::facebookSlugFromUrl(isset($profile['url']) ? (string) $profile['url'] : '');
            }
            if (($username === '' || self::isInvalidFacebookHandle($username)) && !self::isInvalidFacebookHandle($identifier)) {
                $username = trim((string) $identifier);
            }
        } else {
            if ($username === '') {
                $username = (string) $identifier;
            }
            if ($name === '') {
                $name = $username;
            }
        }

        $handle    = $username;
        if ($platform === 'facebook' && self::isInvalidFacebookHandle($handle)) {
            $handle = '';
        }
        $avatar    = self::proxied($apiUrl, self::normalizeAvatarUrl(isset($profile['avatar']) ? (string) $profile['avatar'] : ''));
        $cover     = self::resolveCover($apiUrl, $platform, $profile, $posts);
        $followers = (int) ($profile['followers'] ?? $profile['followerCount'] ?? 0);
        $verified  = self::isProfileVerified($profile);
        $profUrl   = isset($profile['url']) && $profile['url'] !== '' ? $profile['url'] : $fallbackUrl;

        $following   = isset($profile['following']) ? (int) $profile['following'] : 0;
        $connections = (int) ($profile['connections'] ?? $profile['connectionsCount'] ?? 0);
        if ($connections === 0 && $platform === 'linkedin') {
            $connections = $following;
        }
        $postsNum  = isset($profile['posts_count']) ? (int) $profile['posts_count'] : 0;
        if ($postsNum === 0 && !empty($posts)) {
            $postsNum = count($posts);
        }
        $profViews = isset($profile['views']) ? (int) $profile['views'] : 0;
        $bio       = self::formatProfileBio(isset($profile['bio']) ? (string) $profile['bio'] : '', $name, $handle);

        $meta  = self::platformMeta($platform);
        $theme = self::normalizeTheme($theme);

        // Stat cells shown under the name (value, label) - zeros are skipped.
        $stats = self::profileStats($platform, $postsNum, $followers, $following, $profViews, $connections);

        // Shared context passed to the per-post renderers.
        $ctx = array(
            'apiUrl'      => $apiUrl,
            'avatar'      => $avatar,
            'handle'      => $handle,
            'displayName' => $name,
            'profileUrl'  => $profUrl,
            'meta'        => $meta,
            'platform'    => $platform,
            'isX'         => $isX,
            'verified'    => $verified,
        );

        $isIg = ($platform === 'instagram');
        $hasProfile = ($avatar !== '' || $bio !== '' || $cover !== '' || $followers > 0 || $connections > 0 || $following > 0
            || ($name !== '' && strtolower($name) !== 'facebook')
            || ($handle !== '' && ($platform !== 'facebook' || !self::isInvalidFacebookHandle($handle))));

        ob_start();
        ?>
        <div class="jssocial_feed jssocial_feed--<?php echo $theme; ?> jssocial_feed--<?php echo htmlspecialchars($platform); ?>" style="--jssocial-accent: <?php echo $meta['accent']; ?>;">
            <div class="jssocial_profile">
                <?php if ($cover !== '') : ?>
                <div class="jssocial_cover jssocial_cover--img">
                    <?php echo self::lazyImg($cover, 'jssocial_cover_img', 'jssocial_imgwrap--cover', 'loading="eager" fetchpriority="high" decoding="async"'); ?>
                    <i class="fab <?php echo $meta['icon']; ?> jssocial_cover_badge"></i>
                </div>
                <?php elseif (!$isIg) : ?>
                <div class="jssocial_cover">
                    <i class="fab <?php echo $meta['icon']; ?> jssocial_cover_badge"></i>
                </div>
                <?php endif; ?>
                <div class="jssocial_profile_body<?php echo $cover !== '' ? ' jssocial_profile_body--cover' : ''; ?>">
                    <span class="jssocial_avatar_wrap">
                        <?php if ($avatar !== '') : ?>
                            <?php echo self::lazyImg($avatar, 'jssocial_avatar', 'jssocial_imgwrap--round jssocial_imgwrap--avatar'); ?>
                        <?php else : ?>
                            <span class="jssocial_avatar jssocial_avatar--ph"><i class="fab <?php echo $meta['icon']; ?>"></i></span>
                        <?php endif; ?>
                    </span>
                    <div class="jssocial_ident">
                        <div class="jssocial_name">
                            <a href="<?php echo htmlspecialchars($profUrl); ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($name); ?></a>
                            <?php echo self::verifiedBadge($verified, $platform); ?>
                        </div>
                        <?php if ($handle !== '') : ?>
                            <div class="jssocial_handle"><?php echo htmlspecialchars(self::formatHandle($platform, $handle)); ?></div>
                        <?php endif; ?>
                        <?php if ($bio !== '') : ?>
                            <div class="jssocial_tagline"><?php echo htmlspecialchars($bio); ?></div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($stats)) : ?>
                        <div class="jssocial_stats">
                            <?php foreach ($stats as $st) : ?>
                                <span class="jssocial_statcell">
                                    <b><?php echo htmlspecialchars(self::formatCount($st[0])); ?></b>
                                    <small><?php echo htmlspecialchars($st[1]); ?></small>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <a class="jssocial_action" href="<?php echo htmlspecialchars($profUrl); ?>" target="_blank" rel="noopener">
                        <i class="fab <?php echo $meta['icon']; ?>"></i> <?php echo htmlspecialchars($meta['button']); ?>
                    </a>
                </div>
            </div>

            <?php if ($showPosts && !empty($posts) && $isYt) : ?>
                <?php echo self::renderYouTubeList($posts, $ctx); ?>
            <?php elseif ($showPosts && !empty($posts)) : ?>
                <?php echo self::renderPostList($posts, $ctx); ?>
            <?php elseif (!$showPosts && $hasProfile) : ?>
                <div class="jssocial_empty jssocial_empty--profile_only">
                    <p>Visit our profile for the latest updates.</p>
                </div>
            <?php elseif ($hasProfile) : ?>
                <div class="jssocial_empty">
                    <p>No public posts to show right now.</p>
                </div>
            <?php else : ?>
                <div class="jssocial_empty">
                    <p>Latest posts are loading&hellip; check back in a moment, or visit the profile.</p>
                </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Build the (value, label) stat cells for a platform, skipping zeros. */
    private static function profileStats($platform, $posts, $followers, $following, $profileViews = 0, $connections = 0)
    {
        switch ($platform) {
            case 'instagram':
                $cells = array(array($posts, 'Posts'), array($followers, 'Followers'), array($following, 'Following'));
                break;
            case 'twitter':
            case 'x':
                $cells = array(array($posts, 'Posts'), array($following, 'Following'), array($followers, 'Followers'));
                break;
            case 'youtube':
                $cells = array(
                    array($followers, 'Subscribers'),
                    array($posts, 'Videos'),
                    array($profileViews, 'Views'),
                );
                break;
            case 'linkedin':
                $cells = array(array($posts, 'Posts'));
                if ($followers > 0) {
                    $cells[] = array($followers, 'Followers');
                }
                if ($connections > 0) {
                    $cells[] = array($connections, 'Connections');
                }
                break;
            case 'tiktok':
                $cells = array(
                    array($posts, 'Videos'),
                    array($followers, 'Followers'),
                    array($following, 'Following'),
                );
                break;
            case 'pinterest':
                $cells = array(array($posts, 'Pins'), array($followers, 'Followers'));
                if ($following > 0) {
                    $cells[] = array($following, 'Following');
                }
                break;
            case 'telegram':
                $cells = array(array($followers, 'Subscribers'), array($posts, 'Posts'));
                break;
            case 'facebook':
            default:
                $cells = array(array($followers, 'Likes'));
                break;
        }

        $out = array();
        foreach ($cells as $c) {
            if ((int) $c[0] > 0) {
                $out[] = $c;
            }
        }
        return $out;
    }

    /** Rich post cards (image, caption, author row, actions) matching the design. */
    private static function renderPostList(array $posts, array $ctx, $wrapperClass = 'jssocial_posts', array $opts = array())
    {
        $meta        = $ctx['meta'];
        $avatar      = (string) $ctx['avatar'];
        $handle      = (string) $ctx['handle'];
        $platform    = isset($ctx['platform']) ? (string) $ctx['platform'] : '';
        $verified    = !empty($ctx['verified']);
        $wallInitial = isset($opts['wallInitial']) ? (int) $opts['wallInitial'] : 0;

        ob_start();
        ?>
        <div class="<?php echo htmlspecialchars($wrapperClass); ?>">
            <?php foreach ($posts as $index => $post) : ?>
                <?php
                    $postPlatform = isset($post['_platform']) ? (string) $post['_platform'] : $platform;
                    $postMeta     = ($postPlatform !== '' && $postPlatform !== $platform)
                        ? self::platformMeta($postPlatform)
                        : $meta;
                    $postCtx      = $ctx;
                    $postCtx['platform'] = $postPlatform;
                    $postCtx['meta']     = $postMeta;
                    $postCtx['isX']      = ($postPlatform === 'twitter' || $postPlatform === 'x');

                    if (!empty($ctx['profiles'][$postPlatform]) && is_array($ctx['profiles'][$postPlatform])) {
                        $prof = $ctx['profiles'][$postPlatform];
                        $postCtx['avatar']      = self::proxied($ctx['apiUrl'], self::normalizeAvatarUrl(isset($prof['avatar']) ? (string) $prof['avatar'] : ''));
                        $postCtx['handle']      = (isset($prof['username']) && $prof['username'] !== '') ? (string) $prof['username'] : '';
                        $postCtx['displayName'] = (isset($prof['display_name']) && $prof['display_name'] !== '')
                            ? (string) $prof['display_name']
                            : $postCtx['handle'];
                        if ($postPlatform === 'facebook' && ($postCtx['displayName'] === '' || self::isInvalidFacebookHandle($postCtx['displayName']))) {
                            $postCtx['displayName'] = self::resolveFacebookDisplayName($prof, array($post));
                        }
                        $postCtx['profileUrl']  = isset($prof['url']) && $prof['url'] !== '' ? (string) $prof['url'] : self::buildProfileUrl($postPlatform, $postCtx['handle']);
                        $postCtx['verified']    = self::isProfileVerified($prof);
                    }

                    $cardAvatar   = '';
                    $cardHandle   = (string) $postCtx['handle'];
                    $cardName     = trim((string) ($postCtx['displayName'] ?? ''));
                    $cardProfUrl  = (string) $postCtx['profileUrl'];
                    $cardVerified = !empty($postCtx['verified']);
                    $cardMeta     = $postCtx['meta'];

                    if (!empty($post['author_name']) || !empty($post['author_username']) || !empty($post['author_url'])) {
                        if (!empty($post['author_name'])) {
                            $cardName = trim((string) $post['author_name']);
                        }
                        if (!empty($post['author_username']) && !self::isInvalidFacebookHandle($post['author_username'])) {
                            $cardHandle = trim((string) $post['author_username']);
                        }
                        if (!empty($post['author_url'])) {
                            $cardProfUrl = trim((string) $post['author_url']);
                        }
                        if (!empty($post['author_verified'])) {
                            $cardVerified = true;
                        }
                    }

                    $purl = (isset($post['url']) && $post['url'] !== '')
                        ? trim((string) $post['url'])
                        : $cardProfUrl;

                    $cardAvatar = self::resolveCardAvatar($ctx['apiUrl'], $post, $postPlatform, $ctx['profiles'] ?? array(), $postCtx);
                    $cardLabel  = self::postCardLabel($postPlatform, $cardName, $cardHandle);
                    $caption = isset($post['caption']) ? (string) $post['caption'] : '';
                    $sharedFrom = trim((string) ($post['shared_from_name'] ?? ''));
                    $image   = self::proxied($ctx['apiUrl'], isset($post['image']) ? (string) $post['image'] : '');
                    $created = isset($post['created_at']) ? (string) $post['created_at'] : '';
                    $cardClass = 'jssocial_card';
                    if ($wallInitial > 0 && $index >= $wallInitial) {
                        $cardClass .= ' jssocial_card--wall-hidden';
                    }
                ?>
                <article class="<?php echo $cardClass; ?>">
                    <?php if ($image !== '') : ?>
                        <a class="jssocial_card_media" href="<?php echo htmlspecialchars($purl); ?>" target="_blank" rel="noopener">
                            <?php echo self::lazyImg($image); ?>
                        </a>
                    <?php endif; ?>

                    <div class="jssocial_card_body">
                        <?php if ($caption !== '' || $sharedFrom !== '') : ?>
                            <a class="jssocial_card_caption" href="<?php echo htmlspecialchars($purl); ?>" target="_blank" rel="noopener"><?php
                                if ($sharedFrom !== '') {
                                    echo '<span class="jssocial_card_shared">Shared from ' . htmlspecialchars($sharedFrom) . '</span>';
                                }
                                if ($caption !== '') {
                                    echo ($sharedFrom !== '' ? '<br>' : '') . nl2br(htmlspecialchars($caption));
                                }
                            ?></a>
                        <?php endif; ?>

                        <div class="jssocial_card_author">
                            <?php echo self::renderCardAvatar($cardAvatar, $cardMeta); ?>
                            <div class="jssocial_card_authinfo">
                                <span class="jssocial_card_namerow">
                                    <a class="jssocial_card_name" href="<?php echo htmlspecialchars($cardProfUrl); ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($cardLabel); ?></a>
                                    <?php echo self::verifiedBadge($cardVerified, $postPlatform); ?>
                                </span>
                                <?php if ($created !== '') : ?><span class="jssocial_card_date"><?php echo htmlspecialchars(self::formatDate($created)); ?></span><?php endif; ?>
                            </div>
                            <i class="fab <?php echo $cardMeta['icon']; ?> jssocial_card_platform"></i>
                        </div>

                        <?php echo self::renderPostActions($post, $postCtx, $purl); ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Platform-specific engagement row under each post card. */
    private static function renderPostActions(array $post, array $ctx, $purl)
    {
        $platform = isset($ctx['platform']) ? (string) $ctx['platform'] : '';
        $isX      = !empty($ctx['isX']);
        $likes    = isset($post['likes']) ? (int) $post['likes'] : 0;
        $comments = isset($post['comments']) ? (int) $post['comments'] : 0;
        $shares   = isset($post['shares']) ? (int) $post['shares'] : 0;

        ob_start();

        if ($platform === 'facebook') {
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--facebook">
                <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <?php if ($shares > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('share'); ?> <?php echo self::formatCount($shares); ?></span>
                <?php endif; ?>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($isX) {
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--x">
                <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('retweet'); ?> <?php echo self::formatCount($shares); ?></span>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($platform === 'youtube') {
            $views = self::ytCount($post, array('views', 'viewCount', 'viewsCount'));
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--youtube">
                <?php if ($views > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('play'); ?> <?php echo self::formatCount($views); ?></span>
                <?php endif; ?>
                <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($platform === 'pinterest') {
            $saves = isset($post['saves']) ? (int) $post['saves'] : 0;
            if ($saves <= 0 && $likes > 0) {
                $saves = $likes;
            }
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--pinterest">
                <?php if ($saves > 0) : ?>
                    <span class="jssocial_stat" title="Saves"><?php echo self::icon('save'); ?> <?php echo self::formatCount($saves); ?></span>
                <?php endif; ?>
                <?php if ($comments > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
                <?php endif; ?>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        if ($platform === 'telegram') {
            $views = isset($post['views']) ? (int) $post['views'] : 0;
            ?>
            <div class="jssocial_card_actions jssocial_card_actions--telegram">
                <?php if ($views > 0) : ?>
                    <span class="jssocial_stat"><?php echo self::icon('views'); ?> <?php echo self::formatCount($views); ?></span>
                <?php endif; ?>
                <?php if ($likes > 0) : ?>
                    <span class="jssocial_stat" title="Reactions"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
                <?php endif; ?>
                <?php if ($shares > 0) : ?>
                    <span class="jssocial_stat" title="Forwards"><?php echo self::icon('share'); ?> <?php echo self::formatCount($shares); ?></span>
                <?php endif; ?>
                <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
            </div>
            <?php
            return ob_get_clean();
        }

        ?>
        <div class="jssocial_card_actions">
            <span class="jssocial_stat"><?php echo self::icon('heart'); ?> <?php echo self::formatCount($likes); ?></span>
            <span class="jssocial_stat"><?php echo self::icon('comment'); ?> <?php echo self::formatCount($comments); ?></span>
            <?php echo self::renderSharePopup($purl, isset($post['caption']) ? (string) $post['caption'] : ''); ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Normalise theme param (legacy aliases → current values). */
    public static function normalizeTheme($theme)
    {
        $theme = (string) $theme;
        if ($theme === 'fintech') {
            $theme = 'rounded_light';
        }
        if ($theme === 'rounded') {
            $theme = 'rounded_dark';
        }
        $allowed = array('light', 'dark', 'rounded_light', 'rounded_dark', 'minimal', 'warm', 'neon');
        return in_array($theme, $allowed, true) ? $theme : 'rounded_dark';
    }

    /** Whether the theme uses a dark feed background. */
    public static function isDarkFeedTheme($theme)
    {
        $theme = self::normalizeTheme($theme);
        return in_array($theme, array('dark', 'rounded_dark', 'neon'), true);
    }

    /** Whether the theme uses rounded cards + DM Sans styling. */
    public static function isRoundedTheme($theme)
    {
        $theme = self::normalizeTheme($theme);
        return $theme === 'rounded_light' || $theme === 'rounded_dark';
    }

    /** Pick the best proxied avatar URL for a post card author row. */
    private static function resolveCardAvatar($apiUrl, array $post, $postPlatform, array $profiles, array $postCtx)
    {
        $candidates = array();

        if (!empty($post['author_avatar'])) {
            $candidates[] = (string) $post['author_avatar'];
        }
        if ($postPlatform !== '' && !empty($profiles[$postPlatform]['avatar'])) {
            $candidates[] = (string) $profiles[$postPlatform]['avatar'];
        }
        if (!empty($postCtx['avatar'])) {
            $candidates[] = (string) $postCtx['avatar'];
        }

        foreach ($candidates as $raw) {
            $raw = trim($raw);
            if ($raw === '' || !self::isUsableAvatarUrl($raw)) {
                continue;
            }
            $url = self::proxied($apiUrl, self::normalizeAvatarUrl($raw));
            if ($url !== '' && self::isUsableAvatarUrl($url)) {
                return $url;
            }
        }

        return '';
    }

    /** TikTok / ByteDance CDN hosts (browser-only, not server-proxied). */
    private static function isTikTokCdnHost($host)
    {
        $host = strtolower(trim((string) $host));
        if ($host === '') {
            return false;
        }

        if (strpos($host, 'tiktok') !== false) {
            return true;
        }

        foreach (array(
            'ibyteimg.com',
            'byteoversea.com',
            'bytefcdn-oversea.com',
            'bytegecko.com',
            'bytefcdn-ttpeu.com',
            'bytetcdn.com',
            'worldfcdn.com',
            'byteimg.com',
        ) as $suffix) {
            if ($host === $suffix || substr($host, -strlen('.' . $suffix)) === '.' . $suffix) {
                return true;
            }
        }

        return false;
    }

    /** CDN host suffixes routed through the API image proxy. */
    private static function imageProxyHostSuffixes()
    {
        return array(
            'cdninstagram.com',
            'fbcdn.net',
            'fbsbx.com',
            'twimg.com',
            'ytimg.com',
            'ggpht.com',
            'googleusercontent.com',
            'licdn.com',
            'media.licdn.com',
            'pinimg.com',
            'telesco.pe',
            'telegram.org',
            'telegram-cdn.org',
            'cdn-telegram.org',
            'tiktokcdn.com',
            'tiktokcdn-eu.com',
            'tiktokcdn-us.com',
            'tiktokcdn-eu.net',
            'tiktokv.com',
            'tiktokrow-cdn.com',
            'ibyteimg.com',
            'byteoversea.com',
            'bytefcdn-oversea.com',
            'bytegecko.com',
            'bytefcdn-ttpeu.com',
            'bytetcdn.com',
            'worldfcdn.com',
            'byteimg.com',
        );
    }

    /** Whether an image URL host should be fetched via /proxy-image. */
    private static function imageProxyHostAllowed($host)
    {
        $host = strtolower(trim((string) $host));
        if ($host === '') {
            return false;
        }

        foreach (self::imageProxyHostSuffixes() as $suffix) {
            if ($host === $suffix || substr($host, -strlen('.' . $suffix)) === '.' . $suffix) {
                return true;
            }
        }

        if (strpos($host, 'tiktok') !== false
            && (strpos($host, 'akamaized.net') !== false || strpos($host, 'akadns.net') !== false)) {
            return true;
        }

        return false;
    }

    /** Reject page/profile HTML links masquerading as image URLs. */
    private static function isUsableAvatarUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return false;
        }

        if (strpos($url, 'proxy-image') !== false || strpos($url, 'cached-image') !== false) {
            return true;
        }

        if (!preg_match('#^https?://#i', $url)) {
            return false;
        }

        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ($host === '') {
            return false;
        }

        foreach (array('telesco.pe', 'telegram.org', 'telegram-cdn.org', 'cdn-telegram.org') as $suffix) {
            if ($host === $suffix || substr($host, -strlen('.' . $suffix)) === '.' . $suffix) {
                return true;
            }
        }

        return self::imageProxyHostAllowed($host);
    }

    /** Author avatar image or platform icon placeholder. */
    private static function renderCardAvatar($avatarUrl, array $meta)
    {
        $avatarUrl = trim((string) $avatarUrl);
        if ($avatarUrl !== '') {
            return self::lazyImg($avatarUrl, 'jssocial_card_avatar', 'jssocial_imgwrap--round jssocial_imgwrap--avatar-sm');
        }

        $icon   = !empty($meta['icon']) ? (string) $meta['icon'] : 'fa-link';
        $accent = !empty($meta['accent']) ? (string) $meta['accent'] : '#6366f1';

        return '<span class="jssocial_card_avatar jssocial_card_avatar--ph" style="--jssocial-accent: '
            . htmlspecialchars($accent, ENT_QUOTES) . ';" aria-hidden="true"><i class="fab '
            . htmlspecialchars($icon, ENT_QUOTES) . '"></i></span>';
    }

    /** Lazy-loaded image with shimmer placeholder. */
    private static function lazyImg($src, $class = '', $wrapClass = '', $extra = '')
    {
        $src = trim((string) $src);
        if ($src === '') {
            return '';
        }

        $imgHost = strtolower((string) parse_url($src, PHP_URL_HOST));
        $isDirectCdn = self::isTikTokCdnHost($imgHost)
            || stripos($imgHost, 'fbcdn.net') !== false
            || stripos($imgHost, 'fbsbx.com') !== false
            || stripos($imgHost, 'cdninstagram.com') !== false;
        $isProxiedCdn = stripos($src, 'proxy-image') !== false && (
            stripos($src, 'tiktokcdn') !== false
            || stripos($src, 'ibyteimg.com') !== false
            || stripos($src, 'fbcdn.net') !== false
            || stripos($src, 'fbsbx.com') !== false
            || stripos($src, 'cdninstagram.com') !== false
            || stripos($src, 'api.apify.com') !== false
        );
        if (($isDirectCdn || $isProxiedCdn) && stripos($extra, 'referrerpolicy=') === false) {
            $extra = trim($extra . ' referrerpolicy="no-referrer"');
        }

        $imgClass = $class !== '' ? ' class="' . htmlspecialchars($class, ENT_QUOTES) . '"' : '';
        $wrapExtra = $wrapClass !== '' ? ' ' . htmlspecialchars($wrapClass, ENT_QUOTES) : '';

        ob_start();
        ?>
        <span class="jssocial_imgwrap<?php echo $wrapExtra; ?>">
            <span class="jssocial_imgloader" aria-hidden="true"></span>
            <img src="<?php echo htmlspecialchars($src, ENT_QUOTES); ?>" alt="" loading="lazy"<?php echo $imgClass; ?><?php echo $extra !== '' ? ' ' . $extra : ''; ?> />
        </span>
        <?php
        return ob_get_clean();
    }

    /** Share trigger + popup menu (Copy Link, Facebook, WhatsApp, etc.). */
    private static function renderSharePopup($url, $title = '')
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }

        $encoded = rawurlencode($url);
        $title   = trim((string) $title);
        $text    = $title !== '' ? rawurlencode($title . ' ' . $url) : $encoded;
        $subject = $title !== '' ? rawurlencode($title) : rawurlencode('Check this out');

        ob_start();
        ?>
        <span class="jssocial_share_wrap">
            <button type="button" class="jssocial_share" aria-expanded="false" aria-haspopup="true" data-url="<?php echo htmlspecialchars($url, ENT_QUOTES); ?>">
                <?php echo self::icon('share'); ?> Share
            </button>
            <div class="jssocial_share_menu" role="menu" hidden>
                <button type="button" class="jssocial_share_item jssocial_share_item--copy" role="menuitem" data-url="<?php echo htmlspecialchars($url, ENT_QUOTES); ?>">
                    <span class="jssocial_share_item_label">Copy Link</span>
                    <i class="fas fa-link" aria-hidden="true"></i>
                </button>
                <div class="jssocial_share_divider" role="separator"></div>
                <a class="jssocial_share_item" role="menuitem" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $encoded; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on Facebook</span>
                    <i class="fab fa-facebook-f" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://wa.me/?text=<?php echo $text; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on WhatsApp</span>
                    <i class="fab fa-whatsapp" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://t.me/share/url?url=<?php echo $encoded; ?><?php echo $title !== '' ? '&text=' . rawurlencode($title) : ''; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on Telegram</span>
                    <i class="fab fa-telegram" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="mailto:?subject=<?php echo $subject; ?>&amp;body=<?php echo $text; ?>">
                    <span class="jssocial_share_item_label">Share via Email</span>
                    <i class="fas fa-envelope" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://twitter.com/intent/tweet?url=<?php echo $encoded; ?><?php echo $title !== '' ? '&text=' . rawurlencode($title) : ''; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on X</span>
                    <i class="fab fa-x-twitter" aria-hidden="true"></i>
                </a>
                <a class="jssocial_share_item" role="menuitem" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $encoded; ?>" target="_blank" rel="noopener noreferrer">
                    <span class="jssocial_share_item_label">Share on LinkedIn</span>
                    <i class="fab fa-linkedin-in" aria-hidden="true"></i>
                </a>
            </div>
        </span>
        <?php
        return ob_get_clean();
    }

    private static function renderYouTubeList(array $posts, array $ctx)
    {
        ob_start();
        ?>
        <div class="jssocial_posts">
            <?php foreach ($posts as $post) : ?>
                <?php
                    $purl        = isset($post['url']) && $post['url'] !== '' ? $post['url'] : $ctx['profileUrl'];
                    $title       = isset($post['caption']) ? trim((string) $post['caption']) : '';
                    $description = isset($post['description']) ? trim((string) $post['description']) : '';
                    $videoId     = isset($post['id']) ? trim((string) $post['id']) : '';
                    $image       = self::youtubeThumbnail($ctx['apiUrl'], isset($post['image']) ? (string) $post['image'] : '', $videoId);
                    $created     = isset($post['created_at']) ? (string) $post['created_at'] : '';
                    $ytTitle     = $title !== '' ? 'Watch on YouTube: ' . $title : 'Watch on YouTube';
                ?>
                <article class="jssocial_card jssocial_yt">
                    <?php if ($image !== '') : ?>
                        <a class="jssocial_yt_thumb" href="<?php echo htmlspecialchars($purl); ?>" target="_blank" rel="noopener">
                            <?php
                                $ytExtra = $videoId !== ''
                                    ? 'onerror="if(this.dataset.fbk)return;this.dataset.fbk=1;this.src=\'https://i.ytimg.com/vi/' . htmlspecialchars($videoId, ENT_QUOTES) . '/hqdefault.jpg\';"'
                                    : '';
                                echo self::lazyImg($image, '', '', $ytExtra);
                            ?>
                            <span class="jssocial_play"><?php echo self::icon('play'); ?></span>
                        </a>
                    <?php endif; ?>
                    <div class="jssocial_yt_info">
                        <?php if ($title !== '') : ?>
                            <a class="jssocial_yt_info_title" href="<?php echo htmlspecialchars($purl); ?>" title="<?php echo htmlspecialchars($ytTitle); ?>" target="_blank" rel="noopener"><?php echo htmlspecialchars($title); ?></a>
                        <?php endif; ?>
                        <?php if ($created !== '') : ?>
                            <div class="jssocial_yt_info_date"><?php echo htmlspecialchars(self::formatYouTubeDate($created)); ?></div>
                        <?php endif; ?>
                        <div class="jssocial_yt_info_caption"><?php
                            if ($description !== '' && $description !== $title) {
                                echo nl2br(htmlspecialchars(mb_strlen($description) > 220 ? mb_substr($description, 0, 220) . '…' : $description));
                            }
                        ?></div>
                        <?php echo self::renderPostActions($post, $ctx, $purl); ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Resolve a high-res YouTube thumbnail URL for display. */
    private static function youtubeThumbnail($apiUrl, $image, $videoId)
    {
        $image = trim((string) $image);
        if ($image === '' && $videoId !== '') {
            $image = 'https://i.ytimg.com/vi/' . $videoId . '/maxresdefault.jpg';
        } elseif ($image !== '' && preg_match('#(?:i\.)?ytimg\.com/vi/([a-zA-Z0-9_-]{11})/#', $image, $m)) {
            $image = 'https://i.ytimg.com/vi/' . $m[1] . '/maxresdefault.jpg';
        }

        return self::proxied($apiUrl, $image);
    }

    /** Read a numeric YouTube stat from normalized (or legacy) post fields. */
    private static function ytCount(array $post, array $keys)
    {
        foreach ($keys as $key) {
            if (!isset($post[$key]) || $post[$key] === '' || $post[$key] === null || is_array($post[$key])) {
                continue;
            }
            if (is_int($post[$key]) || is_float($post[$key])) {
                return (int) $post[$key];
            }
            $raw = trim((string) $post[$key]);
            if ($raw === '') {
                continue;
            }
            if (is_numeric(str_replace(',', '', $raw))) {
                return (int) str_replace(',', '', $raw);
            }
            if (preg_match('/^([\d,.]+)\s*([KMB])?/i', $raw, $m)) {
                $n = (float) str_replace(',', '', $m[1]);
                switch (strtoupper($m[2] ?? '')) {
                    case 'K':
                        return (int) round($n * 1000);
                    case 'M':
                        return (int) round($n * 1000000);
                    case 'B':
                        return (int) round($n * 1000000000);
                    default:
                        return (int) round($n);
                }
            }
        }

        return 0;
    }

    private static function formatYouTubeDate($raw)
    {
        $raw = trim((string) $raw);
        if ($raw === '') {
            return '';
        }
        $timestamp = is_numeric($raw) ? (int) $raw : strtotime($raw);
        return $timestamp ? date('j.n.Y', $timestamp) : $raw;
    }

    /** Tab/button accent colours — sourced from platforms(). */
    public static function platformTabColor($platform)
    {
        $cfg = self::getPlatform($platform);

        return $cfg !== null ? $cfg['accent'] : '#5e9ca0';
    }

    private static function platformMeta($platform)
    {
        if ($platform === 'testimonials') {
            return array('icon' => 'fa-quote-left', 'accent' => '#F59E0B', 'button' => 'Reviews');
        }

        $cfg = self::getPlatform($platform);
        if ($cfg === null) {
            return array('icon' => 'fa-link', 'accent' => '#5e9ca0', 'button' => 'Follow');
        }

        return array(
            'icon'   => $cfg['feed_icon'],
            'accent' => $cfg['accent'],
            'button' => $cfg['cta'],
        );
    }

    public static function formatDate($raw)
    {
        $raw = (string) $raw;
        if ($raw === '') {
            return '';
        }
        $timestamp = is_numeric($raw) ? (int) $raw : strtotime($raw);
        return $timestamp ? date('M j, Y', $timestamp) : '';
    }

    /** Profile cover from API; Instagram/LinkedIn may lack a native banner so use a post image fallback. */
    private static function resolveCover($apiUrl, $platform, array $profile, array $posts)
    {
        $cover = self::proxied($apiUrl, isset($profile['cover']) ? (string) $profile['cover'] : '');
        if ($cover !== '') {
            return $cover;
        }

        if (($platform === 'instagram' || $platform === 'linkedin' || $platform === 'tiktok' || $platform === 'pinterest' || $platform === 'telegram') && !empty($posts)) {
            $best     = '';
            $bestScore = 0;
            foreach ($posts as $post) {
                $img = isset($post['image']) ? trim((string) $post['image']) : '';
                if ($img === '') {
                    continue;
                }

                if ($platform === 'linkedin') {
                    $score = self::linkedInCoverImageScore($img);
                    if ($score > $bestScore) {
                        $bestScore = $score;
                        $best      = $img;
                    }
                    continue;
                }

                return self::proxied($apiUrl, $img);
            }

            if ($platform === 'linkedin' && $best !== '') {
                return self::proxied($apiUrl, $best);
            }
        }

        return '';
    }

    /** Prefer wide, high-resolution LinkedIn post images as cover fallbacks. */
    private static function linkedInCoverImageScore($url)
    {
        $url = (string) $url;
        if ($url === '') {
            return 0;
        }

        $score = 0;
        if (preg_match('~image-shrink_(\d+)_(\d+)~', $url, $m)) {
            $w = (int) $m[1];
            $h = (int) $m[2];
            $score = $w;
            if ($h > 0 && ($w / $h) >= 1.15) {
                $score += 500;
            }
        } elseif (preg_match('~image-shrink_(\d+)~', $url, $m)) {
            $score = (int) $m[1];
        }

        return $score;
    }

    /** Upscale avatar URLs when the CDN exposes size variants. */
    private static function normalizeAvatarUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return $url;
        }
        if (stripos($url, 'twimg.com') !== false) {
            $upgraded = preg_replace('#_(normal|bigger|mini)(\.)#', '_400x400$2', $url);
            return is_string($upgraded) && $upgraded !== '' ? $upgraded : $url;
        }
        if (stripos($url, 'googleusercontent.com') !== false) {
            $upgraded = preg_replace('#=s\d+(-c-k-c0x00ffffff-no-rj)?$#', '=s176-c-k-c0x00ffffff-no-rj', $url);
            if (!is_string($upgraded) || $upgraded === '') {
                $upgraded = preg_replace('#=s\d+#', '=s176', $url);
            }
            return is_string($upgraded) && $upgraded !== '' ? $upgraded : $url;
        }
        return $url;
    }

    /**
     * Route social-CDN image URLs through the API image proxy so the browser
     * never hotlinks Instagram/Facebook/X CDNs directly (they block hotlinking
     * and use short-lived signed URLs). Non-CDN URLs pass through untouched.
     *
     * TikTok CDN URLs go through proxy-image (302 redirect to CDN in the browser).
     * Meta and Telegram CDNs are fetched server-side via proxy-image (hotlink / CORP).
     * Apify KVS URLs are fetched server-side via proxy-image.
     */
    public static function proxied($apiUrl, $url)
    {
        $url    = (string) $url;
        $apiUrl = trim((string) $apiUrl);

        if ($url === '' || $apiUrl === '') {
            return $url;
        }

        if (strpos($url, 'proxy-image') !== false || strpos($url, 'cached-image') !== false) {
            return $url;
        }

        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if ($host === '') {
            return $url;
        }

        if (stripos($host, 'apifyusercontent.com') !== false) {
            return $url;
        }

        // TikTok CDN + Apify KVS → proxy-image (TikTok: 302 to CDN; Apify: server fetch with token).
        if (self::isTikTokCdnHost($host)
            || stripos($url, 'api.apify.com/v2/key-value-stores') !== false) {
            return rtrim($apiUrl, '/') . '/proxy-image?url=' . rawurlencode($url);
        }

        if (self::imageProxyHostAllowed($host)) {
            return rtrim($apiUrl, '/') . '/proxy-image?url=' . rawurlencode($url);
        }

        return $url;
    }

    /** Short profile bio/tagline for the feed header; skips duplicates of the name/handle. */
    private static function formatProfileBio($bio, $name, $handle)
    {
        $bio = trim((string) $bio);
        if ($bio === '') {
            return '';
        }

        $name   = trim((string) $name);
        $handle = trim((string) $handle);
        if ($name !== '' && strcasecmp($bio, $name) === 0) {
            return '';
        }
        if ($handle !== '' && strcasecmp($bio, $handle) === 0) {
            return '';
        }
        if ($handle !== '' && strcasecmp($bio, '@' . ltrim($handle, '@')) === 0) {
            return '';
        }

        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($bio) > 120) {
                return rtrim(mb_substr($bio, 0, 117)) . '...';
            }
            return $bio;
        }

        if (strlen($bio) > 120) {
            return rtrim(substr($bio, 0, 117)) . '...';
        }

        return $bio;
    }

    /** Whether a Facebook handle should be hidden (profile.php, numeric page id, etc.). */
    private static function isInvalidFacebookHandle($handle)
    {
        $handle = trim((string) $handle);
        if ($handle === '') {
            return true;
        }

        // profile.php?id= pages resolve to a numeric id — not a public handle.
        if (ctype_digit($handle)) {
            return true;
        }

        $handle = strtolower($handle);

        static $bad = array(
            'profile.php', 'pages.php', 'login.php', 'watch.php', 'photo.php',
            'story.php', 'share.php', 'groups.php', 'reel.php', 'reels.php',
            'events.php', 'marketplace.php', 'gaming.php', 'l.php',
        );

        return in_array($handle, $bad, true);
    }

    /** Best display label for Facebook when the configured value is a numeric page id. */
    private static function resolveFacebookDisplayName(array $profile, array $posts = array())
    {
        $candidates = array(
            isset($profile['display_name']) ? trim((string) $profile['display_name']) : '',
        );

        foreach ($posts as $post) {
            if (!empty($post['author_name'])) {
                $candidates[] = trim((string) $post['author_name']);
            }
        }

        foreach ($candidates as $candidate) {
            if ($candidate !== '' && !self::isInvalidFacebookHandle($candidate)) {
                return $candidate;
            }
        }

        return 'Facebook';
    }

    /** Extract a public page slug from a facebook.com URL. */
    private static function facebookSlugFromUrl($url)
    {
        $url = trim((string) $url);
        if ($url === '') {
            return '';
        }

        $path = trim((string) parse_url($url, PHP_URL_PATH), '/');
        if ($path === '') {
            return '';
        }

        $segments = explode('/', $path);
        if (count($segments) >= 2 && in_array(strtolower($segments[0]), array('pages', 'people', 'pg'), true)) {
            $slug = $segments[1];
        } else {
            $slug = $segments[0];
        }

        $slug = trim((string) $slug);
        if ($slug === '' || self::isInvalidFacebookHandle($slug)) {
            return '';
        }

        return $slug;
    }

    /** Label shown on post cards (display name preferred for Facebook). */
    private static function postCardLabel($platform, $displayName, $handle)
    {
        $displayName = trim((string) $displayName);
        if ($platform === 'facebook') {
            if ($displayName !== '') {
                return $displayName;
            }
            if (!self::isInvalidFacebookHandle($handle)) {
                return (string) $handle;
            }

            return 'Facebook';
        }

        if ($displayName !== '') {
            return $displayName;
        }

        return self::formatHandle($platform, $handle);
    }

    /** @return string  @handle for YouTube/X/Instagram; plain for Facebook. */
    private static function formatHandle($platform, $handle)
    {
        $handle = trim((string) $handle);
        if ($handle === '') {
            return '';
        }
        if ($platform === 'youtube' || $platform === 'twitter' || $platform === 'x' || $platform === 'instagram' || $platform === 'tiktok' || $platform === 'telegram') {
            return '@' . ltrim($handle, '@');
        }

        return $handle;
    }

    /** Whether a normalized profile object is verified. */
    private static function isProfileVerified(array $profile)
    {
        if (!empty($profile['verified'])) {
            return true;
        }

        foreach (array('isVerified', 'is_verified', 'isBlueVerified', 'pageVerified', 'isChannelVerified', 'channelVerified') as $key) {
            if (!empty($profile[$key])) {
                return true;
            }
        }

        return false;
    }

    /** Verified badge markup beside the display name, or empty when not verified. */
    private static function verifiedBadge($verified, $platform = '')
    {
        if (empty($verified)) {
            return '';
        }

        $class = 'jssocial_verified';
        $slug  = preg_replace('/[^a-z0-9_-]/', '', (string) $platform);
        if ($slug !== '') {
            $class .= ' jssocial_verified--' . $slug;
        }

        return '<span class="' . $class . '" title="Verified" aria-label="Verified"><i class="fas fa-circle-check" aria-hidden="true"></i></span>';
    }

    /**
     * Inline SVG icons for post actions. These are embedded directly so the
     * like/comment/share glyphs always render, even when the site template
     * ships an old or partial FontAwesome build.
     */
    public static function icon($name)
    {
        $paths = array(
            'heart'   => '<path fill-rule="evenodd" d="M11.36 1.407A4.267 4.267 0 0 0 8.583 2.65l-.282.282-.283-.282a4.268 4.268 0 0 0-6.035 6.035l5.894 5.894a.6.6 0 0 0 .848 0l5.893-5.894A4.267 4.267 0 0 0 11.601 1.4l-.242.007ZM11.6 2.6a3.067 3.067 0 0 1 3.069 3.068l-.007.202a3.067 3.067 0 0 1-.892 1.967l-5.469 5.469-5.47-5.469A3.068 3.068 0 0 1 7.17 3.499l.707.706a.6.6 0 0 0 .848 0l.707-.706A3.067 3.067 0 0 1 11.6 2.6Z"/>',
            'save'    => '<path fill-rule="evenodd" d="M3.2 1.3a.6.6 0 0 0-.6.6v10.2l4.4-2.64 4.4 2.64V1.9a.6.6 0 0 0-.6-.6H3.2Zm1.2 1.2h5.2v7.28L8 7.22 4.4 9.78V2.5Z"/>',
            'like'    => '<path fill-rule="evenodd" d="M7.5 1.3a3.2 3.2 0 0 0-3.15 2.57l-.02.13-.45 2.38a.6.6 0 0 1-.59.49H1.8a1.2 1.2 0 0 0-1.2 1.2v3.6A1.2 1.2 0 0 0 1.8 12.7h5.34a1.8 1.8 0 0 0 1.74-1.34l.98-3.43.36-1.8a3.2 3.2 0 0 0-3.12-3.83Zm-.02 1.2a2 2 0 0 1 1.95 2.39l-.36 1.8-.98 3.43a.6.6 0 0 1-.58.45H1.8a.6.6 0 0 1-.6-.6V7.79a.6.6 0 0 1 .6-.6h1.49a1.8 1.8 0 0 0 1.77-1.47l.45-2.38A2 2 0 0 1 7.48 2.5ZM12.2 7.79v3.6a.6.6 0 0 1-.6.6h-1.8V7.19h1.8a.6.6 0 0 1 .6.6Z"/>',
            'comment' => '<path fill-rule="evenodd" d="M8.389.7h-.422a7.176 7.176 0 0 0-3.229.759A7.262 7.262 0 0 0 .7 7.965l.008.34c.04.908.254 1.8.627 2.628l.039.08-.66 3.419-.013.097c-.024.416.313.765.701.691l3.512-.667-.176-.082a7.264 7.264 0 0 0 9.714-3.233 7.172 7.172 0 0 0 .782-3.275v-.387C15.026 3.833 12.068.902 8.389.701Zm-.423 1.32h.378-.015c3.091.17 5.539 2.593 5.706 5.597l-.001.348a5.751 5.751 0 0 1-.63 2.63c-1.02 2.024-3.125 3.313-5.437 3.314a6.07 6.07 0 0 1-2.732-.64l-.084-.034a.547.547 0 0 0-.266-.016l-2.814.534.522-2.698a.719.719 0 0 0-.063-.46 5.75 5.75 0 0 1-.63-2.628c.001-2.236 1.284-4.29 3.333-5.305a6.072 6.072 0 0 1 2.733-.641Z"/>',
            'retweet' => '<path fill-rule="evenodd" d="M4.5 2.5 1.8 5.2l.7.7L4 4.4V10a2 2 0 0 0 2 2h4v-1.3H6a.7.7 0 0 1-.7-.7V4.4l1.5 1.5.7-.7L4.5 2.5Zm7 11 2.7-2.7-.7-.7L12 11.6V6a2 2 0 0 0-2-2H6v1.3h4a.7.7 0 0 1 .7.7v5.6L9.2 10.1l-.7.7 2.7 2.7Z"/>',
            'share'   => '<path fill-rule="evenodd" d="M11.5 1a2.5 2.5 0 0 0-2.46 2.99L5.7 5.86a2.5 2.5 0 1 0 0 4.28l3.34 1.87a2.5 2.5 0 1 0 .64-1.14L6.34 9a2.5 2.5 0 0 0 0-2L9.68 5.13A2.5 2.5 0 1 0 11.5 1Z"/>',
            'views'   => '<path fill-rule="evenodd" d="M8 3.75C4.9 3.75 2.2 6.1 1 8c1.2 1.9 3.9 4.25 7 4.25s5.8-2.35 7-4.25c-1.2-1.9-3.9-4.25-7-4.25zm0 1.5c2.35 0 4.35 1.55 5.25 2.75-.9 1.2-2.9 2.75-5.25 2.75S3.65 9.2 2.75 8 4.65 5.25 8 5.25zm0 1.75a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z"/>',
            'play'    => '<path d="M4.5 3v10l8-5-8-5Z"/>',
            'verified' => '<path fill-rule="evenodd" d="M8 1 6.2 2.3l-2.2-.2-.9 2L1.2 5.3l.6 2.1-.6 2.1 1.9 1.2.9 2 2.2-.2L8 15l1.8-1.5 2.2.2.9-2 1.9-1.2-.6-2.1.6-2.1-1.9-1.2-.9-2-2.2.2L8 1Zm-.7 9.2L4.9 7.8l.9-.9 1.5 1.5 3-3 .9.9-3.9 3.9Z"/>',
        );

        if (!isset($paths[$name])) {
            return '';
        }

        return '<svg class="jssocial_ico" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true">' . $paths[$name] . '</svg>';
    }

    public static function formatCount($n)
    {
        $n = (int) $n;
        if ($n >= 1000000000) {
            return rtrim(rtrim(number_format($n / 1000000000, 1), '0'), '.') . 'B';
        }
        if ($n >= 1000000) {
            return rtrim(rtrim(number_format($n / 1000000, 1), '0'), '.') . 'M';
        }
        if ($n >= 1000) {
            return rtrim(rtrim(number_format($n / 1000, 1), '0'), '.') . 'K';
        }
        return (string) $n;
    }
}
