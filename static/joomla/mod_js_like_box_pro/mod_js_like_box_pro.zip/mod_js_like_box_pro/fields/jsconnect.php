<?php

/**
 * Admin Connect — fills and stores the module API key.
 *
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

defined('_JEXEC') or die;

require_once dirname(__DIR__) . '/joomla-compat.php';

if (!class_exists('JFormFieldJsconnect', false)) {
    if (class_exists('Joomla\\CMS\\Form\\FormField')) {
        class JFormFieldJsconnect extends Joomla\CMS\Form\FormField
        {
            protected $type = 'Jsconnect';

            protected function getLabel()
            {
                return '';
            }

            protected function getInput()
            {
                return JsLikeBoxConnectField::render($this->form);
            }
        }
    } else {
        jimport('joomla.form.formfield');

        class JFormFieldJsconnect extends JFormField
        {
            protected $type = 'Jsconnect';

            protected function getLabel()
            {
                return '';
            }

            protected function getInput()
            {
                return JsLikeBoxConnectField::render($this->form);
            }
        }
    }
}

class JsLikeBoxConnectField
{
    const CONNECT_URL = 'https://jsns.eu/index.php';
    const DASHBOARD_URL = 'https://jsns.eu/user/api-keys';
    const SESSION_STATE = 'jlb_connect_state';
    const SESSION_RESULT = 'jlb_connect_result';
    const SESSION_PENDING = 'jlb_pending_api_key';

    /** @var string */
    private static $resolvedKey = '';

    /** @var array{html:string,api_key:string}|null */
    private static $requestResult = null;

    /** @var string|null */
    private static $buttonState = null;

    /** @var string DOM id of the visible API key input (set when rendering). */
    private static $apiKeyInputId = 'jform_params_api_key';

    /** @var string Key the fill script was already emitted for, so it is injected once. */
    private static $fillKeyScriptKey = '';

    private static function connectCode($app)
    {
        $code = preg_replace('/[^a-fA-F0-9]/', '', (string) $app->input->getString('jlb_code', ''));
        if ($code === '' && !empty($_GET['jlb_code'])) {
            $code = preg_replace('/[^a-fA-F0-9]/', '', (string) $_GET['jlb_code']);
        }

        return $code;
    }

    /** @param object $app */
    public static function connectCodePublic($app)
    {
        return self::connectCode($app);
    }

    private static function recoverKeyFromSession($session, $code)
    {
        $pending = self::pendingKey();
        if ($pending !== '') {
            return $pending;
        }

        $cached = $session->get(self::SESSION_RESULT, null);
        if (is_array($cached) && $code !== '' && isset($cached['code'])
            && hash_equals((string) $cached['code'], $code) && !empty($cached['api_key'])) {
            return (string) $cached['api_key'];
        }

        return self::keyFromModuleParams();
    }

    /** Read api_key straight from #__modules.params (set by a previous successful exchange). */
    private static function keyFromModuleParams()
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            $app = \Joomla\CMS\Factory::getApplication();
            $db = \Joomla\CMS\Factory::getDbo();
        } else {
            $app = JFactory::getApplication();
            $db = JFactory::getDbo();
        }

        $moduleId = self::moduleId($app);
        if ($moduleId <= 0) {
            return '';
        }

        try {
            $raw = $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('params'))
                    ->from($db->quoteName('#__modules'))
                    ->where($db->quoteName('id') . ' = ' . $moduleId)
            )->loadResult();
        } catch (Exception $e) {
            return '';
        }

        if (!is_string($raw) || $raw === '') {
            return '';
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            return trim((string) ($decoded['api_key'] ?? ''));
        }

        $registry = new \Joomla\Registry\Registry($raw);

        return trim((string) $registry->get('api_key', ''));
    }

    /** @var string */
    private static $lastExchangeError = '';

    /** @var array<int, string> One line per exchange attempt: endpoint, HTTP code, body snippet. */
    private static $diagnostics = array();

    public static function resolvedKey()
    {
        return self::$resolvedKey;
    }

    /** Key from Connect exchange or the saved form value. */
    public static function bestApiKey($form)
    {
        if (self::$resolvedKey !== '') {
            return self::$resolvedKey;
        }

        if (is_array(self::$requestResult) && !empty(self::$requestResult['api_key'])) {
            return (string) self::$requestResult['api_key'];
        }

        if (class_exists('Joomla\\CMS\\Factory')) {
            $app = \Joomla\CMS\Factory::getApplication();
        } else {
            $app = JFactory::getApplication();
        }

        // Returning from Connect: the freshly exchanged key wins over the stored one.
        if (self::connectCode($app) !== '') {
            if (class_exists('Joomla\\CMS\\Factory')) {
                $session = \Joomla\CMS\Factory::getSession();
            } else {
                $session = JFactory::getSession();
            }

            $cached = $session->get(self::SESSION_RESULT, null);
            if (is_array($cached) && !empty($cached['api_key'])) {
                return (string) $cached['api_key'];
            }
        }

        // A saved key always wins; the pending key only bridges the gap between
        // the exchange and the first Save.
        $formKey = self::formApiKey($form);
        if ($formKey !== '') {
            self::clearPendingKey();

            return $formKey;
        }

        return self::pendingKey();
    }

    private static function pendingKey()
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            $session = \Joomla\CMS\Factory::getSession();
        } else {
            $session = JFactory::getSession();
        }

        return trim((string) $session->get(self::SESSION_PENDING, ''));
    }

    private static function setPendingKey($apiKey)
    {
        $apiKey = trim((string) $apiKey);
        if ($apiKey === '') {
            return;
        }

        if (class_exists('Joomla\\CMS\\Factory')) {
            $session = \Joomla\CMS\Factory::getSession();
        } else {
            $session = JFactory::getSession();
        }

        $session->set(self::SESSION_PENDING, $apiKey);
    }

    private static function clearPendingKey()
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            $session = \Joomla\CMS\Factory::getSession();
        } else {
            $session = JFactory::getSession();
        }

        $session->clear(self::SESSION_PENDING);
    }

    /**
     * Exchange jlb_code once per request and put the key on the form.
     *
     * @param object|null $form
     */
    public static function captureKey($form)
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            $app = \Joomla\CMS\Factory::getApplication();
            $session = $app->getSession();
        } else {
            $app = JFactory::getApplication();
            $session = JFactory::getSession();
        }

        $code = self::connectCode($app);
        if ($code === '') {
            return;
        }

        $cached = $session->get(self::SESSION_RESULT, null);
        if (is_array($cached) && isset($cached['code']) && !hash_equals((string) $cached['code'], $code)) {
            self::$requestResult = null;
            self::$resolvedKey = '';
            self::$fillKeyScriptKey = '';
            $session->clear(self::SESSION_RESULT);
        }

        if (self::$requestResult !== null) {
            if (self::$resolvedKey === '') {
                $recovered = self::recoverKeyFromSession($session, $code);
                if ($recovered !== '') {
                    self::$requestResult = array('html' => '', 'api_key' => $recovered);
                }
            }
            self::applyResolvedKey($form);

            return;
        }

        $host = class_exists('Joomla\\CMS\\Uri\\Uri')
            ? \Joomla\CMS\Uri\Uri::getInstance()->getHost()
            : JUri::getInstance()->getHost();
        $state = preg_replace('/[^a-zA-Z0-9._\-]/', '', (string) $app->input->getString('jlb_state', ''));
        self::$requestResult = self::completeConnect(
            $session,
            $form,
            $code,
            $state,
            self::normalizeDomain($host),
            self::moduleId($app)
        );
        self::applyResolvedKey($form);
    }

    /** @param object|null $form */
    private static function applyResolvedKey($form)
    {
        if (is_array(self::$requestResult) && self::$requestResult['api_key'] !== '') {
            self::$resolvedKey = (string) self::$requestResult['api_key'];
        }

        if (self::$resolvedKey !== '') {
            self::setFormApiKey($form, self::$resolvedKey);
        }
    }

    /** @param object|null $form */
    public static function render($form)
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            $app = \Joomla\CMS\Factory::getApplication();
            $session = $app->getSession();
        } else {
            $app = JFactory::getApplication();
            $session = JFactory::getSession();
        }

        $host = class_exists('Joomla\\CMS\\Uri\\Uri')
            ? \Joomla\CMS\Uri\Uri::getInstance()->getHost()
            : JUri::getInstance()->getHost();
        $domain = self::normalizeDomain($host);

        self::captureKey($form);

        $html = '<div class="jslikebox-admin-connect" style="margin:0 0 12px;">';

        $code = self::connectCode($app);
        if ($code !== '' && is_array(self::$requestResult) && self::$requestResult['api_key'] === '') {
            $message = self::exchangeError(self::$lastExchangeError);
            if ($message === '') {
                $message = 'Connect did not return an API key. Paste it from the jsns.eu dashboard, or click Connect again.';
            }

            $html .= '<div class="alert alert-warning" style="margin:0 0 8px;">'
                . htmlspecialchars($message, ENT_QUOTES, 'UTF-8')
                . self::diagnosticsHtml()
                . '</div>';
        }

        if (!self::isConnectableDomain($domain)) {
            $html .= '<div class="alert alert-info" style="margin:0 0 8px;">'
                . 'Connect is not available on localhost or an IP. Paste a key from '
                . '<a href="' . htmlspecialchars(self::DASHBOARD_URL, ENT_QUOTES) . '" target="_blank" rel="noopener">jsns.eu</a>.'
                . '</div>';
        } else {
            $codeInUrl = self::connectCode($app);
            if ($codeInUrl === '' && self::$buttonState === null) {
                self::$buttonState = bin2hex(random_bytes(16));
                $session->set(self::SESSION_STATE, self::$buttonState);
            } elseif ($codeInUrl !== '' && self::$buttonState === null) {
                self::$buttonState = (string) $session->get(self::SESSION_STATE, '');
                if (self::$buttonState === '') {
                    self::$buttonState = bin2hex(random_bytes(16));
                    $session->set(self::SESSION_STATE, self::$buttonState);
                }
            }
            $href = self::CONNECT_URL . '?' . http_build_query(array_merge(
                array(
                    'option' => 'com_js_like_box',
                    'task'   => 'connect',
                    'domain' => $domain,
                ),
                self::returnParams(),
                array(
                    'state'    => self::$buttonState,
                    'platform' => 'joomla',
                )
            ));
            $hasKey = self::bestApiKey($form) !== '';
            $label = $hasKey ? 'Reconnect with jsns.eu' : 'Connect with jsns.eu';
            $html .= '<a class="btn btn-primary" href="'
                . htmlspecialchars($href, ENT_QUOTES) . '">' . htmlspecialchars($label) . '</a>';
        }

        $html .= '</div>';

        return $html;
    }

    /** Collapsed technical detail of each exchange attempt (helps diagnose WAF/route problems). */
    private static function diagnosticsHtml()
    {
        if (self::$diagnostics === array()) {
            return '';
        }

        $lines = '';
        foreach (self::$diagnostics as $line) {
            $lines .= '<div>' . htmlspecialchars($line, ENT_QUOTES, 'UTF-8') . '</div>';
        }

        return '<details style="margin-top:6px;"><summary>Connect details</summary>'
            . '<div style="font-family:monospace;font-size:11px;margin-top:4px;">' . $lines . '</div></details>';
    }

    public static function registerApiKeyField($inputId)
    {
        self::$apiKeyInputId = (string) $inputId;
    }

    public static function fillKeyScriptPublic($apiKey, $showNotice = true)
    {
        self::fillKeyScript($apiKey, $showNotice);
    }

    /** @param object $app */
    private static function moduleId($app)
    {
        $id = (int) $app->input->getInt('id', 0);
        if ($id > 0) {
            return $id;
        }

        $jform = $app->input->get('jform', array(), 'array');
        if (is_array($jform) && !empty($jform['id'])) {
            return (int) $jform['id'];
        }

        $cid = $app->input->get('cid', array(), 'array');
        if (is_array($cid) && !empty($cid[0])) {
            return (int) $cid[0];
        }

        return 0;
    }

    /** Put the key in the textbox and drop the connect code from the URL. */
    private static function fillKeyScript($apiKey, $showNotice = true)
    {
        $apiKey = trim((string) $apiKey);
        $token  = $apiKey . '|' . ($showNotice ? '1' : '0');
        if ($apiKey === '' || self::$fillKeyScriptKey === $token) {
            return;
        }
        self::$fillKeyScriptKey = $token;

        $js = '(function(){function go(){var el=document.getElementById(' . json_encode(self::$apiKeyInputId) . ');'
            . 'if(!el){return;}'
            . 'el.value=' . json_encode($apiKey) . ';'
            . ($showNotice
                ? 'if(!document.getElementById("jlb-save-notice")){'
                    . 'var n=document.createElement("div");n.id="jlb-save-notice";n.className="alert alert-success";'
                    . 'n.style.margin="8px 0";n.innerHTML="Click <strong>Save</strong> to store the API key.";'
                    . 'var row=el.closest?el.closest(".control-group,.form-group"):el.parentNode;'
                    . '(row&&row.parentNode)?row.parentNode.insertBefore(n,row.nextSibling):el.parentNode.appendChild(n);}'
                : '')
            . 'if(window.history&&window.history.replaceState){'
            . 'try{var u=new URL(window.location.href);u.searchParams.delete("jlb_code");u.searchParams.delete("jlb_state");'
            . 'window.history.replaceState({},"",u.toString());}catch(e){}}}'
            . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",go);}else{go();}'
            . '})();';

        if (class_exists('Joomla\\CMS\\Factory')) {
            \Joomla\CMS\Factory::getDocument()->addScriptDeclaration($js);
        } else {
            JFactory::getDocument()->addScriptDeclaration($js);
        }
    }

    /** @param object|null $form */
    private static function formApiKey($form)
    {
        if (is_object($form) && method_exists($form, 'getValue')) {
            return trim((string) $form->getValue('api_key', 'params'));
        }

        return '';
    }

    /**
     * @param object $session
     * @param object|null $form
     * @return array{html:string,api_key:string}
     */
    private static function withKey($form, $apiKey)
    {
        $apiKey = trim((string) $apiKey);
        $stored = self::formApiKey($form);

        self::setPendingKey($apiKey);
        self::setFormApiKey($form, $apiKey);
        self::fillKeyScript($apiKey, $apiKey !== $stored);

        return array('html' => '', 'api_key' => $apiKey);
    }

    /**
     * @param object $session
     * @param object|null $form
     * @return array{html:string,api_key:string}
     */
    private static function completeConnect($session, $form, $code, $state, $domain, $moduleId)
    {
        // The state proves this return belongs to the Connect click made in this
        // admin session, so a code issued for our domain by someone else is refused.
        $expected = trim((string) $session->get(self::SESSION_STATE, ''));
        if ($expected === '' || !hash_equals($expected, (string) $state)) {
            self::$lastExchangeError = 'state';

            return array('html' => '', 'api_key' => '');
        }

        $cached = $session->get(self::SESSION_RESULT, null);
        if (is_array($cached) && isset($cached['code']) && hash_equals((string) $cached['code'], $code)
            && !empty($cached['api_key'])) {
            return self::withKey($form, (string) $cached['api_key']);
        }

        $result = self::exchangeCode($code, $domain);
        self::$lastExchangeError = (string) ($result['error'] ?? '');
        if (!empty($result['ok'])) {
            $apiKey = trim((string) $result['api_key']);
            if ($apiKey !== '') {
                self::saveKeyToModule($moduleId, $apiKey);
                self::setPendingKey($apiKey);
                $session->set(self::SESSION_RESULT, array('code' => $code, 'api_key' => $apiKey));

                return self::withKey($form, $apiKey);
            }
        }

        $error = (string) ($result['error'] ?? '');
        if ($error === 'used' || $error === 'expired') {
            $recovered = self::recoverKeyFromSession($session, $code);
            if ($recovered !== '') {
                return self::withKey($form, $recovered);
            }

            return array('html' => '', 'api_key' => '');
        }

        if ($error !== '') {
            return array(
                'html'    => '<div class="alert alert-warning">' . htmlspecialchars(self::exchangeError($error)) . '</div>',
                'api_key' => '',
            );
        }

        return array('html' => '', 'api_key' => '');
    }

    /** @param object|null $form */
    private static function setFormApiKey($form, $apiKey)
    {
        if (is_object($form) && method_exists($form, 'setValue')) {
            $form->setValue('api_key', 'params', $apiKey);
        }
    }

    /** Persist api_key into #__modules.params (JSON or INI). */
    private static function saveKeyToModule($moduleId, $apiKey)
    {
        $moduleId = (int) $moduleId;
        $apiKey = trim((string) $apiKey);
        if ($moduleId <= 0 || $apiKey === '') {
            return false;
        }

        if (class_exists('Joomla\\CMS\\Factory')) {
            $user = \Joomla\CMS\Factory::getUser();
            $db = \Joomla\CMS\Factory::getDbo();
        } else {
            $user = JFactory::getUser();
            $db = JFactory::getDbo();
        }

        if ($user->guest || !$user->authorise('core.edit', 'com_modules')) {
            return false;
        }

        $raw = $db->setQuery(
            $db->getQuery(true)
                ->select($db->quoteName('params'))
                ->from($db->quoteName('#__modules'))
                ->where($db->quoteName('id') . ' = ' . $moduleId)
                ->where($db->quoteName('module') . ' = ' . $db->quote('mod_js_like_box_pro'))
        )->loadResult();

        if ($raw === null) {
            return false;
        }

        $decoded = json_decode((string) $raw, true);
        if (is_array($decoded)) {
            $decoded['api_key'] = $apiKey;
            $stored = json_encode($decoded);
        } else {
            $registry = new \Joomla\Registry\Registry($raw);
            $registry->set('api_key', $apiKey);
            $stored = $registry->toString();
        }

        $db->setQuery(
            $db->getQuery(true)
                ->update($db->quoteName('#__modules'))
                ->set($db->quoteName('params') . ' = ' . $db->quote($stored))
                ->where($db->quoteName('id') . ' = ' . $moduleId)
        )->execute();

        return true;
    }

    /** @return array{ok:bool,api_key:string,error:string} */
    private static function exchangeCode($code, $domain)
    {
        if (!function_exists('curl_init')) {
            return array('ok' => false, 'api_key' => '', 'error' => 'curl');
        }

        $rawUrl  = self::CONNECT_URL . '?option=com_js_like_box&task=exchangeConnect&format=raw';
        $jsonUrl = self::CONNECT_URL . '?option=com_js_like_box&task=api.exchangeCode&format=json';

        $attempts = array(
            array($rawUrl, 'form'),
            array($rawUrl, 'json'),
            array($jsonUrl, 'form'),
            array($jsonUrl, 'json'),
        );

        $last = 'request_failed';
        foreach ($attempts as $attempt) {
            $result = self::requestExchange($attempt[0], $attempt[1], $code, $domain);
            if (!empty($result['ok'])) {
                return $result;
            }

            $last = (string) $result['error'];
            // The code is single-use: once jsns.eu reports it consumed or wrong, retrying cannot help.
            if ($last === 'used' || $last === 'expired' || $last === 'domain_mismatch' || $last === 'blocked') {
                break;
            }
        }

        return array('ok' => false, 'api_key' => '', 'error' => $last);
    }

    /**
     * One exchange attempt. Records a diagnostic line so a failed Connect can be explained.
     *
     * @return array{ok:bool,api_key:string,error:string}
     */
    private static function requestExchange($url, $mode, $code, $domain)
    {
        $fields  = array('code' => $code, 'domain' => $domain);
        $headers = array('Accept: application/json', 'User-Agent: JSLikeBoxPro/4.1.0');

        if ($mode === 'json') {
            $body = json_encode($fields);
            $headers[] = 'Content-Type: application/json';
        } else {
            $body = http_build_query($fields);
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        }

        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_HTTPHEADER     => $headers,
        ));
        $response  = curl_exec($ch);
        $httpCode  = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        $task = strpos($url, 'api.exchangeCode') !== false ? 'api.exchangeCode' : 'exchangeConnect';
        $json = self::decodeJson($response);

        if (is_array($json) && !empty($json['success']) && !empty($json['api_key'])) {
            self::$diagnostics[] = $task . ' (' . $mode . '): HTTP ' . $httpCode . ' — key received';

            return array('ok' => true, 'api_key' => trim((string) $json['api_key']), 'error' => '');
        }

        $error = is_array($json) && !empty($json['error']) ? (string) $json['error'] : '';
        if ($error === '') {
            $error = $httpCode === 403 ? 'blocked' : 'request_failed';
        }

        $detail = $curlError !== '' ? $curlError : trim(strip_tags((string) $response));
        $detail = trim(preg_replace('/\s+/', ' ', $detail));
        self::$diagnostics[] = $task . ' (' . $mode . '): HTTP ' . $httpCode . ' — ' . $error
            . ($detail !== '' ? ' — ' . substr($detail, 0, 120) : '');

        return array('ok' => false, 'api_key' => '', 'error' => $error);
    }

    private static function decodeJson($response)
    {
        if (!is_string($response) || $response === '') {
            return null;
        }

        $json = json_decode($response, true);
        if (is_array($json)) {
            return $json;
        }

        if (preg_match('/\{[^{}]*"success"\s*:/', $response) && preg_match('/\{.*\}/s', $response, $m)) {
            $json = json_decode($m[0], true);
            if (is_array($json)) {
                return $json;
            }
        }

        return null;
    }

    private static function exchangeError($error)
    {
        switch ($error) {
            case 'expired':
            case 'used':
                return '';
            case 'state':
                return 'This Connect link did not start from this page. Click Connect again.';
            case 'domain_mismatch':
                return 'This key belongs to a different domain.';
            case 'curl':
                return 'PHP curl is required to Connect. Paste a key from the dashboard instead.';
            case 'blocked':
                return 'jsns.eu blocked the server request (403). Paste the key from the dashboard, or allow POST from your site IP.';
            case 'invalid':
                return 'Connect link invalid or already used. Click Connect again, then approve within 5 minutes.';
            case 'unauthorized':
                return 'jsns.eu needs com_js_like_box 1.1.16+. Update the component, then click Connect again.';
            default:
                return 'Could not fetch the API key. Paste it from jsns.eu or click Connect again.';
        }
    }

    /**
     * The return address travels as a path plus scheme instead of a whole URL,
     * because an absolute https:// value inside a query string trips firewall
     * rules that read it as a remote file inclusion attempt.
     *
     * @return array
     */
    private static function returnParams()
    {
        $uri = class_exists('Joomla\\CMS\\Uri\\Uri')
            ? clone \Joomla\CMS\Uri\Uri::getInstance()
            : clone JUri::getInstance();
        $uri->delVar('jlb_code');
        $uri->delVar('jlb_state');

        $path = $uri->toString(array('path', 'query', 'fragment'));

        if ($path === '' || strpos($path, '/') !== 0 || strpos($path, '//') === 0) {
            return array('return' => $uri->toString());
        }

        return array(
            'return_path'   => $path,
            'return_scheme' => strtolower((string) $uri->getScheme()) === 'http' ? 'http' : 'https',
        );
    }

    private static function isConnectableDomain($domain)
    {
        if ($domain === '' || strpos($domain, '.') === false) {
            return false;
        }
        if ($domain === 'localhost' || substr($domain, -6) === '.local' || substr($domain, -5) === '.test') {
            return false;
        }
        if (filter_var($domain, FILTER_VALIDATE_IP)) {
            return false;
        }

        return true;
    }

    private static function normalizeDomain($domain)
    {
        $domain = strtolower(trim((string) $domain));
        if ($domain === '') {
            return '';
        }
        if (strpos($domain, '://') !== false) {
            $host = parse_url($domain, PHP_URL_HOST);
            $domain = is_string($host) ? $host : $domain;
        }
        $domain = preg_replace('#/.*$#', '', $domain);
        $domain = preg_replace('#^www\.#', '', $domain);
        $domain = preg_replace('#[^a-z0-9.\-]#', '', $domain);

        return substr($domain, 0, 255);
    }
}

// Defer Connect exchange until the admin app is ready (file-load bootstrap was unreliable).
