<?php

/**
 * API key field — value comes from Connect exchange when returning from jsns.eu,
 * otherwise from the saved module params.
 *
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

defined('_JEXEC') or die;

require_once dirname(__DIR__) . '/joomla-compat.php';

if (!class_exists('JFormFieldApikey', false)) {
    if (class_exists('Joomla\\CMS\\Form\\FormField')) {
        class JFormFieldApikey extends Joomla\CMS\Form\FormField
        {
            protected $type = 'Apikey';

            protected function getInput()
            {
                return JsLikeBoxApiKeyField::renderInput(array(
                    'form'  => $this->form,
                    'name'  => $this->name,
                    'id'    => $this->id,
                    'value' => (string) $this->value,
                    'size'  => (int) $this->element['size'],
                    'class' => (string) $this->element['class'],
                ));
            }
        }
    } else {
        jimport('joomla.form.formfield');

        class JFormFieldApikey extends JFormField
        {
            protected $type = 'Apikey';

            protected function getInput()
            {
                return JsLikeBoxApiKeyField::renderInput(array(
                    'form'  => $this->form,
                    'name'  => $this->name,
                    'id'    => $this->id,
                    'value' => (string) $this->value,
                    'size'  => (int) $this->element['size'],
                    'class' => (string) $this->element['class'],
                ));
            }
        }
    }
}

class JsLikeBoxApiKeyField
{
    /**
     * @param array $field form, name, id, value, size and class, collected inside
     *                     the field class where the protected properties are readable.
     */
    public static function renderInput(array $field)
    {
        if (!class_exists('JsLikeBoxConnectField', false)) {
            require_once __DIR__ . '/jsconnect.php';
        }

        $form = isset($field['form']) ? $field['form'] : null;

        JsLikeBoxConnectField::captureKey($form);
        JsLikeBoxConnectField::registerApiKeyField($field['id']);

        // Value Joomla bound from the stored module params, before Connect had a say.
        $saved = trim((string) $field['value']);

        $value = JsLikeBoxConnectField::bestApiKey($form);
        if ($value === '') {
            $value = $saved;
        }

        $size  = $field['size'] > 0 ? (int) $field['size'] : 60;
        $class = $field['class'] !== '' ? (string) $field['class'] : 'form-control';

        // Only prompt for a Save while the shown key differs from the stored one.
        if ($value !== '' && $value !== $saved) {
            JsLikeBoxConnectField::fillKeyScriptPublic($value);
        }

        return '<input type="text" name="' . htmlspecialchars($field['name'], ENT_COMPAT, 'UTF-8')
            . '" id="' . htmlspecialchars($field['id'], ENT_COMPAT, 'UTF-8')
            . '" value="' . htmlspecialchars($value, ENT_COMPAT, 'UTF-8')
            . '" class="' . htmlspecialchars($class, ENT_COMPAT, 'UTF-8')
            . '" size="' . $size . '" autocomplete="off" spellcheck="false" />';
    }
}
