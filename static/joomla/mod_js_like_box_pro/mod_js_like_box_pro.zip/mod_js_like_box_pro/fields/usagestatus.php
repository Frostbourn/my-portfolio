<?php

/**
 * Lightweight admin usage field — does not load helper.php.
 *
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

defined('_JEXEC') or die;

require_once dirname(__DIR__) . '/joomla-compat.php';

if (!class_exists('JFormFieldUsagestatus', false)) {
    if (class_exists('Joomla\\CMS\\Form\\FormField')) {
        class JFormFieldUsagestatus extends Joomla\CMS\Form\FormField
        {
            protected $type = 'Usagestatus';

            protected function getLabel()
            {
                return '';
            }

            protected function getInput()
            {
                return JsLikeBoxUsageStatusField::render($this->form);
            }
        }
    } else {
        jimport('joomla.form.formfield');

        class JFormFieldUsagestatus extends JFormField
        {
            protected $type = 'Usagestatus';

            protected function getLabel()
            {
                return '';
            }

            protected function getInput()
            {
                return JsLikeBoxUsageStatusField::render($this->form);
            }
        }
    }
}

class JsLikeBoxUsageStatusField
{
    const API_BASE_URL = 'https://socialproof.pl/api';
    const DASHBOARD_URL = 'https://jsns.eu/user/api-keys';
    const UPGRADE_URL = 'https://jsns.eu/user/upgrade-plan';

    /** @var string|null */
    private static $html = null;

    /** @param object|null $form */
    public static function render($form)
    {
        if (self::$html !== null) {
            return self::$html;
        }

        self::ensureStyles();

        try {
            if (!class_exists('JsLikeBoxConnectField', false)) {
                require_once __DIR__ . '/jsconnect.php';
            }
            JsLikeBoxConnectField::captureKey($form);

            if (class_exists('Joomla\\CMS\\Factory')) {
                $app = \Joomla\CMS\Factory::getApplication();
            } else {
                $app = JFactory::getApplication();
            }

            $connectReturn = class_exists('JsLikeBoxConnectField', false)
                && JsLikeBoxConnectField::connectCodePublic($app) !== '';
            $apiKey = JsLikeBoxConnectField::bestApiKey($form);

            if ($apiKey === '') {
                self::$html = '<div class="alert alert-info jslikebox-admin-usage-notice">Enter your API key above and save to see monthly usage.</div>';

                return self::$html;
            }

            if (class_exists('Joomla\\CMS\\Uri\\Uri')) {
                $domain = \Joomla\CMS\Uri\Uri::getInstance()->getHost();
            } else {
                $domain = JUri::getInstance()->getHost();
            }
            $domain = self::normalizeDomain($domain);

            $moduleId = (int) $app->input->getInt('id', 0);
            $widgetId = $moduleId > 0
                ? substr(hash('sha256', $domain . '|' . $moduleId), 0, 24)
                : 'admin_preview';

            $status = self::fetchStatus($apiKey, $widgetId, $domain);
            if ($connectReturn && empty($status['ok']) && (int) $status['http_code'] === 401) {
                self::$html = '<div class="alert alert-success jslikebox-admin-usage-notice">'
                    . 'The API key is ready. Click <strong>Save</strong> at the top — usage will refresh after saving.'
                    . '</div>';

                return self::$html;
            }

            self::$html = self::renderHtml($status);

            return self::$html;
        } catch (Exception $e) {
            self::$html = '<div class="alert alert-warning jslikebox-admin-usage-notice">Usage status unavailable.</div>';

            return self::$html;
        } catch (Throwable $e) {
            self::$html = '<div class="alert alert-warning jslikebox-admin-usage-notice">Usage status unavailable.</div>';

            return self::$html;
        }
    }

    private static function ensureStyles()
    {
        static $loaded = false;
        if ($loaded) {
            return;
        }
        $loaded = true;

        $cssPath = dirname(__DIR__) . '/tmpl/css/admin-usage.css';
        if (!is_file($cssPath)) {
            return;
        }

        $cssUrl = '/modules/mod_js_like_box_pro/tmpl/css/admin-usage.css';
        if (class_exists('Joomla\\CMS\\Uri\\Uri')) {
            $cssUrl = \Joomla\CMS\Uri\Uri::root(true) . $cssUrl;
        } elseif (class_exists('JUri')) {
            $cssUrl = JUri::root(true) . $cssUrl;
        }

        $cssVer = (string) filemtime($cssPath);

        if (class_exists('Joomla\\CMS\\Factory')) {
            $doc = \Joomla\CMS\Factory::getDocument();
            if (method_exists($doc, 'addStyleSheet')) {
                if (class_exists('Joomla\\CMS\\Version') && version_compare(\Joomla\CMS\Version::MAJOR_VERSION, '4', '>=')) {
                    $doc->addStyleSheet($cssUrl, array('version' => $cssVer));
                } else {
                    $doc->addStyleSheet($cssUrl . '?v=' . rawurlencode($cssVer), 'text/css');
                }
            }
            return;
        }

        $doc = JFactory::getDocument();
        $doc->addStyleSheet($cssUrl . '?v=' . rawurlencode($cssVer), 'text/css');
    }

    /** @return array<string, mixed> */
    private static function fetchStatus($apiKey, $widgetId, $domain = '')
    {
        $empty = array(
            'ok'             => false,
            'meta'           => null,
            'plan'           => null,
            'user_id'        => 0,
            'http_code'      => 0,
            'error'          => null,
            'message'        => null,
            'pinned_domains' => array(),
        );

        if (!function_exists('curl_init')) {
            $empty['error'] = 'curl extension unavailable';

            return $empty;
        }

        $endpoint = rtrim(self::API_BASE_URL, '/') . '/status?' . http_build_query(array(
            'widget_id' => $widgetId,
            'domain'    => self::normalizeDomain($domain),
        ));

        $headers = array(
            'X-API-Key: ' . $apiKey,
            'User-Agent: JSLikeBoxPro/4.1.0',
        );
        if ($domain !== '') {
            $headers[] = 'X-Site-Domain: ' . self::normalizeDomain($domain);
        }

        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_HTTPHEADER     => $headers,
        ));

        $response = curl_exec($ch);
        $code     = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        $empty['http_code'] = $code;

        if ($response === false) {
            $empty['error'] = $curlErr !== '' ? $curlErr : 'request failed';

            return $empty;
        }

        $json = json_decode($response, true);
        if ($code === 200 && is_array($json) && !empty($json['success']) && isset($json['meta']) && is_array($json['meta'])) {
            return array(
                'ok'        => true,
                'meta'      => $json['meta'],
                'plan'      => isset($json['plan']) ? (string) $json['plan'] : null,
                'user_id'   => isset($json['user_id']) ? (int) $json['user_id'] : 0,
                'http_code' => 200,
                'error'     => null,
                'message'   => null,
            );
        }

        if (is_array($json)) {
            if (!empty($json['error'])) {
                $empty['message'] = (string) $json['error'];
            } elseif (!empty($json['message'])) {
                $empty['message'] = (string) $json['message'];
            }
            if (!empty($json['pinned_domains']) && is_array($json['pinned_domains'])) {
                $empty['pinned_domains'] = array_values(array_filter(array_map('strval', $json['pinned_domains'])));
            } elseif (!empty($json['domain'])) {
                $empty['pinned_domains'] = array((string) $json['domain']);
            }
        }

        return $empty;
    }

    private static function formatApiKeyMessage(array $status, $fallback)
    {
        if (!empty($status['message'])) {
            return (string) $status['message'];
        }

        $pinned = array();
        if (!empty($status['pinned_domains']) && is_array($status['pinned_domains'])) {
            foreach ($status['pinned_domains'] as $domain) {
                $domain = trim((string) $domain);
                if ($domain !== '') {
                    $pinned[$domain] = true;
                }
            }
        }

        if ($pinned !== []) {
            return 'This API key is registered for: ' . implode(', ', array_keys($pinned))
                . '. Generate a separate key for each site.';
        }

        return (string) $fallback;
    }

    /** @param array<string, mixed> $status */
    private static function renderHtml(array $status)
    {
        if (empty($status['ok'])) {
            $msg = 'Could not load usage from the API.';
            if ((int) $status['http_code'] === 401) {
                $msg = self::formatApiKeyMessage(
                    $status,
                    'Invalid or inactive API key. Generate a key in your jsns.eu dashboard.'
                );
            } elseif (!empty($status['message'])) {
                $msg = htmlspecialchars((string) $status['message'], ENT_QUOTES, 'UTF-8');
            } elseif (!empty($status['error'])) {
                $msg = 'Connection error: ' . htmlspecialchars((string) $status['error'], ENT_QUOTES, 'UTF-8');
            } elseif ((int) $status['http_code'] > 0) {
                $msg = 'API returned HTTP ' . (int) $status['http_code'] . '.';
            }

            return '<div class="alert alert-warning jslikebox-admin-usage-notice">' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8')
                . ' <a href="' . htmlspecialchars(self::DASHBOARD_URL, ENT_QUOTES) . '" target="_blank" rel="noopener">Open API keys dashboard</a></div>';
        }

        $meta         = is_array($status['meta']) ? $status['meta'] : array();
        $viewsUsed    = isset($meta['views_used']) ? (int) $meta['views_used'] : 0;
        $viewLimit    = isset($meta['view_limit']) ? (int) $meta['view_limit'] : 0;
        $widgetsUsed  = isset($meta['widgets_used']) ? (int) $meta['widgets_used'] : 0;
        $widgetLimit  = isset($meta['widget_limit']) ? (int) $meta['widget_limit'] : 0;
        $overLimit    = !empty($meta['over_limit']);
        $widgetDenied = $widgetLimit > 0 && $widgetsUsed >= $widgetLimit;
        $viewPctLabel = ($viewLimit > 0 && $viewsUsed > 0) ? min(100.0, round(($viewsUsed / $viewLimit) * 100, 1)) : 0.0;
        $widgetPctLabel = ($widgetLimit > 0 && $widgetsUsed > 0) ? min(100.0, round(($widgetsUsed / $widgetLimit) * 100, 1)) : 0.0;
        $viewPct      = ($viewPctLabel > 0 && $viewPctLabel < 2) ? 2.0 : $viewPctLabel;
        $widgetPct    = ($widgetPctLabel > 0 && $widgetPctLabel < 2) ? 2.0 : $widgetPctLabel;
        $viewColor    = $overLimit ? '#d9534f' : ($viewPctLabel >= 85 ? '#f0ad4e' : '#5cb85c');
        $userId       = isset($status['user_id']) ? (int) $status['user_id'] : 0;

        $html = '<div class="jslikebox-admin-usage">';

        if ($userId > 0) {
            $html .= '<p class="jslikebox-admin-usage__row"><strong>Account ID:</strong> ' . $userId
                . ' <span class="jslikebox-admin-usage__muted">(from your API key)</span></p>';
        }

        $html .= '<p class="jslikebox-admin-usage__row"><strong>Monthly views</strong> — '
            . number_format($viewsUsed) . ' / ' . number_format($viewLimit) . ' (' . $viewPctLabel . '%)</p>';
        $html .= '<div class="jslikebox-admin-usage__bar-track">';
        $html .= '<div class="jslikebox-admin-usage__bar-fill" style="width:' . $viewPct . '%;min-width:' . ($viewsUsed > 0 ? '8px' : '0') . ';background:' . $viewColor . ';"></div></div>';
        $html .= '<p class="jslikebox-admin-usage__row"><strong>Active sites</strong> — '
            . (int) $widgetsUsed . ' / ' . (int) $widgetLimit . ' (' . $widgetPctLabel . '%)</p>';
        $html .= '<div class="jslikebox-admin-usage__bar-track">';
        $html .= '<div class="jslikebox-admin-usage__bar-fill" style="width:' . $widgetPct . '%;min-width:' . ($widgetsUsed > 0 ? '8px' : '0') . ';background:#5bc0de;"></div></div>';

        if ($overLimit) {
            $html .= '<div class="alert alert-warning">You have reached your monthly view limit. Feeds keep showing cached data.</div>';
        }

        if ($widgetDenied) {
            $html .= '<div class="alert alert-warning">This module exceeds your plan&rsquo;s widget limit and will not render on the site.</div>';
        }

        $html .= '<p class="jslikebox-admin-usage__row" style="margin-bottom:0;"><a href="' . htmlspecialchars(self::UPGRADE_URL, ENT_QUOTES)
            . '" target="_blank" rel="noopener"><strong>Upgrade your plan on jsns.eu</strong></a> to increase limits or manage API keys.</p>';
        $html .= '</div>';

        return $html;
    }

    private static function normalizeDomain($domain)
    {
        $domain = strtolower(trim((string) $domain));
        if ($domain === '') {
            return '';
        }

        if (strpos($domain, '://') !== false) {
            $host = parse_url($domain, PHP_URL_HOST);
            $domain = is_string($host) ? $host : $domain;
        }

        $domain = preg_replace('#/.*$#', '', $domain);
        $domain = preg_replace('#^www\.#', '', $domain);
        $domain = preg_replace('#[^a-z0-9.\-]#', '', $domain);

        return substr($domain, 0, 255);
    }
}
