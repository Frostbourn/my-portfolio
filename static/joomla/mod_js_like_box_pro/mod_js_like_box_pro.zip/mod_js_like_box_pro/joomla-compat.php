<?php

/**
 * Joomla 3.10 compatibility aliases for namespaced CMS classes.
 */

defined('_JEXEC') or die;

if (!class_exists('Joomla\\CMS\\Factory', false)) {
    jimport('joomla.factory');
    if (class_exists('JFactory', false)) {
        class_alias('JFactory', 'Joomla\\CMS\\Factory');
    }
}

if (!class_exists('Joomla\\CMS\\Uri\\Uri', false)) {
    jimport('joomla.environment.uri');
    if (class_exists('JUri', false)) {
        class_alias('JUri', 'Joomla\\CMS\\Uri\\Uri');
    }
}

if (!class_exists('Joomla\\CMS\\Helper\\ModuleHelper', false)) {
    jimport('joomla.application.module.helper');
    if (class_exists('JModuleHelper', false)) {
        class_alias('JModuleHelper', 'Joomla\\CMS\\Helper\\ModuleHelper');
    }
}

if (!class_exists('Joomla\\CMS\\HTML\\HTMLHelper', false)) {
    jimport('joomla.html.html');
    if (class_exists('JHtml', false)) {
        class_alias('JHtml', 'Joomla\\CMS\\HTML\\HTMLHelper');
    }
}

if (!class_exists('Joomla\\Registry\\Registry', false)) {
    jimport('joomla.registry.registry');
    if (class_exists('JRegistry', false)) {
        class_alias('JRegistry', 'Joomla\\Registry\\Registry');
    }
}

if (!class_exists('Joomla\\CMS\\Session\\Session', false)) {
    jimport('joomla.session.session');
    if (class_exists('JSession', false)) {
        class_alias('JSession', 'Joomla\\CMS\\Session\\Session');
    }
}

if (!class_exists('Joomla\\CMS\\Log\\Log', false)) {
    jimport('joomla.log.log');
    if (class_exists('JLog', false)) {
        class_alias('JLog', 'Joomla\\CMS\\Log\\Log');
    }
}

if (!class_exists('Joomla\\CMS\\Form\\FormField', false)) {
    jimport('joomla.form.formfield');
    if (class_exists('JFormField', false)) {
        class_alias('JFormField', 'Joomla\\CMS\\Form\\FormField');
    }
}
