<?php

/**
 * @package    JS Like Box PRO
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * @link       https://jsns.eu
 *
 * Unified, server-side rendered social feed module (Instagram, X, Facebook,
 * YouTube). Feeds are rendered on the server so the customer api_key is never
 * exposed. Views are counted client-side via a signed beacon; widget/usage
 * limits are enforced by the API (validated against jsns.eu).
 */

defined('_JEXEC') or die('Restricted access');

require_once __DIR__ . '/joomla-compat.php';

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

require_once __DIR__ . '/helper.php';

try {

$app      = Factory::getApplication();
$document = $app->getDocument();

$apiUrl = ModJsLikeBoxProHelper::API_BASE_URL;
$apiKey = trim((string) $params->get('api_key'));

$domain   = ModJsLikeBoxProHelper::getSiteDomain();
$widgetId = substr(hash('sha256', $domain . '|' . (int) $module->id), 0, 24);

$postsLimit = 12;

$showOnMobile = (int) $params->get('show_on_mobile', 1);
$displayMode  = (string) $params->get('display_mode', 'slider');
$showFeedPosts = (int) $params->get('show_feed_posts', 1) === 1;
$socialBarPosition = (string) $params->get('social_bar_position', 'bottom');
$socialBarAlign    = (string) $params->get('social_bar_align', 'center');
$theme        = ModJsLikeBoxProHelper::normalizeTheme($params->get('theme', 'rounded_dark'));
$position     = (int) $params->get('position', 0);
$buttonsShape = (int) $params->get('buttons_shape', 0);
$buttonsShape = ($buttonsShape >= 0 && $buttonsShape <= 2) ? $buttonsShape : 0;
$buttonsLabel = (int) $params->get('buttons_label', 0);
$marginTop    = $params->get('margin_top', '10vh');
$faCdn        = (int) $params->get('fa_cdn', 1);
$faShim       = (int) $params->get('fa_shim', 0);

$statusResult  = ($apiUrl !== '' && $apiKey !== '') ? ModJsLikeBoxProHelper::fetchStatus($apiUrl, $apiKey, $widgetId) : null;
$configError   = null;
$statusWarning = null;
$showAdminNotices = ModJsLikeBoxProHelper::canManageModules();
$widgetAllowed = true;
$overLimit     = false;
$beaconToken   = '';
$meta          = null;
$plan          = '';
$showBranding  = false;

if (empty($apiKey) || empty($apiUrl)) {
    $configError = 'Js Like Box Slider is not configured. Paste your API key from the jsns.eu dashboard.';
} elseif (!is_array($statusResult) || empty($statusResult['ok'])) {
    $httpCode = is_array($statusResult) ? (int) $statusResult['http_code'] : 0;

    if ($httpCode === 401) {
        $configError = ModJsLikeBoxProHelper::formatApiKeyStatusMessage(
            is_array($statusResult) ? $statusResult : array(),
            'Invalid or inactive API key. Check the key in your jsns.eu dashboard.'
        );
    } else {
        $statusWarning = 'Could not verify API status'
            . ($httpCode > 0 ? ' (HTTP ' . $httpCode . ')' : '')
            . '. Cached feeds will still display when available.';
    }
} else {
    $meta          = $statusResult['meta'];
    $plan          = isset($statusResult['plan']) ? (string) $statusResult['plan'] : '';
    if ($plan === '' && is_array($meta) && !empty($meta['plan'])) {
        $plan = (string) $meta['plan'];
    }
    $showBranding  = ModJsLikeBoxProHelper::isFreePlan($plan);
    $widgetAllowed = true;
    $overLimit     = !empty($meta['over_limit']);
    $beaconToken   = (string) ($meta['beacon_token'] ?? '');
    $postsLimit    = isset($meta['posts_limit']) ? (int) $meta['posts_limit'] : ModJsLikeBoxProHelper::postsLimitForPlan($plan);
    if ($postsLimit <= 0) {
        $postsLimit = ModJsLikeBoxProHelper::postsLimitForPlan($plan);
    }
}

$feeds         = array();
$socialBarHtml = '';
$wallHtml      = '';
$layout        = (string) $params->get('layout', 'default');
$showSlider    = ($layout !== 'wall') && in_array($displayMode, array('slider', 'both'), true);
$showSocialBar = in_array($displayMode, array('social_bar', 'both'), true);

if ($displayMode === 'social_bar' && $layout !== 'wall') {
    $layout = 'socialbar';
}

if ($configError === null && $widgetAllowed && $layout === 'wall') {
    $wallHtml = ModJsLikeBoxProHelper::renderWallForModule(
        $module,
        $params,
        $apiUrl,
        $apiKey,
        $widgetId,
        $theme,
        $postsLimit,
        $plan
    );
}

if ($configError === null && $widgetAllowed && $showSlider) {
    foreach (ModJsLikeBoxProHelper::PLATFORM_ORDER as $platformSlug) {
        $entry = ModJsLikeBoxProHelper::buildFeedEntry(
            $platformSlug,
            $params,
            $apiUrl,
            $apiKey,
            $widgetId,
            $theme,
            $postsLimit,
            true,
            $showFeedPosts
        );
        if ($entry !== null) {
            $feeds[] = $entry;
        }
    }

    $feeds = array_merge(
        $feeds,
        ModJsLikeBoxProHelper::buildSpecialTabs($params, $apiUrl, $apiKey, $widgetId, $theme, $postsLimit, $beaconToken, (int) $module->id, true)
    );
}

if ($configError === null && $widgetAllowed && $showSocialBar) {
    $ajaxUrl = ModJsLikeBoxProHelper::buildFeedAjaxUrl((int) $module->id);
    $socialBarHtml = ModJsLikeBoxProHelper::renderSocialBarShell(
        $params,
        $theme,
        $socialBarPosition,
        $socialBarAlign,
        (int) $module->id,
        $ajaxUrl
    );
}

$customTabs = array();

if ($configError === null && $widgetAllowed) {
    $rawTabs = $params->get('custom_tabs');

    foreach ((array) $rawTabs as $rawTab) {
        $tab     = (object) $rawTab;
        $content = (string) ($tab->custom_content ?? '');
        $text    = trim((string) ($tab->custom_text ?? ''));
        $icon    = trim((string) ($tab->custom_icon ?? ''));
        $url     = trim((string) ($tab->custom_url ?? ''));

        if ($content === '' && $text === '' && $url === '') {
            continue;
        }

        if ($content !== '' && (int) ($tab->js_prepare_content ?? 0) === 1) {
            $content = HTMLHelper::_('content.prepare', $content);
        }

        $customTabs[] = array(
            'text'    => $text,
            'icon'    => $icon !== '' ? $icon : 'fas fa-link',
            'color'   => trim((string) ($tab->custom_color ?? '')),
            'url'     => $url,
            'content' => $content,
        );
    }
}

if ($overLimit) {
    $keep = array_merge(ModJsLikeBoxProHelper::PLATFORM_ORDER, array('contact', 'whatsapp', 'faq', 'testimonials', 'unified'));
    $feeds = array_values(array_filter($feeds, function ($feed) use ($keep) {
        return isset($feed['key']) && in_array($feed['key'], $keep, true);
    }));
    $customTabs = array();
}

$hasContent = !empty($feeds) || !empty($customTabs) || $socialBarHtml !== '' || $wallHtml !== '';
$hasContact = false;
$hasLazyFeeds = false;
$hasSocialBar = $socialBarHtml !== '';

if ($configError === null && $widgetAllowed) {
    foreach ($feeds as $feed) {
        if (!empty($feed['lazy'])) {
            $hasLazyFeeds = true;
        }
        if (isset($feed['key']) && $feed['key'] === 'contact') {
            $hasContact = true;
        }
    }
}

$cssPath = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/css/style.min.css';
$cssVer  = is_file($cssPath) ? (string) filemtime($cssPath) : '4.0';
ModJsLikeBoxProHelper::addDocumentStyleSheet($document, (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/css/style.min.css', $cssVer);

if (ModJsLikeBoxProHelper::isRoundedTheme($theme)) {
    ModJsLikeBoxProHelper::addDocumentStyleSheet($document, 'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,600;0,9..40,700;0,9..40,800;1,9..40,400&display=swap');
}

if ($faCdn == 1) {
    ModJsLikeBoxProHelper::addDocumentStyleSheet($document, 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css');
    if ($faShim == 1) {
        ModJsLikeBoxProHelper::addDocumentStyleSheet($document, 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/v4-shims.min.css');
    }
}

if ($widgetAllowed && $beaconToken !== '' && $hasContent) {
    ModJsLikeBoxProHelper::addDocumentScriptOptions($document, 'modJsLikeBoxPro', array(
        'beaconUrl' => rtrim($apiUrl, '/') . '/beacon',
        'token'     => $beaconToken,
        'widgetId'  => $widgetId,
    ));
    ModJsLikeBoxProHelper::addDocumentScript($document, (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/beacon.js', '4.0', true);
}

if ($hasContent) {
    $shareJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/share.js';
    ModJsLikeBoxProHelper::addDocumentScript(
        $document,
        (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/share.js',
        is_file($shareJs) ? (string) filemtime($shareJs) : '4.0',
        true
    );

    $imagesJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/images.js';
    ModJsLikeBoxProHelper::addDocumentScript(
        $document,
        (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/images.js',
        is_file($imagesJs) ? (string) filemtime($imagesJs) : '4.0',
        true
    );

    if ($wallHtml !== '') {
        $wallJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/wall.js';
        ModJsLikeBoxProHelper::addDocumentScript(
            $document,
            (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/wall.js',
            is_file($wallJs) ? (string) filemtime($wallJs) : '4.0',
            true
        );
    }

    if ($hasContact) {
        $contactJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/contact.js';
        ModJsLikeBoxProHelper::addDocumentScript(
            $document,
            (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/contact.js',
            is_file($contactJs) ? (string) filemtime($contactJs) : '4.0',
            true
        );
    }

    if ($hasLazyFeeds || $hasSocialBar) {
        ModJsLikeBoxProHelper::ensureJQuery();
        ModJsLikeBoxProHelper::addDocumentScriptOptions($document, 'modJsLikeBoxProLazy', array(
            'ajaxUrl'  => ModJsLikeBoxProHelper::buildFeedAjaxUrl((int) $module->id),
            'moduleId' => (int) $module->id,
        ));
        $lazyJs = (JPATH_SITE . '/modules/mod_js_like_box_pro/tmpl') . '/js/lazy-tabs.js';
        ModJsLikeBoxProHelper::addDocumentScript(
            $document,
            (Uri::root(true) . '/modules/mod_js_like_box_pro/tmpl') . '/js/lazy-tabs.js',
            is_file($lazyJs) ? (string) filemtime($lazyJs) : '4.0',
            true
        );
    }
}

require ModuleHelper::getLayoutPath('mod_js_like_box_pro', $layout);

} catch (Exception $e) {
    return;
}
