<?php

/**
 * Shared migration runner: installs mod_js_like_box_pro from packages zip.
 * Uses direct file copy and creates a site module instance.
 */

defined('_JEXEC') or die;

class JsLikeBoxLegacyMigration
{
    /** @return string */
    public static function flagPath()
    {
        return JPATH_ADMINISTRATOR . '/cache/js_like_box_migrate.json';
    }

    /** @return string */
    public static function cachedProZipPath()
    {
        return JPATH_ADMINISTRATOR . '/cache/js_like_box_pro.zip';
    }

    /** @param string $proZip @param int $legacyId */
    public static function queue($proZip, $legacyId)
    {
        if (is_file($proZip)) {
            @copy($proZip, self::cachedProZipPath());
        }

        $data = array(
            'proZip' => self::resolveProZip($proZip),
            'legacyId' => (int) $legacyId,
            'legacyModule' => self::captureLegacyModuleSettings(),
            'queued' => gmdate('c'),
        );

        @file_put_contents(self::flagPath(), json_encode($data));
    }

    /** @return bool */
    public static function isQueued()
    {
        return is_file(self::flagPath());
    }

    /** @return bool */
    public static function runQueued()
    {
        $flag = self::flagPath();

        if (!is_file($flag)) {
            return false;
        }

        $data = json_decode((string) file_get_contents($flag), true);

        if (!is_array($data)) {
            @unlink($flag);

            return false;
        }

        $proZip = isset($data['proZip']) ? (string) $data['proZip'] : '';
        $legacyId = isset($data['legacyId']) ? (int) $data['legacyId'] : 0;
        $legacyModule = isset($data['legacyModule']) && is_array($data['legacyModule']) ? $data['legacyModule'] : null;

        if ($proZip === '') {
            $proZip = self::defaultProZipPath();
        }

        return self::run($proZip, $legacyId, $legacyModule);
    }

    /**
     * @param string $proZip
     * @param int $legacyId
     * @param array<string, mixed>|null $legacyModule
     * @return bool
     */
    public static function run($proZip, $legacyId = 0, $legacyModule = null)
    {
        $app = self::getApp();
        $flag = self::flagPath();

        if ($legacyId <= 0) {
            $legacyId = self::legacyExtensionId();
        }

        if ($legacyModule === null) {
            $legacyModule = self::captureLegacyModuleSettings();
        }

        $proZip = self::resolveProZip($proZip);

        if (!is_file($proZip)) {
            self::fail(
                $app,
                'JS Like Box migration: bundled mod_js_like_box_pro.zip not found at ' . $proZip
                . '. Install JS Like Box Slider 4.0 manually from jsns.eu or upload mod_js_like_box_pro.zip.'
            );

            return false;
        }

        if (self::isProReady()) {
            self::createProModuleInstance($legacyModule);
            self::removeLegacy($legacyId);
            self::cleanupPlugin();
            @unlink($flag);
            self::success(
                $app,
                'JS Like Box Slider 4.0 (mod_js_like_box_pro) is ready. Open Content → Site Modules to configure your API key.'
            );

            return true;
        }

        $installError = '';
        if (!self::installProZip($proZip, $installError)) {
            $message = 'JS Like Box migration: could not install mod_js_like_box_pro from packages.';
            if ($installError !== '') {
                $message .= ' ' . $installError;
            } else {
                $message .= ' Upload mod_js_like_box_pro.zip manually via System → Install.';
            }

            self::fail($app, $message);

            return false;
        }

        if (!self::isProReady()) {
            self::fail(
                $app,
                'JS Like Box migration: files were copied but mod_js_like_box_pro is not registered. Upload mod_js_like_box_pro.zip manually.'
            );

            return false;
        }

        self::createProModuleInstance($legacyModule);
        self::removeLegacy($legacyId);
        self::cleanupPlugin();
        @unlink($flag);

        self::success(
            $app,
            'JS Like Box Slider 4.0 (mod_js_like_box_pro) has been installed from packages. '
            . 'Open Content → Site Modules, paste your API key from jsns.eu, and publish the module.'
        );

        return true;
    }

    /** @param string $proZip @return string */
    private static function resolveProZip($proZip)
    {
        $candidates = array(
            self::cachedProZipPath(),
            $proZip,
            self::defaultProZipPath(),
        );

        foreach ($candidates as $candidate) {
            if ($candidate !== '' && is_file($candidate)) {
                return $candidate;
            }
        }

        return $proZip !== '' ? $proZip : self::cachedProZipPath();
    }

    /** @return string */
    public static function defaultProZipPath()
    {
        $candidates = array(
            self::cachedProZipPath(),
        );

        if (defined('JPATH_SITE')) {
            $candidates[] = JPATH_SITE . '/modules/mod_facebook_slide_likebox/packages/mod_js_like_box_pro.zip';
        }

        $candidates[] = dirname(__FILE__) . '/packages/mod_js_like_box_pro.zip';

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        return self::cachedProZipPath();
    }

    /** @return bool */
    private static function isProReady()
    {
        if (!defined('JPATH_SITE')) {
            return false;
        }

        if (!is_file(JPATH_SITE . '/modules/mod_js_like_box_pro/mod_js_like_box_pro.php')) {
            return false;
        }

        return self::getProExtensionId() > 0;
    }

    /** @return int */
    private static function getProExtensionId()
    {
        $db = self::getDbo();

        try {
            return (int) $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('extension_id'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('module'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('mod_js_like_box_pro'))
            )->loadResult();
        } catch (Exception $e) {
            return 0;
        }
    }

    /** @return int */
    private static function legacyExtensionId()
    {
        $db = self::getDbo();

        try {
            return (int) $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('extension_id'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('module'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('mod_facebook_slide_likebox'))
            )->loadResult();
        } catch (Exception $e) {
            return 0;
        }
    }

    /** @return array<string, mixed>|null */
    private static function captureLegacyModuleSettings()
    {
        $db = self::getDbo();

        try {
            $row = $db->setQuery(
                $db->getQuery(true)
                    ->select('*')
                    ->from($db->quoteName('#__modules'))
                    ->where($db->quoteName('module') . ' = ' . $db->quote('mod_facebook_slide_likebox'))
                    ->where($db->quoteName('client_id') . ' = 0')
                    ->order($db->quoteName('id') . ' ASC')
            )->loadAssoc();

            return is_array($row) ? $row : null;
        } catch (Exception $e) {
            return null;
        }
    }

    /** @param array<string, mixed>|null $legacyModule */
    private static function createProModuleInstance($legacyModule)
    {
        $db = self::getDbo();

        try {
            $exists = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select('COUNT(*)')
                    ->from($db->quoteName('#__modules'))
                    ->where($db->quoteName('module') . ' = ' . $db->quote('mod_js_like_box_pro'))
                    ->where($db->quoteName('client_id') . ' = 0')
            )->loadResult() > 0;

            if ($exists) {
                return;
            }

            $record = array(
                'title' => self::legacyValue($legacyModule, 'title', 'JS Like Box Slider'),
                'note' => '',
                'content' => '',
                'ordering' => (int) self::legacyValue($legacyModule, 'ordering', 0),
                'position' => self::legacyValue($legacyModule, 'position', 'debug'),
                'checked_out' => 0,
                'checked_out_time' => null,
                'publish_up' => null,
                'publish_down' => null,
                'published' => (int) self::legacyValue($legacyModule, 'published', 0),
                'module' => 'mod_js_like_box_pro',
                'access' => (int) self::legacyValue($legacyModule, 'access', 1),
                'showtitle' => 0,
                'params' => '{}',
                'client_id' => 0,
                'language' => '*',
            );

            $columns = $db->getTableColumns('#__modules');
            if (!isset($columns['language'])) {
                unset($record['language']);
            }

            if (isset($columns['asset_id'])) {
                $record['asset_id'] = 0;
            }

            $db->insertObject('#__modules', (object) $record);
        } catch (Exception $e) {
            // Module instance can be created manually in Content → Site Modules.
        }
    }

    /**
     * @param array<string, mixed>|null $legacyModule
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    private static function legacyValue($legacyModule, $key, $default)
    {
        if (!is_array($legacyModule) || !isset($legacyModule[$key])) {
            return $default;
        }

        return $legacyModule[$key];
    }

    /** @param string $zipPath @param string &$error @return bool */
    private static function installProZip($zipPath, &$error)
    {
        return self::installProManually($zipPath, $error);
    }

    /** @param string $zipPath @param string &$error @return bool */
    private static function installProManually($zipPath, &$error)
    {
        $error = '';
        $package = self::unpackZip($zipPath, $error);

        if ($package === false) {
            return false;
        }

        $sourceDir = rtrim($package['dir'], '/\\');
        $manifest = $sourceDir . '/mod_js_like_box_pro.xml';

        if (!is_file($manifest)) {
            $error = 'Invalid packages zip: mod_js_like_box_pro.xml not found in ' . $sourceDir;
            self::cleanupPackage($package);

            return false;
        }

        $destDir = JPATH_SITE . '/modules/mod_js_like_box_pro';

        if (!self::copyDirectory($sourceDir, $destDir)) {
            $error = 'Could not copy module files to ' . $destDir;
            self::cleanupPackage($package);

            return false;
        }

        self::installLanguageFiles($sourceDir);

        if (!self::registerProExtension($manifest, $error)) {
            self::cleanupPackage($package);

            return false;
        }

        self::cleanupPackage($package);

        if (!is_file($destDir . '/mod_js_like_box_pro.php')) {
            $error = 'Module entry file missing after copy.';

            return false;
        }

        return true;
    }

    /** @param string $manifest @param string &$error @return bool */
    private static function registerProExtension($manifest, &$error)
    {
        $error = '';

        try {
            $xml = @simplexml_load_file($manifest);

            if ($xml === false) {
                $error = 'Could not read module manifest.';

                return false;
            }

            $manifestCache = json_encode(array(
                'name' => (string) $xml->name,
                'type' => 'module',
                'version' => (string) $xml->version,
                'author' => (string) $xml->author,
                'creationDate' => (string) $xml->creationDate,
                'authorEmail' => (string) $xml->authorEmail,
                'authorUrl' => (string) $xml->authorUrl,
            ));

            $db = self::getDbo();
            $extensionId = self::getProExtensionId();

            if ($extensionId > 0) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->update($db->quoteName('#__extensions'))
                        ->set($db->quoteName('manifest_cache') . ' = ' . $db->quote($manifestCache))
                        ->set($db->quoteName('enabled') . ' = 1')
                        ->where($db->quoteName('extension_id') . ' = ' . (int) $extensionId)
                )->execute();

                return true;
            }

            $columns = $db->getTableColumns('#__extensions');
            $record = array(
                'name' => 'mod_js_like_box_pro',
                'type' => 'module',
                'element' => 'mod_js_like_box_pro',
                'folder' => '',
                'client_id' => 0,
                'enabled' => 1,
                'access' => 1,
                'protected' => 0,
                'manifest_cache' => $manifestCache,
                'params' => '{}',
                'custom_data' => '',
                'system_data' => '',
                'checked_out' => 0,
                'checked_out_time' => null,
                'ordering' => 0,
                'state' => 0,
            );

            if (isset($columns['namespace'])) {
                $record['namespace'] = '';
            }

            $db->insertObject('#__extensions', (object) $record);

            return self::getProExtensionId() > 0;
        } catch (Exception $e) {
            $error = $e->getMessage();

            return false;
        }
    }

    /** @param string $sourceDir */
    private static function installLanguageFiles($sourceDir)
    {
        $langSrc = $sourceDir . '/language/en-GB';
        $langDest = JPATH_SITE . '/language/en-GB';

        if (!is_dir($langSrc) || !is_dir($langDest)) {
            return;
        }

        $files = @scandir($langSrc);

        if (!is_array($files)) {
            return;
        }

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $from = $langSrc . '/' . $file;
            if (is_file($from)) {
                @copy($from, $langDest . '/' . $file);
            }
        }
    }

    /** @param string $src @param string $dest @return bool */
    private static function copyDirectory($src, $dest)
    {
        if (!is_dir($src)) {
            return false;
        }

        if (!is_dir($dest) && !@mkdir($dest, 0755, true)) {
            return false;
        }

        $items = @scandir($src);

        if (!is_array($items)) {
            return false;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $from = $src . '/' . $item;
            $to = $dest . '/' . $item;

            if (is_dir($from)) {
                if (!self::copyDirectory($from, $to)) {
                    return false;
                }
                continue;
            }

            if (!@copy($from, $to)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param string $zipPath
     * @param string &$error
     * @return array<string, string>|false
     */
    private static function unpackZip($zipPath, &$error)
    {
        $error = '';

        try {
            if (class_exists('Joomla\\CMS\\Installer\\InstallerHelper')) {
                $package = \Joomla\CMS\Installer\InstallerHelper::unpack($zipPath, true);
            } else {
                JLoader::import('joomla.installer.helper');
                $package = JInstallerHelper::unpack($zipPath);
            }
        } catch (Exception $e) {
            $package = false;
        }

        if ($package !== false && !empty($package['dir']) && is_dir($package['dir'])) {
            return $package;
        }

        return self::unpackZipArchive($zipPath, $error);
    }

    /**
     * @param string $zipPath
     * @param string &$error
     * @return array<string, string>|false
     */
    private static function unpackZipArchive($zipPath, &$error)
    {
        $error = '';

        if (!class_exists('ZipArchive')) {
            $error = 'Could not unpack packages zip (ZipArchive unavailable).';

            return false;
        }

        $tmpBase = defined('JPATH_ROOT') ? JPATH_ROOT . '/tmp' : sys_get_temp_dir();
        $tmp = rtrim($tmpBase, '/\\') . '/js_like_box_migrate_' . uniqid();

        if (!@mkdir($tmp, 0755, true)) {
            $error = 'Could not create temp directory for unpack.';

            return false;
        }

        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            $error = 'Could not open packages zip: ' . $zipPath;
            self::removeDirectory($tmp);

            return false;
        }

        $zip->extractTo($tmp);
        $zip->close();

        $dir = $tmp . '/mod_js_like_box_pro';
        if (!is_dir($dir)) {
            $error = 'Packages zip does not contain mod_js_like_box_pro folder.';
            self::removeDirectory($tmp);

            return false;
        }

        return array(
            'extractdir' => $tmp,
            'dir' => $dir,
        );
    }

    /** @param array<string, string> $package */
    private static function cleanupPackage($package)
    {
        if (!empty($package['extractdir'])) {
            self::removeDirectory($package['extractdir']);
        }
    }

    /** @param string $dir */
    private static function removeDirectory($dir)
    {
        if (!is_dir($dir)) {
            return;
        }

        $items = @scandir($dir);

        if (!is_array($items)) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $path = $dir . '/' . $item;

            if (is_dir($path)) {
                self::removeDirectory($path);
                continue;
            }

            @unlink($path);
        }

        @rmdir($dir);
    }

    /** @param int $extensionId */
    private static function removeLegacy($extensionId)
    {
        if ($extensionId <= 0) {
            self::removeLegacyFilesOnly();

            return;
        }

        try {
            if (class_exists('Joomla\\CMS\\Installer\\Installer')) {
                $installer = new \Joomla\CMS\Installer\Installer();
            } else {
                require_once JPATH_LIBRARIES . '/joomla/installer/installer.php';
                $installer = new JInstaller();
            }

            if ($installer->uninstall('module', (int) $extensionId)) {
                return;
            }
        } catch (Exception $e) {
            // Fall through to manual cleanup.
        }

        self::removeLegacyManually($extensionId);
    }

    private static function removeLegacyFilesOnly()
    {
        self::removeDirectory(JPATH_SITE . '/modules/mod_facebook_slide_likebox');
    }

    /** @param int $extensionId */
    private static function removeLegacyManually($extensionId)
    {
        self::removeLegacyFilesOnly();

        $db = self::getDbo();

        try {
            $db->setQuery(
                $db->getQuery(true)
                    ->delete($db->quoteName('#__modules'))
                    ->where($db->quoteName('module') . ' = ' . $db->quote('mod_facebook_slide_likebox'))
            )->execute();

            $db->setQuery(
                $db->getQuery(true)
                    ->delete($db->quoteName('#__extensions'))
                    ->where($db->quoteName('extension_id') . ' = ' . (int) $extensionId)
            )->execute();
        } catch (Exception $e) {
            // Ignore cleanup issues.
        }
    }

    private static function cleanupPlugin()
    {
        self::removeDirectory(JPATH_PLUGINS . '/system/jslikeboxmigrate');

        $db = self::getDbo();

        try {
            $pluginId = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('extension_id'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('jslikeboxmigrate'))
            )->loadResult();

            if ($pluginId > 0) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->delete($db->quoteName('#__extensions'))
                        ->where($db->quoteName('extension_id') . ' = ' . (int) $pluginId)
                )->execute();
            }
        } catch (Exception $e) {
            // Ignore cleanup issues.
        }
    }

    /** @param object $app @param string $message */
    private static function success($app, $message)
    {
        if (is_object($app) && method_exists($app, 'enqueueMessage')) {
            $app->enqueueMessage($message, 'message');
        }
    }

    /** @param object $app @param string $message */
    private static function fail($app, $message)
    {
        if (is_object($app) && method_exists($app, 'enqueueMessage')) {
            $app->enqueueMessage($message, 'error');
        }
    }

    /** @return object */
    private static function getApp()
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            return \Joomla\CMS\Factory::getApplication();
        }

        return JFactory::getApplication();
    }

    /** @return object */
    private static function getDbo()
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            return \Joomla\CMS\Factory::getDbo();
        }

        return JFactory::getDbo();
    }
}
