<?php

/**
 * Legacy mod_facebook_slide_likebox — queues migration to mod_js_like_box_pro.
 * Actual install runs on the next admin request via plg_system_jslikeboxmigrate.
 */

defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/migration.php';

class Mod_facebook_slide_likeboxInstallerScript
{
    /** @var bool */
    private $queued = false;

    /** @param object $parent */
    public function update($parent)
    {
        $this->queueMigration($parent);
    }

    /** @param string $type @param object $parent */
    public function postflight($type, $parent)
    {
        if (!in_array($type, array('install', 'update', 'discover_install'), true)) {
            return;
        }

        $this->queueMigration($parent);
    }

    /** @param object $parent */
    private function queueMigration($parent)
    {
        if ($this->queued) {
            return;
        }

        $this->queued = true;

        $app = $this->getApp();
        $proZip = $this->proZipPath($parent);
        $legacyId = $this->legacyExtensionId();

        if (!is_file($proZip)) {
            $app->enqueueMessage(
                'JS Like Box migration: bundled mod_js_like_box_pro.zip not found at ' . $proZip
                . '. Install JS Like Box Slider 4.0 manually from jsns.eu.',
                'error'
            );

            return;
        }

        JsLikeBoxLegacyMigration::queue($proZip, $legacyId);
        $this->installMigrationPlugin();
        $this->clearPluginCache();

        $app->enqueueMessage(
            'JS Like Box migration queued (v8.0.5). Reload this admin page to install JS Like Box Slider 4.0 from the bundled packages zip.',
            'message'
        );
    }

    /** @param object $parent @return string */
    private function proZipPath($parent)
    {
        $candidates = array(
            __DIR__ . '/packages/mod_js_like_box_pro.zip',
            dirname(__FILE__) . '/packages/mod_js_like_box_pro.zip',
        );

        if (defined('JPATH_SITE')) {
            $candidates[] = JPATH_SITE . '/modules/mod_facebook_slide_likebox/packages/mod_js_like_box_pro.zip';
        }

        if (is_object($parent) && method_exists($parent, 'getPath')) {
            foreach (array('extension_root', 'source') as $key) {
                $path = $parent->getPath($key);
                if ($path) {
                    $candidates[] = rtrim($path, '/\\') . '/packages/mod_js_like_box_pro.zip';
                }
            }
        }

        foreach ($candidates as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        return $candidates[0];
    }

    private function installMigrationPlugin()
    {
        $src = __DIR__ . '/plugins/system/jslikeboxmigrate';
        $dest = JPATH_PLUGINS . '/system/jslikeboxmigrate';

        if (!is_dir($src)) {
            return;
        }

        if (!is_dir($dest)) {
            $this->copyDirectory($src, $dest);
        } else {
            $this->copyDirectory($src, $dest, false);
        }

        $this->registerMigrationPlugin();
    }

    /** @param string $src @param string $dest @param bool $create */
    private function copyDirectory($src, $dest, $create = true)
    {
        if ($create && !is_dir($dest)) {
            @mkdir($dest, 0755, true);
        }

        if (!is_dir($dest)) {
            return;
        }

        $items = @scandir($src);

        if (!is_array($items)) {
            return;
        }

        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }

            $from = $src . '/' . $item;
            $to = $dest . '/' . $item;

            if (is_dir($from)) {
                $this->copyDirectory($from, $to, true);
                continue;
            }

            @copy($from, $to);
        }
    }

    private function registerMigrationPlugin()
    {
        $db = $this->getDbo();

        try {
            $pluginId = (int) $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('extension_id'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('jslikeboxmigrate'))
            )->loadResult();

            if ($pluginId > 0) {
                $db->setQuery(
                    $db->getQuery(true)
                        ->update($db->quoteName('#__extensions'))
                        ->set($db->quoteName('enabled') . ' = 1')
                        ->where($db->quoteName('extension_id') . ' = ' . (int) $pluginId)
                )->execute();

                return;
            }

            $manifest = array(
                'name' => 'JS Like Box legacy migration runner',
                'type' => 'plugin',
                'version' => '1.0.0',
                'author' => 'Jakub Skowroński',
            );

            $columns = $db->getTableColumns('#__extensions');
            $record = array(
                'name' => 'plg_system_jslikeboxmigrate',
                'type' => 'plugin',
                'element' => 'jslikeboxmigrate',
                'folder' => 'system',
                'client_id' => 0,
                'enabled' => 1,
                'access' => 1,
                'protected' => 0,
                'manifest_cache' => json_encode($manifest),
                'params' => '',
                'custom_data' => '',
                'system_data' => '',
                'checked_out' => 0,
                'checked_out_time' => null,
                'ordering' => 0,
                'state' => 0,
            );

            if (isset($columns['namespace'])) {
                $record['namespace'] = '';
            }

            $object = (object) $record;
            $db->insertObject('#__extensions', $object);
        } catch (Exception $e) {
            // Plugin registration failed — module edit field remains as fallback.
        }
    }

    private function clearPluginCache()
    {
        try {
            if (class_exists('Joomla\\CMS\\Factory')) {
                \Joomla\CMS\Factory::getCache('com_plugins')->clean();
            } else {
                JFactory::getCache('com_plugins')->clean();
            }
        } catch (Exception $e) {
            // Ignore cache backend issues.
        }
    }

    /** @return object */
    private function getApp()
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            return \Joomla\CMS\Factory::getApplication();
        }

        return JFactory::getApplication();
    }

    /** @return int */
    private function legacyExtensionId()
    {
        $db = $this->getDbo();

        try {
            return (int) $db->setQuery(
                $db->getQuery(true)
                    ->select($db->quoteName('extension_id'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote('module'))
                    ->where($db->quoteName('element') . ' = ' . $db->quote('mod_facebook_slide_likebox'))
            )->loadResult();
        } catch (Exception $e) {
            return 0;
        }
    }

    /** @return object */
    private function getDbo()
    {
        if (class_exists('Joomla\\CMS\\Factory')) {
            return \Joomla\CMS\Factory::getDbo();
        }

        return JFactory::getDbo();
    }
}
