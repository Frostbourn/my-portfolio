<?php

/**
 * One-time admin migration runner for legacy JS Like Box module.
 */

defined('_JEXEC') or die;

if (class_exists('Joomla\\CMS\\Plugin\\CMSPlugin')) {
    class PlgSystemJslikeboxmigrate extends Joomla\CMS\Plugin\CMSPlugin
    {
        public function onAfterInitialise()
        {
            $app = \Joomla\CMS\Factory::getApplication();

            if (!$app->isClient('administrator')) {
                return;
            }

            $flag = JPATH_ADMINISTRATOR . '/cache/js_like_box_migrate.json';

            if (!is_file($flag)) {
                return;
            }

            $migrationFile = JPATH_SITE . '/modules/mod_facebook_slide_likebox/migration.php';

            if (!is_file($migrationFile)) {
                return;
            }

            require_once $migrationFile;
            JsLikeBoxLegacyMigration::runQueued();
        }
    }

    return;
}

jimport('joomla.plugin.plugin');

class PlgSystemJslikeboxmigrate extends JPlugin
{
    public function onAfterInitialise()
    {
        $app = JFactory::getApplication();

        if (!$app->isClient('administrator')) {
            return;
        }

        $flag = JPATH_ADMINISTRATOR . '/cache/js_like_box_migrate.json';

        if (!is_file($flag)) {
            return;
        }

        $migrationFile = JPATH_SITE . '/modules/mod_facebook_slide_likebox/migration.php';

        if (!is_file($migrationFile)) {
            return;
        }

        require_once $migrationFile;
        JsLikeBoxLegacyMigration::runQueued();
    }
}
