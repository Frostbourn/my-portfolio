<?php

/**
 * Legacy free module — replaced by mod_js_like_box_pro.
 * Run the v8.0.0 update to uninstall this extension and install JS Like Box Slider 4.0.
 */

defined('_JEXEC') or die;
