<?php

/**
 * Runs queued migration when the legacy module is opened in admin.
 */

defined('_JEXEC') or die;

if (class_exists('Joomla\\CMS\\Form\\FormField')) {
    class JFormFieldJslikeboxmigration extends Joomla\CMS\Form\FormField
    {
        protected $type = 'Jslikeboxmigration';

        protected function getInput()
        {
            $this->runMigration();

            return '<div class="alert alert-info">'
                . 'Completing JS Like Box migration from the bundled packages zip...'
                . '</div>';
        }

        private function runMigration()
        {
            $migrationFile = dirname(__DIR__) . '/migration.php';

            if (!is_file($migrationFile)) {
                return;
            }

            require_once $migrationFile;

            if (JsLikeBoxLegacyMigration::isQueued()) {
                JsLikeBoxLegacyMigration::runQueued();

                return;
            }

            JsLikeBoxLegacyMigration::run(JsLikeBoxLegacyMigration::defaultProZipPath());
        }
    }

    return;
}

JFormHelper::loadFieldClass('hidden');

class JFormFieldJslikeboxmigration extends JFormFieldHidden
{
    protected $type = 'Jslikeboxmigration';

    protected function getInput()
    {
        $migrationFile = dirname(__DIR__) . '/migration.php';

        if (is_file($migrationFile)) {
            require_once $migrationFile;

            if (JsLikeBoxLegacyMigration::isQueued()) {
                JsLikeBoxLegacyMigration::runQueued();
            } else {
                JsLikeBoxLegacyMigration::run(JsLikeBoxLegacyMigration::defaultProZipPath());
            }
        }

        return parent::getInput();
    }
}
